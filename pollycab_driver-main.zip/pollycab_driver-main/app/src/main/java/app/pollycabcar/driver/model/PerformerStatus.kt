package app.pollycabcar.driver.model

import com.google.gson.annotations.SerializedName

class PerformerStatus {

    @SerializedName("id")
    var id: Int? = null

    @SerializedName("performer_id")
    var performerId: Int? = null

    @SerializedName("order_id")
    var orderId: Int? = null

    @SerializedName("status")
    var status: Int? = null

    @SerializedName("latitude")
    var latitude: String? = null

    @SerializedName("longitude")
    var longitude: String? = null

    @SerializedName("created_at")
    var createdAt: String? = null

    @SerializedName("updated_at")
    var updatedAt: String? = null
}
