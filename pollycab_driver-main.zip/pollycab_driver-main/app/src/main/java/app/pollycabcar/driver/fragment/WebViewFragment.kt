package app.pollycabcar.driver.fragment

import android.content.Context
import android.os.Bundle
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.InputMethodManager
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import app.pollycabcar.driver.R
import kotlinx.android.synthetic.main.webview_fragment.*

class WebViewFragment : BaseFragment(){

    private var url: String? = null
    private var imm: InputMethodManager? = null
    private var pageFinishedCount: Int? = 0

    override fun onStart() {
        super.onStart()

        imm = context!!.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        imm?.hideSoftInputFromWindow(view?.windowToken, 0)

        url = arguments?.getString(ARG_URL)
        webview.loadUrl(url)
        showProgress(true)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        retainInstance = true
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?,
                              savedInstanceState: Bundle?): View? {
        return inflater.inflate(R.layout.webview_fragment, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)



        webview.webChromeClient = WebChromeClient()
        webview.settings.javaScriptEnabled = true

        webview.setOnKeyListener(View.OnKeyListener { p0, p1, p2 ->
            if (p2?.action == KeyEvent.ACTION_DOWN){
                when(p1){
                    KeyEvent.KEYCODE_BACK -> {
                        if(webview.canGoBack()) {
                            webview.goBack()
                            return@OnKeyListener true
                        }
                    }
                }
            }
            false
        })

        webview.webViewClient = object : WebViewClient() {

            override fun onPageFinished(view: WebView, url: String) {
                showProgress(false)

                if (url.contains("pollycabcar")){
                    goBack()
                }
            }
        }
    }

    companion object {

        val ARG_URL = "arg_url"

        fun newInstance(url: String): WebViewFragment {

            val args = Bundle()

            args.putString(ARG_URL, url)

            val fragment = WebViewFragment()
            fragment.arguments = args
            return fragment
        }
    }

}