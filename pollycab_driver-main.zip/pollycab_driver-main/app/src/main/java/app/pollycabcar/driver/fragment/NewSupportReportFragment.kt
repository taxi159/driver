package app.pollycabcar.driver.fragment

import android.Manifest
import android.animation.AnimatorSet
import android.animation.ObjectAnimator
import android.animation.ValueAnimator
import android.app.Activity
import android.app.Activity.RESULT_CANCELED
import android.app.Activity.RESULT_OK
import android.app.Dialog
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.ContextWrapper
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Typeface
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.Drawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.SystemClock
import android.provider.MediaStore
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import android.text.Editable
import android.text.TextWatcher
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import android.widget.Toast
import app.pollycabcar.driver.R
import app.pollycabcar.driver.model.DataResponse
import com.bumptech.glide.Glide
import com.karumi.dexter.Dexter
import com.karumi.dexter.MultiplePermissionsReport
import com.karumi.dexter.PermissionToken
import com.karumi.dexter.listener.PermissionRequest
import com.karumi.dexter.listener.multi.MultiplePermissionsListener
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.disposables.Disposable
import io.reactivex.schedulers.Schedulers
import kotlinx.android.synthetic.main.chat_with_support_fragment.*
import okhttp3.MediaType
import okhttp3.MultipartBody
import okhttp3.RequestBody
import org.jetbrains.anko.find
import org.jetbrains.anko.support.v4.toast
import org.jetbrains.anko.textColor
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.io.OutputStream
import java.text.SimpleDateFormat
import java.util.*


class NewSupportReportFragment : BaseFragment() {
    private var sendDisposable: Disposable? = null
    private var file: File? = null
    private var isGranted: Boolean? = false
    private var mLastClickTime = 0L

    override fun onStart() {
        super.onStart()
        changeFont()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        retainInstance = true
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?,
                              savedInstanceState: Bundle?): View? {
        val view = inflater.inflate(R.layout.chat_with_support_fragment, container, false)

        return view
    }

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)
        showPermissions()
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        toolbar.setNavigationIcon(R.drawable.ic_arrow_back)
        toolbar.setNavigationOnClickListener { 
            goBack()
        }

        sendMessageButton.setOnClickListener {

            if (SystemClock.elapsedRealtime() - mLastClickTime < 1000){
                return@setOnClickListener
            }
            mLastClickTime = SystemClock.elapsedRealtime()

            if (headerText.text.isEmpty()){
                toast("Заполните тему обращения")
                return@setOnClickListener
            } else if(messageText.text.isEmpty()) {
                toast("Заполните текст обращения")
                return@setOnClickListener
            } else {
                if (file != null ) {
                    sendReportWithImage(loginService.value.accessToken, headerText.text.toString().trim(), messageText.text.toString().trim())
                } else {
                    createReport(loginService.value.accessToken, headerText.text.toString().trim(), messageText.text.toString().trim())
                }
            }
        }

        addPhotoBtn.setOnClickListener {
            showDialogAction("Добавить фото", "Галерея", "Камера", "add_photo")
        }

        deleteImageBtn.setOnClickListener {
            file = null

            imageLayout.visibility = View.GONE
        }
    }

    private fun createReport(token: String, topic: String, message: String) {
        showProgress(true)

        messageText.clearFocus()
        hideKeyboardFrom(context!!, messageText)

        sendDisposable = taxiService.value.createReport(token, topic, message)
                .subscribeOn(Schedulers.newThread())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe({ t: DataResponse ->

                    if (t.status == "success"){

                        toast("Обращение успешно отправлено")

                    }

                    showProgress(false)
                    goBack()

                }, { e ->
                    e.printStackTrace()
                    toast(e.localizedMessage)
                    showProgress(false)
                })
    }

    private fun sendReportWithImage(token: String, topic: String, message: String) {
        showProgress(true)

        messageText.clearFocus()
        hideKeyboardFrom(context!!, messageText)

        val body = MultipartBody.Part.createFormData("token", token)
        val body2 = MultipartBody.Part.createFormData("topic", topic)
        val body3 = MultipartBody.Part.createFormData("text", message)
        val requestFile = RequestBody.create(MediaType.parse("image/png"), file)
        val body4 = MultipartBody.Part.createFormData("file", "image.jpg", requestFile)

        sendDisposable = taxiService.value.createReportWithImage(body, body2, body3, body4)
                .subscribeOn(Schedulers.newThread())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe({ t: DataResponse ->

                    if (t.status == "success"){

                        if (file != null){

                            file?.deleteOnExit()
                            file = null
                        }

                        goBack()
                    }

                }, { e ->
                    e.printStackTrace()
                    toast(e.localizedMessage)
                    showProgress(false)
                })
    }

    private fun showDialogAction(dialogTitle: String, firstBtn: String, secondBtn: String, action: String) {
        context?.let {
            val mDialog = Dialog(it, R.style.CustomDialog)
            mDialog.setCancelable(true)
            mDialog.setContentView(R.layout.dialog_with_action)

            val type = Typeface.createFromAsset(context?.assets, "font/roboto_regular.ttf")

            val title = mDialog.find<TextView>(R.id.title)
            val firstButtonText = mDialog?.find<TextView>(R.id.firstButtonText)
            val secondButtonText = mDialog?.find<TextView>(R.id.secondButtonText)

            title.typeface = type
            title.text = dialogTitle
            firstButtonText.typeface = type
            firstButtonText.text = firstBtn
            secondButtonText.typeface = type
            secondButtonText.text = secondBtn

            firstButtonText.setOnClickListener {
                mDialog.dismiss()

                val intent = Intent(Intent.ACTION_GET_CONTENT)
                intent.type = "image/jpeg"
                try {
                    startActivityForResult(intent, GALLERY_REQUEST_CODE)
                } catch (e: ActivityNotFoundException) {
                    e.printStackTrace()
                }
            }
            secondButtonText.setOnClickListener {
                if (!isGranted!!){
                    mDialog.dismiss()
                    showPermissions()
                } else {
                    mDialog.dismiss()

                    // Create an image file name
                    val timeStamp: String = SimpleDateFormat("yyyyMMdd_HHmmss").format(Date())
                    val storageDir: File? = mainActivity.getExternalFilesDir(Environment.DIRECTORY_PICTURES)
                    file = File.createTempFile(
                            "JPEG_${timeStamp}_", /* prefix */
                            ".jpg", /* suffix */
                            storageDir /* directory */
                    )

                    val imageUri = if(Build.VERSION.SDK_INT >= 24){
                        FileProvider.getUriForFile(context!!, "${context?.packageName}.fileprovider", file!!)
                    } else {
                        Uri.fromFile(file!!)
                    }

                    val intent = Intent(MediaStore.ACTION_IMAGE_CAPTURE)
                    intent.putExtra(MediaStore.EXTRA_OUTPUT, imageUri)
                    startActivityForResult(intent, REQUEST_IMAGE)
                }
            }

            mDialog.show()
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

        if (requestCode == GALLERY_REQUEST_CODE){

            if (resultCode == RESULT_OK) {
                try {
                    file = File(context!!.filesDir, "img" + Date().time)
                    val cr = mainActivity.contentResolver
                    val `is` = cr.openInputStream(data!!.data!!)
                    file!!.createNewFile()
                    `is`?.copyTo(file!!.outputStream())
                    file!!.absolutePath
                    showFile()
                } catch (e: IOException) {
                    e.printStackTrace()
                }
            }
        }

        if (requestCode == REQUEST_IMAGE && resultCode == Activity.RESULT_OK) {
            showFile()
        } else {
            file = null
        }
    }

    private fun showFile() {
        imageLayout.visibility = View.VISIBLE
        Glide.with(context!!).load(file?.absolutePath).into(imageView)
    }

    private fun changeFont() {
        changeFontInTextView(headerLabelText)
        changeFontInEditTextView(messageText)
        changeFontInEditTextView(headerText)
    }

    private fun showPermissions(){
        Dexter.withActivity(mainActivity)
                .withPermissions(Manifest.permission.CAMERA)
                .withListener(object : MultiplePermissionsListener {

                    override fun onPermissionRationaleShouldBeShown(permissions: MutableList<PermissionRequest>?, token: PermissionToken?) {
                        token?.continuePermissionRequest()
                    }

                    override fun onPermissionsChecked(report: MultiplePermissionsReport?) {
                        try {
                            isGranted = report!!.areAllPermissionsGranted()
                        } catch (e: IOException) {
                            toast("Could not create file!")
                        }
                    }
                }).check()
    }

    companion object {
        private val GALLERY_REQUEST_CODE = 100
        private val REQUEST_IMAGE = 200
    }

}
