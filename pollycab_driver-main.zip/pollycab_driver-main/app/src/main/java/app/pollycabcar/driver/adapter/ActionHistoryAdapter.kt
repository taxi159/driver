package app.pollycabcar.driver.adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView

import androidx.recyclerview.widget.RecyclerView
import app.pollycabcar.driver.R
import app.pollycabcar.driver.model.ActionHistoryModel
import app.pollycabcar.driver.util.DateFormatter
import java.util.*

class ActionHistoryAdapter : RecyclerView.Adapter<ActionHistoryAdapter.ActionHolder>() {

    var activityList: List<ActionHistoryModel>? = null

    fun setList(list: List<ActionHistoryModel>) {
        activityList = list
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ActionHolder {
        val v = LayoutInflater.from(parent.context).inflate(R.layout.item_action_item, null)
        return ActionHolder(v)
    }

    override fun onBindViewHolder(holder: ActionHolder, position: Int) {
        holder.setIsRecyclable(false)

        val date: Date = DateFormatter.getDateFromStringUTC(activityList!![position].date!!)!!

        holder.date.text = DateFormatter.getSimpleDate(date) + " " + DateFormatter.getSimpleTime(date)
        holder.desc.setText(activityList!![position].description)
    }

    override fun getItemCount(): Int {
        return if (activityList != null)
            activityList!!.size
        else
            0
    }

    inner class ActionHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val date: TextView
        val desc: TextView

        init {
            date = itemView.findViewById(R.id.tv_date)
            desc = itemView.findViewById(R.id.tv_desc)
        }
    }
}
