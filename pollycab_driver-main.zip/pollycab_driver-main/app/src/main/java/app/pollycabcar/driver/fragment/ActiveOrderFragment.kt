package app.pollycabcar.driver.fragment

import android.app.Dialog
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.net.Uri
import android.os.Bundle
import androidx.localbroadcastmanager.content.LocalBroadcastManager
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.lifecycle.Observer
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.annotation.DrawableRes
import androidx.core.content.ContextCompat
import androidx.lifecycle.MutableLiveData
import app.pollycabcar.driver.R
import app.pollycabcar.driver.adapter.OrderAddressesAdapter
import app.pollycabcar.driver.adapter.ServicesAdapter
import app.pollycabcar.driver.model.*
import app.pollycabcar.driver.repo.NotificationRepository
import com.google.android.gms.common.api.GoogleApiClient
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.MapsInitializer
import com.google.android.gms.maps.model.*
import com.pixplicity.easyprefs.library.Prefs
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.disposables.Disposable
import io.reactivex.schedulers.Schedulers
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import kotlinx.android.synthetic.main.taked_order_fragment.*
import org.jetbrains.anko.find
import org.jetbrains.anko.notificationManager
import org.jetbrains.anko.support.v4.toast
import java.text.SimpleDateFormat
import java.util.*

class ActiveOrderFragment : BaseFragment() {

    var mGoogleApiClient: GoogleApiClient? = null

    private lateinit var servicesAdapter: ServicesAdapter
    private lateinit var addressesAdapter: OrderAddressesAdapter

    private var orderId: Int? = null
    private var orderInfo: OrderInfoModel? = null
    private var orderStatus: Int? = null

    private var googleMap: GoogleMap? = null

    private var orderDisposable: Disposable? = null

    private var disposable: Disposable? = null

    override fun onStart() {
        super.onStart()
        changeFont()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        retainInstance = true

    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        return inflater.inflate(R.layout.taked_order_fragment, container, false)
    }

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        subscribeToNotification()

        orderId = arguments?.getInt(ARG_ORDER_ID)

        rvServices.layoutManager = LinearLayoutManager(context, LinearLayoutManager.HORIZONTAL, false)
        servicesAdapter = ServicesAdapter()
        rvServices.adapter = servicesAdapter
        rvServices.isNestedScrollingEnabled = false

        rvAddresses.layoutManager = LinearLayoutManager(context, LinearLayoutManager.VERTICAL, false)
        addressesAdapter = OrderAddressesAdapter()
        rvAddresses.adapter = addressesAdapter
        rvAddresses.isNestedScrollingEnabled = false

        toolbar.setNavigationIcon(R.drawable.ic_menu)
        toolbar.setNavigationOnClickListener {
            mainActivity.hardReplaceFragment(MainFragment())
        }

        mapView?.onCreate(savedInstanceState)

        mapView?.onResume()

        try {
            MapsInitializer.initialize(activity!!.applicationContext)
        } catch (e: Exception) {
            e.printStackTrace()
        }

        mapView?.getMapAsync { mMap ->
            googleMap = mMap

            googleMap?.uiSettings?.isRotateGesturesEnabled = false
            googleMap?.uiSettings?.isCompassEnabled = false
            googleMap?.uiSettings?.isMapToolbarEnabled = false
            googleMap?.uiSettings?.isIndoorLevelPickerEnabled = true
            googleMap?.uiSettings?.isMyLocationButtonEnabled = false
        }

        updateOrderInfo()

        btnChangeOrderStatus.setOnClickListener {
            val newStatus = orderStatus!! + 1

            val lat = Prefs.getDouble("my_latitude", 0.0).toString()
            val lon = Prefs.getDouble("my_longitude", 0.0).toString()

            showProgress(true)

            orderDisposable?.dispose()
            orderDisposable = taxiService.value.setPerformerOrderStatus(loginService.value.accessToken, orderInfo?.id!!, newStatus, lat, lon)
                .subscribeOn(Schedulers.newThread())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe({ t: DataResponse ->

                    showProgress(false)

                    orderStatus = newStatus

                    when(orderStatus) {
                        3 -> {
                            orderStatusText.text = getString(R.string.start_move)
                        }
                        4 -> {
                            orderStatusText.text = getString(R.string.stop_move)
                        }
                        5 -> {
                            replaceFragment(OrderCompliteFragment.newInstance(orderInfo?.id!!))
                        }
                    }

                }, { e ->
                    e.printStackTrace()
                    toast(e.localizedMessage)
                    showProgress(false)
                })
        }

        callBtn.setOnClickListener {
            val intent = Intent(Intent.ACTION_DIAL)
            intent.data = Uri.parse("tel:+${orderInfo?.phoneNumber}")
            if (intent.resolveActivity(context!!.packageManager) != null) {
                startActivity(intent)
            }
        }

        navigatorButton.setOnClickListener {
            showDialogForSelectNavigator()
        }
    }

    private fun subscribeToNotification() {
        val liveData: MutableLiveData<MutableList<Notification>> =
            NotificationRepository.instance!!.notificationLiveData
        liveData.observe(this, Observer { t ->
            if (t.size == 0) {
                return@Observer
            }

            val notification: Notification = t[0]

            when (notification.action) {
                Notification.Action.OrderCanceled -> {
                    if (notification.orderId!!.toInt() == orderInfo?.id) {
                        mainActivity.hardReplaceFragment(MainFragment())
                        toast("Заказ был отменён")
                    }

                    NotificationRepository.instance?.removeNotification()
                }
                Notification.Action.RemovedFromOrder -> {
                    if (notification.orderId!!.toInt() == orderInfo?.id) {
                        mainActivity.hardReplaceFragment(MainFragment())
                        toast("Вы были сняты с заказа")
                    }

                    NotificationRepository.instance?.removeNotification()
                }
                else -> {
                    updateOrderInfo()
                    NotificationRepository.instance?.removeNotification()
                }
            }
        })
    }

    private fun updateOrderInfo() {
        orderDisposable?.dispose()
        orderDisposable = taxiService.value.getOrderInfo(loginService.value.accessToken, orderId!!.toInt())
            .subscribeOn(Schedulers.newThread())
            .observeOn(AndroidSchedulers.mainThread())
            .subscribe({ t: OrderInfoResponse ->

                if (t.status == "success"){

                    if (t.orderInfo != null){

                        orderInfo = t.orderInfo!!

                        toolbar.title = getString(R.string.orderWithId) + t.orderInfo!!.id

                        textTariff.text = t.orderInfo!!.transportationTariffName

                        t.orderInfo!!.resultTripCost?.let { tv_price.text = it.toString() + " \u20BD" }

                        addressesAdapter.setList(t.orderInfo?.addresses!!)

                        if(!t.orderInfo!!.comment.isNullOrEmpty()) {
                            commentText.visibility = View.VISIBLE
                            commentText.text = t.orderInfo!!.comment
                        }

                        var format: SimpleDateFormat = SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
                        val date: Date = format.parse(t.orderInfo!!.deadline)
                        format = SimpleDateFormat("E, d MMM HH:mm", Locale("ru"))
                        val deadline: String = format.format(date)
                        tv_date_time.text = deadline

                        if(t.orderInfo!!.services!!.isNotEmpty())
                            servicesAdapter.setList(t.orderInfo!!.services!!)
                        else
                            rvServices.visibility = View.GONE

                        clientNameText.text = t.orderInfo?.fullName

                        if(t.showClientDataForPerformer == true) {
                            layoutClientData.visibility = View.VISIBLE
                            googleMap!!.setPadding(0, 0, 0, 350)
                        } else {
                            googleMap!!.setPadding(0, 0, 0, 180)
                        }

                        val paymentType = t.orderInfo!!.paymentType
                        when(paymentType){
                            0 -> tv_payment_type.text = getString(R.string.payment_type_nal)
                            1 -> tv_payment_type.text = getString(R.string.payment_type_bez_nal)
                            2 -> tv_payment_type.text = getString(R.string.payment_type_virtual)
                            3 -> tv_payment_type.text = getString(R.string.payment_type_organization)
                        }

                        orderStatus = if(orderInfo?.performerStatuses!!.isEmpty()) 2 else orderInfo?.performerStatuses!![0].status
                        when(orderStatus) {
                            2 -> {
                                orderStatusText.text = getString(R.string.near_the_client)
                            }
                            3 -> {
                                orderStatusText.text = getString(R.string.start_move)
                            }
                            4 -> {
                                orderStatusText.text = getString(R.string.stop_move)
                            }
                            5 -> {
                                replaceFragment(OrderCompliteFragment.newInstance(orderInfo?.id!!))
                            }
                        }

                        drawRoutePolyline()
                    }

                } else if(t.status == "error" && t.error == "no_access") {
                    toast("Доступ запрещён")
                    mainActivity.hardReplaceFragment(MainFragment())
                }

                showProgress(false)
            }, { e ->
                e.printStackTrace()
                showProgress(false)
            })
    }

    private fun drawRoutePolyline() {
        val LatLongB = LatLngBounds.Builder()
        val options = PolylineOptions()
        options.color(resources.getColor(R.color.lightBlue))
        options.width(7f)

        googleMap!!.addMarker(
            MarkerOptions().position(
                LatLng(
                    orderInfo?.geoPoints?.get(0)?.lat!!.toDouble(),
                    orderInfo?.geoPoints?.get(0)?.lon!!.toDouble()
                )
            ).icon(bitmapDescriptorFromVector(context!!, R.drawable.ic_marker_start))
        )

        for (coordinates in orderInfo?.routePolyline!!) {
            options.add(LatLng(coordinates[0], coordinates[1]))
            LatLongB.include(LatLng(coordinates[0], coordinates[1]))
        }
        googleMap!!.addPolyline(options)

        for (geoPoint in orderInfo?.geoPoints!!) {
            googleMap!!.addMarker(
                MarkerOptions().position(
                    LatLng(
                        geoPoint.lat!!.toDouble(),
                        geoPoint.lon!!.toDouble()
                    )
                ).icon(bitmapDescriptorFromVector(context!!, R.drawable.ic_marker_end))
            )
        }

        googleMap!!.setPadding(0, 0, 0, 180)

        val bounds = LatLongB.build()
        val width = getResources().getDisplayMetrics().widthPixels
        val height = getResources().getDisplayMetrics().heightPixels
        val padding = (width * 0.30).toInt()
        googleMap!!.moveCamera(CameraUpdateFactory.newLatLngBounds(bounds, width, height, padding))
    }

    private fun bitmapDescriptorFromVector(
        context: Context,
        @DrawableRes vectorResId: Int
    ): BitmapDescriptor? {
        val vectorDrawable: Drawable = ContextCompat.getDrawable(context, vectorResId)!!
        vectorDrawable.setBounds(
            0,
            0,
            vectorDrawable.intrinsicWidth,
            vectorDrawable.intrinsicHeight
        )
        val bitmap = Bitmap.createBitmap(
            vectorDrawable.intrinsicWidth,
            vectorDrawable.intrinsicHeight,
            Bitmap.Config.ARGB_8888
        )
        val canvas = Canvas(bitmap)
        vectorDrawable.draw(canvas)
        return BitmapDescriptorFactory.fromBitmap(bitmap)
    }

    override fun onResume() {
        super.onResume()
        mapView?.onResume()
    }

    override fun onPause() {
        super.onPause()
        mapView?.onPause()

        if (mGoogleApiClient != null && mGoogleApiClient!!.isConnected) {
            mGoogleApiClient?.stopAutoManage(activity!!)
            mGoogleApiClient?.disconnect()
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        mapView?.onDestroy()
        disposable?.dispose()
    }

    override fun onLowMemory() {
        super.onLowMemory()
        mapView?.onLowMemory()
    }

    override fun onStop() {
        super.onStop()
        orderDisposable?.dispose()
    }

    private fun startNavigator(Lng: String, Lat: String){

        val uri: Uri?

        when (Prefs.getInt("navigation", 0)){
            2 -> {
                Prefs.putInt("navigation", 2)

                uri = Uri.parse("dgis://2gis.ru/routeSearch/rsType/car/to/" +
                        Lng + "," + Lat)
            }

            else -> {
                Prefs.putInt("navigation", 1)

                uri = Uri.parse("yandexnavi://build_route_on_map?lat_to=" +
                        Lat + "&lon_to=" + Lng)
            }
        }

        val intent = Intent(Intent.ACTION_VIEW, uri)
        val packageManager = context?.packageManager
        val activities = packageManager?.queryIntentActivities(intent, 0)
        val isIntentSafe = activities!!.size > 0

        if (isIntentSafe)
            startActivity(intent)
        else
            toast("Не удалось запустить навигатор, т. к. на смартфоне не установлена программа Яндекс.Навигатор или 2ГИС")
    }

    private fun showDialogForSelectNavigator() {
        context?.let {
            val dialog = Dialog(it, R.style.CustomDialog)
            dialog.setCancelable(true)
            dialog.setContentView(R.layout.dialog_for_select_navigator)

            val type = Typeface.createFromAsset(context?.assets, "font/roboto_regular.ttf")
            val typeBold = Typeface.createFromAsset(context?.assets, "font/roboto_medium.ttf")
            val title = dialog.find<TextView>(R.id.title)
            val firstButtonText = dialog.find<TextView>(R.id.firstButtonText)
            val secondButtonText = dialog.find<TextView>(R.id.secondButtonText)

            title.typeface = typeBold
            firstButtonText.typeface = type
            secondButtonText.typeface = type

            firstButtonText.setOnClickListener {
                dialog.dismiss()
                Prefs.putInt("navigation", 1)
                showDialogForSelectNavigationPoint()
            }

            secondButtonText.setOnClickListener {
                dialog.dismiss()
                Prefs.putInt("navigation", 2)
                showDialogForSelectNavigationPoint()
            }

            dialog.show()
        }
    }

    private fun showDialogForSelectNavigationPoint() {
        context?.let {
            val dialog = Dialog(it, R.style.CustomDialog)
            dialog.setCancelable(true)
            dialog.setContentView(R.layout.dialog_for_select_navigation_point)

            val type = Typeface.createFromAsset(context?.assets, "font/roboto_regular.ttf")
            val typeBold = Typeface.createFromAsset(context?.assets, "font/roboto_medium.ttf")
            val title = dialog.find<TextView>(R.id.title)
            val firstButtonText = dialog.find<TextView>(R.id.firstButtonText)
            val secondButtonText = dialog.find<TextView>(R.id.secondButtonText)

            title.typeface = typeBold
            firstButtonText.typeface = type
            secondButtonText.typeface = type

            firstButtonText.setOnClickListener {
                dialog.dismiss()
                startNavigator(orderInfo?.geoPoints?.get(0)?.lon!!, orderInfo?.geoPoints?.get(0)?.lat!!)
            }

            secondButtonText.setOnClickListener {
                dialog.dismiss()
                startNavigator(orderInfo?.geoPoints?.last()?.lon!!, orderInfo?.geoPoints?.last()?.lat!!)
            }

            dialog.show()
        }
    }

    private fun changeFont() {
        changeFontInTextView(tv_date_time)
        changeFontInTextView(textTariff)
        changeFontInTextView(tv_payment_type)
        changeFontInTextView(clientText)
        changeFontInTextView(commentText)

        changeFontInTextViewBold(tv_price)
        changeFontInTextViewBold(orderStatusText)
        changeFontInTextViewBold(clientNameText)
    }

    companion object {
        val ARG_ORDER_ID = "arg_order_id"

        fun newInstance(orderId: Int): ActiveOrderFragment {

            val args = Bundle()

            args.putInt(ARG_ORDER_ID, orderId)
            val fragment = ActiveOrderFragment()
            fragment.arguments = args
            return fragment
        }
    }
}
