package app.pollycabcar.driver.activity

import android.Manifest
import android.annotation.SuppressLint
import android.app.Dialog
import android.app.PendingIntent
import android.content.Intent
import android.content.res.Configuration
import android.graphics.Typeface
import android.os.Bundle
import android.os.Handler
import android.util.Log
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentManager
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.Observer
import app.pollycabcar.driver.R
import app.pollycabcar.driver.fragment.*
import app.pollycabcar.driver.model.DataResponse
import app.pollycabcar.driver.model.DriverModel
import app.pollycabcar.driver.model.Notification
import app.pollycabcar.driver.model.OrderResponse
import app.pollycabcar.driver.network.LoginService
import app.pollycabcar.driver.network.TaxiService
import app.pollycabcar.driver.repo.NotificationRepository
import app.pollycabcar.driver.repo.OrdersRepository
import app.pollycabcar.driver.repo.ProfileRepository
import app.pollycabcar.driver.service.LocationUpdatesBroadcastReceiver
import com.github.salomonbrys.kodein.LazyKodein
import com.github.salomonbrys.kodein.android.KodeinAppCompatActivity
import com.github.salomonbrys.kodein.android.appKodein
import com.github.salomonbrys.kodein.instance
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationRequest
import com.google.android.gms.location.LocationServices
import com.google.firebase.iid.FirebaseInstanceId
import com.karumi.dexter.Dexter
import com.karumi.dexter.MultiplePermissionsReport
import com.karumi.dexter.PermissionToken
import com.karumi.dexter.listener.PermissionDeniedResponse
import com.karumi.dexter.listener.multi.MultiplePermissionsListener
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.disposables.Disposable
import io.reactivex.schedulers.Schedulers
import org.jetbrains.anko.find
import org.jetbrains.anko.toast
import retrofit2.HttpException
import java.util.*


class MainActivity : KodeinAppCompatActivity() {

    protected val kodein = LazyKodein(appKodein)
    protected val taxiService = kodein.instance<TaxiService>()
    protected val loginService = kodein.instance<LoginService>()

    var progressView: FrameLayout? = null
    var fragment: Fragment? = null

    private var isGranted: Boolean = false

    internal var doubleBackToExitPressedOnce = false

    private val UPDATE_INTERVAL: Long = 10000
    private val FASTEST_UPDATE_INTERVAL: Long = 5000
    private val MAX_WAIT_TIME: Long = 30000

    private var mFusedLocationClient: FusedLocationProviderClient? = null
    private var mLocationRequest: LocationRequest? = null

    private var profile: DriverModel? = null

    private var infoDisposable: Disposable? = null
    private var firebaseDisposable: Disposable? = null
    private var ordersListDisposable: Disposable? = null

    @SuppressLint("MissingSuperCall")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.main_activity)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        val scale = 1.0f
        val res = resources
        val configuration =
            Configuration(res.configuration)
        configuration.fontScale = scale
        res.updateConfiguration(configuration, res.displayMetrics)

        progressView = findViewById(R.id.progressMain)
        mFusedLocationClient = LocationServices.getFusedLocationProviderClient(this)

        if (savedInstanceState == null) {

            if (loginService.value.isLoggedIn()) {
                progressView?.visibility = View.VISIBLE
                createLocationRequest()
                getLocationPermissions()
                getDriverInfo()
                getOrders()
            } else {
                val ft = supportFragmentManager.beginTransaction()
                ft.replace(R.id.placeholder, LoginFragment())
                ft.commit()
            }
        }

        subscribeToNotification()
    }

    private fun subscribeToNotification() {
        val liveData: MutableLiveData<MutableList<Notification>> =
            NotificationRepository.instance!!.notificationLiveData
        liveData.observe(this, Observer { t ->
            if (t.size == 0) {
                return@Observer
            }

            val notification: Notification = t[0]

            when (notification.action) {
                Notification.Action.NewOrder -> {
                    val calendar: Calendar = Calendar.getInstance()
                    val now = (calendar.timeInMillis / 1000).toInt()

                    if (notification.orderTimeout!! > now) {
                        val ft = supportFragmentManager.beginTransaction()
                        ft.setCustomAnimations(
                            R.anim.enter_from_right,
                            R.anim.exit_to_left,
                            R.anim.enter_from_left,
                            R.anim.exit_to_right
                        )
                        ft.replace(
                            R.id.placeholder,
                            OrderInfoFragment.newInstance(notification.orderId.toString(), 0)
                        )
                        ft.addToBackStack(null)
                        ft.commit()
                    }

                    getOrders()

                    NotificationRepository.instance?.removeNotification()
                }
                Notification.Action.AssignedOnOrder -> {
                    val ft = supportFragmentManager.beginTransaction()
                    ft.setCustomAnimations(
                        R.anim.enter_from_right,
                        R.anim.exit_to_left,
                        R.anim.enter_from_left,
                        R.anim.exit_to_right
                    )
                    ft.replace(
                        R.id.placeholder,
                        ActiveOrderFragment.newInstance(notification.orderId!!)
                    )
                    ft.addToBackStack(null)
                    ft.commit()

                    updateDriverProfile()

                    NotificationRepository.instance?.removeNotification()
                }
                Notification.Action.OrderCanceled -> {
                    if (notification.orderId!!.toInt() == ProfileRepository.instance?.profile?.activeOrder?.id) {
                        updateDriverProfile(true)
                        getOrders()
                        toast("Заказ был отменён")
                    }

                    NotificationRepository.instance?.removeNotification()
                }
                Notification.Action.RemovedFromOrder -> {
                    if (notification.orderId!!.toInt() == ProfileRepository.instance?.profile?.activeOrder?.id) {
                        updateDriverProfile(true)
                        getOrders()
                        toast("Вы были сняты с заказа")
                    }

                    NotificationRepository.instance?.removeNotification()
                }
                Notification.Action.PerformerStatusChanged -> {
                    updateDriverProfile()
                    toast("Вы были сняты с линии")
                    NotificationRepository.instance?.removeNotification()
                }
                else -> {
                    updateDriverProfile()
                    NotificationRepository.instance?.removeNotification()
                }
            }
        })
    }

    fun createLocationRequest() {
        mLocationRequest = LocationRequest()

        mLocationRequest?.interval = UPDATE_INTERVAL

        // Sets the fastest rate for active location updates. This interval is exact, and your
        // application will never receive updates faster than this value.
        mLocationRequest?.fastestInterval = FASTEST_UPDATE_INTERVAL
        mLocationRequest?.priority = LocationRequest.PRIORITY_HIGH_ACCURACY

        // Sets the maximum time when batched location updates are delivered. Updates may be
        // delivered sooner than this interval.
        mLocationRequest?.maxWaitTime = MAX_WAIT_TIME
    }

    private fun getPendingIntent(): PendingIntent {
        val intent: Intent = Intent(this, LocationUpdatesBroadcastReceiver::class.java)
        intent.action = LocationUpdatesBroadcastReceiver.ACTION_PROCESS_UPDATES
        return     if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.S) {
            PendingIntent.getBroadcast(this, 0, intent, PendingIntent.FLAG_MUTABLE)
        }
        else
        {
            PendingIntent.getBroadcast(this, 0, intent, PendingIntent.FLAG_UPDATE_CURRENT)
        }
    }

    fun requestLocationUpdates() {
        Log.i("Location", "Starting location updates")
        try {
            mFusedLocationClient?.requestLocationUpdates(mLocationRequest, getPendingIntent())
        } catch (e: SecurityException) {
            e.printStackTrace();
        }
    }

    fun removeLocationUpdates() {
        Log.i("Location", "Removing location updates")
        mFusedLocationClient?.removeLocationUpdates(getPendingIntent())
    }

    override fun onBackPressed() {

        if (supportFragmentManager.backStackEntryCount != 0) {
            super.onBackPressed()
            return
        }

        if (doubleBackToExitPressedOnce) {
            super.onBackPressed()
            finish()
            return
        }

        this.doubleBackToExitPressedOnce = true
        applicationContext.toast("Для выхода из приложения нажмите BACK еще раз")

        Handler().postDelayed({ doubleBackToExitPressedOnce = false }, 2000)
    }

    fun hardReplaceFragment(fragment: Fragment) {
        supportFragmentManager.popBackStack(null, FragmentManager.POP_BACK_STACK_INCLUSIVE)
        supportFragmentManager.beginTransaction()
            .replace(R.id.placeholder, fragment)
            .commit()
    }
    fun getLocationPermissions(){
        Dexter.withContext(this)
            .withPermissions(Manifest.permission.ACCESS_COARSE_LOCATION,  Manifest.permission.ACCESS_FINE_LOCATION)
            .withListener(object : MultiplePermissionsListener {

                override fun onPermissionRationaleShouldBeShown(permissions: MutableList<com.karumi.dexter.listener.PermissionRequest>?, token: PermissionToken?) {

                    val mDialog = Dialog(this@MainActivity, R.style.CustomDialog)
                    mDialog.setCancelable(true)
                    mDialog.setContentView(R.layout.dialog_with_action)

                    val type = Typeface.createFromAsset(this@MainActivity.assets, "font/roboto_regular.ttf")

                    val title = mDialog.find<TextView>(R.id.title)
                    val firstButtonText = mDialog.find<TextView>(R.id.firstButtonText)
                    val secondButtonText = mDialog.find<TextView>(R.id.secondButtonText)
                    secondButtonText.visibility = View.GONE
                    title.typeface = type
                    title.text = getString(R.string.geo_request_desc)
                    firstButtonText.typeface = type
                    firstButtonText.text = "Ок"

                    firstButtonText.setOnClickListener {
                        token?.continuePermissionRequest()
                        mDialog.dismiss()
                    }

                    mDialog.show()

                }

                override fun onPermissionsChecked(report: MultiplePermissionsReport?) {
                    if (report?.areAllPermissionsGranted()!!){
                        isGranted = true
                        requestLocationUpdates()

                    }
                }
            }).check()
    }


    private fun sendFirebaseToken() {
        val myToken = loginService.value.accessToken
        val fireToken = FirebaseInstanceId.getInstance().token

        firebaseDisposable?.dispose()
        firebaseDisposable = taxiService.value.sendFirebaseToken(myToken, fireToken!!)
            .subscribeOn(Schedulers.newThread())
            .observeOn(AndroidSchedulers.mainThread())
            .subscribe({ t: DataResponse ->

            }, { e ->
                e.printStackTrace()
                toast(e.localizedMessage)
            })
    }

    fun getDriverInfo() {
        infoDisposable = taxiService.value.getDriverInfo(loginService.value.accessToken)
            .subscribeOn(Schedulers.newThread())
            .observeOn(AndroidSchedulers.mainThread())
            .subscribe({ t: DriverModel ->
                progressView?.visibility = View.GONE
                ProfileRepository.instance?.setProfile(t)
                profile = t

                sendFirebaseToken()

                if (loginService.value.getSessionId() != t.sessionId) {
                    loginService.value.logout()
                    toast("Аккаунт был авторизирован на другом устройстве")
                    removeLocationUpdates()
                    hardReplaceFragment(LoginFragment())
                } else if (profile?.photocontrolStatus != DriverModel.PhotocontrolStatus.Accept && profile?.activeOrder == null) {
                    hardReplaceFragment(PhotocontrolFragment())
                } else {
                    hardReplaceFragment(MainFragment())
                }

            }, { e ->
                e.printStackTrace()
                progressView?.visibility = View.GONE
                val error: HttpException = e as HttpException
                if (error.response().code() == 401) {
                    loginService.value.logout()
                    hardReplaceFragment(LoginFragment())
                }
            })
    }

    private fun updateDriverProfile(showMainFragment: Boolean = false) {
        progressView?.visibility = View.VISIBLE
        infoDisposable?.dispose()
        infoDisposable = taxiService.value.getDriverInfo(loginService.value.accessToken)
            .subscribeOn(Schedulers.newThread())
            .observeOn(AndroidSchedulers.mainThread())
            .subscribe({ t: DriverModel ->
                progressView?.visibility = View.GONE
                ProfileRepository.instance?.setProfile(t)
                profile = t

                if (profile?.photocontrolStatus != DriverModel.PhotocontrolStatus.Accept && profile?.activeOrder == null) {
                    hardReplaceFragment(PhotocontrolFragment())
                } else if (showMainFragment) {
                    hardReplaceFragment(MainFragment())
                }
            }, { e ->
                e.printStackTrace()
                progressView?.visibility = View.GONE
            })
    }

    fun getOrders() {
        ordersListDisposable = taxiService.value.getOrders(loginService.value.accessToken)
            .subscribeOn(Schedulers.newThread())
            .observeOn(AndroidSchedulers.mainThread())
            .subscribe({ t: OrderResponse ->
                if (t.status == "success") {
                    OrdersRepository.instance?.setOrders(t.ordersOnMap!!)
                } else if (t.status == "error" && t.error == "no_access") {
                    toast("Доступ к заказам запрещён")
                }
            }, { e ->
                e.printStackTrace()
            })
    }
}
