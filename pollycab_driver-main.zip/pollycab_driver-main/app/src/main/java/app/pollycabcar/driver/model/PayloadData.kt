package app.pollycabcar.driver.model

import com.google.gson.annotations.SerializedName

class PayloadData {



    @SerializedName("action")
    var action: String? = null
}