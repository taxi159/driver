package app.pollycabcar.driver.model

import com.google.gson.annotations.SerializedName

class ActionHistoryModel {

    @SerializedName("created_at")
    var date: String? = null

    @SerializedName("description")
    var description: String? = null
}