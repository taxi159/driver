package app.pollycabcar.driver.fragment

import android.Manifest
import android.app.Activity
import android.app.Activity.RESULT_CANCELED
import android.app.Activity.RESULT_OK
import android.app.Dialog
import android.content.*
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.net.Uri
import android.os.*
import android.provider.MediaStore
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.lifecycle.Observer
import androidx.localbroadcastmanager.content.LocalBroadcastManager
import androidx.recyclerview.widget.DefaultItemAnimator
import androidx.recyclerview.widget.LinearLayoutManager
import android.text.Editable
import android.text.TextWatcher
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.lifecycle.MutableLiveData
import app.pollycabcar.driver.R
import app.pollycabcar.driver.adapter.AnswersAdapter
import app.pollycabcar.driver.model.*
import app.pollycabcar.driver.repo.NotificationRepository
import com.bumptech.glide.Glide
import com.bumptech.glide.load.DataSource
import com.bumptech.glide.load.engine.DiskCacheStrategy
import com.bumptech.glide.load.engine.GlideException
import com.bumptech.glide.request.RequestListener
import com.bumptech.glide.request.RequestOptions
import com.bumptech.glide.request.target.Target
import com.google.gson.Gson
import com.karumi.dexter.Dexter
import com.karumi.dexter.MultiplePermissionsReport
import com.karumi.dexter.PermissionToken
import com.karumi.dexter.listener.PermissionRequest
import com.karumi.dexter.listener.multi.MultiplePermissionsListener
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.disposables.Disposable
import io.reactivex.rxkotlin.zipWith
import io.reactivex.schedulers.Schedulers
import kotlinx.android.synthetic.main.chat_with_support_fragment.*
import kotlinx.android.synthetic.main.images_item.*
import okhttp3.MediaType
import okhttp3.MultipartBody
import okhttp3.RequestBody
import org.jetbrains.anko.find
import org.jetbrains.anko.support.v4.toast
import org.jetbrains.anko.textColor
import java.io.*
import java.util.*
import kotlinx.android.synthetic.main.support_details_fragment.*
import kotlinx.android.synthetic.main.support_details_fragment.addPhotoBtn
import kotlinx.android.synthetic.main.support_details_fragment.deleteImageBtn
import kotlinx.android.synthetic.main.support_details_fragment.messageText
import kotlinx.android.synthetic.main.support_details_fragment.sendMessageButton
import kotlinx.android.synthetic.main.support_details_fragment.toolbar
import org.jetbrains.anko.notificationManager
import java.text.SimpleDateFormat


class SupportDetailsFragment : BaseFragment() {

    private var reportInfoDisposable: Disposable? = null
    private var reportDisposable: Disposable? = null
    private var reportId: Int? = null
    private var isGranted: Boolean? = false

    private lateinit var adapter: AnswersAdapter

    private var mLastClickTime = 0L

    private var file: File? = null

    override fun onStart() {
        super.onStart()
        changeFont()

        reportId = arguments?.getInt(ARG_REPORT_ID)
        getReportInfo(reportId!!)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        retainInstance = true
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?,
                              savedInstanceState: Bundle?): View? {
        val view = inflater.inflate(R.layout.support_details_fragment, container, false)

        return view
    }

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)
        showPermissions()
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        subscribeToNotification()

        toolbar.setNavigationIcon(R.drawable.ic_arrow_back)
        toolbar.setNavigationOnClickListener {
            goBack()
        }

        adapter = AnswersAdapter {
            url -> showDialogMyImage(url)
        }
        rvChat.layoutManager = LinearLayoutManager(context, LinearLayoutManager.VERTICAL, false)
        rvChat.itemAnimator = DefaultItemAnimator()
        rvChat.adapter = adapter
        rvChat.isNestedScrollingEnabled = false

        sendMessageButton.setOnClickListener {

            if (SystemClock.elapsedRealtime() - mLastClickTime < 1000){
                return@setOnClickListener
            }
            mLastClickTime = SystemClock.elapsedRealtime()

            if (messageText.text.isEmpty()){
                toast("Введите текст сообщения")
                return@setOnClickListener
            } else {
                if (file != null ) {
                    sendReportWithImage(loginService.value.accessToken, reportId!!, messageText.text.toString().trim())
                } else {
                    sendReport(loginService.value.accessToken, reportId!!, messageText.text.toString().trim())
                }
            }
        }

        addPhotoBtn.setOnClickListener {
            showDialogAction("Добавить фото", "Галерея", "Камера", "add_photo")
        }

        deleteImageBtn.setOnClickListener {
            file = null

            imageMessageLayout.visibility = View.GONE
        }
    }

    private fun subscribeToNotification() {
        val liveData: MutableLiveData<MutableList<Notification>> =
                NotificationRepository.instance!!.notificationLiveData
        liveData.observe(this, Observer { t ->
            if (t.size == 0) {
                return@Observer
            }

            val notification: Notification = t[0]

            when (notification.action) {
                Notification.Action.NewAnswerReport -> {
                    getReportInfo(reportId!!)
                    NotificationRepository.instance?.removeNotification()
                }
                Notification.Action.ReportChecked -> {
                    getReportInfo(reportId!!)
                    NotificationRepository.instance?.removeNotification()
                }
            }
        })
    }

    private fun changeFont() {
        changeFontInEditTextView(messageText)
    }

    private fun getReportInfo(id: Int) {

        showProgress(true)

        reportInfoDisposable?.dispose()
        reportInfoDisposable = taxiService.value.getReportInfo(loginService.value.accessToken, id)
                .subscribeOn(Schedulers.newThread())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe({ t: ReportInfoResponse ->

                   if (t.report != null) {
                       val report = t.report!!

                       if (report.checked != 0)
                           sendLayout.visibility = View.GONE

                       toolbar.title = report.topic

                       val firstMessage = AnswerModel()
                       firstMessage.pathFile = report.patchFile
                       firstMessage.answer = report.text
                       firstMessage.accountType = report.accountType
                       firstMessage.createdAt = report.date
                       firstMessage.reportId = report.id

                       val messageList = (report.answer as ArrayList<AnswerModel>?)!!
                       messageList.add(0, firstMessage)

                       adapter.setList(messageList)

                       scroll.post {
                           scroll.fullScroll(View.FOCUS_DOWN)
                       }

                   }

                    showProgress(false)

                }, { e ->
                    e.printStackTrace()
                    toast(e.localizedMessage)
                    showProgress(false)
                })
    }

    private fun showDialogMyImage(url: String){
        context?.let {
            val mDialog = Dialog(it, R.style.CustomDialog)
            mDialog.setCancelable(true)
            mDialog.setContentView(R.layout.preview_fragment_layout)

            val imgPreview = mDialog.find<ImageView>(R.id.imagePreview)
            val progressView = mDialog.find<FrameLayout>(R.id.progressView)

            val requestOptions = RequestOptions().diskCacheStrategy(DiskCacheStrategy.ALL)

            if (url.isNotEmpty()) {

                progressView.visibility = View.VISIBLE

                Glide.with(context!!).load(url + "/performer?token=${loginService.value.accessToken}")
                        .apply(requestOptions)
                        .listener(object : RequestListener<Drawable> {

                            override fun onLoadFailed(e: GlideException?, model: Any?, target: Target<Drawable>?, isFirstResource: Boolean): Boolean {
                                progressView.visibility = View.GONE
                                return false
                            }

                            override fun onResourceReady(resource: Drawable, model: Any, target: Target<Drawable>?, dataSource: DataSource, isFirstResource: Boolean): Boolean {
                                progressView.visibility = View.GONE
                                return false
                            }
                        })
                        .into(imgPreview)
            }

            mDialog.show()
        }
    }

    private fun sendReport(token: String, repId: Int, text: String){
        showProgress(true)

        messageText.text.clear()
        messageText.clearFocus()
        hideKeyboardFrom(context!!, messageText)

        reportDisposable = taxiService.value.answerToReport(token, repId, text)
                .subscribeOn(Schedulers.newThread())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe({ t: DataResponse ->

                    if (t.status == "success"){
                        getReportInfo(reportId!!)
                    }

                }, { e ->
                    e.printStackTrace()
                    toast(e.localizedMessage)
                    showProgress(false)
                })
    }

    private fun sendReportWithImage(token: String, repId: Int, text: String) {
        showProgress(true)

        messageText.text.clear()
        messageText.clearFocus()
        hideKeyboardFrom(context!!, messageText)
        imageMessageLayout.visibility = View.GONE

        val body = MultipartBody.Part.createFormData("token", token)
        val body2 = MultipartBody.Part.createFormData("reports_id", repId.toString())
        val body3 = MultipartBody.Part.createFormData("answer", text)
        val requestFile = RequestBody.create(MediaType.parse("image/png"), file!!)
        val body4 = MultipartBody.Part.createFormData("file", "image.jpg", requestFile)

        reportDisposable = taxiService.value.answerToReportWithImage(body, body2, body3, body4)
                .subscribeOn(Schedulers.newThread())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe({ t: DataResponse ->

                    if (t.status == "success"){

                        if (file != null){

                            file?.deleteOnExit()
                            file = null
                        }

                        getReportInfo(reportId!!)
                    }

                }, { e ->
                    e.printStackTrace()
                    toast(e.localizedMessage)
                    showProgress(false)
                })
    }

    private fun showDialogAction(dialogTitle: String, firstBtn: String, secondBtn: String, action: String) {
        context?.let {
            val mDialog = Dialog(it, R.style.CustomDialog)
            mDialog.setCancelable(true)
            mDialog.setContentView(R.layout.dialog_with_action)

            val type = Typeface.createFromAsset(context?.assets, "font/roboto_regular.ttf")

            val title = mDialog.find<TextView>(R.id.title)
            val firstButtonText = mDialog?.find<TextView>(R.id.firstButtonText)
            val secondButtonText = mDialog?.find<TextView>(R.id.secondButtonText)

            title.typeface = type
            title.text = dialogTitle
            firstButtonText.typeface = type
            firstButtonText.text = firstBtn
            secondButtonText.typeface = type
            secondButtonText.text = secondBtn

            firstButtonText.setOnClickListener {
                mDialog.dismiss()

                val intent = Intent(Intent.ACTION_GET_CONTENT)
                intent.type = "image/jpeg"
                try {
                    startActivityForResult(intent, GALLERY_REQUEST_CODE)
                } catch (e: ActivityNotFoundException) {
                    e.printStackTrace()
                }
            }
            secondButtonText.setOnClickListener {
                if (!isGranted!!){
                    mDialog.dismiss()
                    showPermissions()
                } else {
                    mDialog.dismiss()

                    // Create an image file name
                    val timeStamp: String = SimpleDateFormat("yyyyMMdd_HHmmss").format(Date())
                    val storageDir: File? = mainActivity.getExternalFilesDir(Environment.DIRECTORY_PICTURES)
                    file = File.createTempFile(
                            "JPEG_${timeStamp}_", /* prefix */
                            ".jpg", /* suffix */
                            storageDir /* directory */
                    )

                    val imageUri = if(Build.VERSION.SDK_INT >= 24){
                        FileProvider.getUriForFile(context!!, "${context?.packageName}.fileprovider", file!!)
                    } else {
                        Uri.fromFile(file!!)
                    }

                    val intent = Intent(MediaStore.ACTION_IMAGE_CAPTURE)
                    intent.putExtra(MediaStore.EXTRA_OUTPUT, imageUri)
                    startActivityForResult(intent, REQUEST_IMAGE)
                }
            }

            mDialog.show()
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

        if (requestCode == GALLERY_REQUEST_CODE){

            if (resultCode == RESULT_OK) {
                try {
                    file = File(context!!.filesDir, "img" + Date().time)
                    val cr = mainActivity.contentResolver
                    val `is` = cr.openInputStream(data!!.data!!)
                    file!!.createNewFile()
                    `is`?.copyTo(file!!.outputStream())
                    file!!.absolutePath
                    showFile()
                } catch (e: IOException) {
                    e.printStackTrace()
                }
            }
        }

        if (requestCode == REQUEST_IMAGE && resultCode == Activity.RESULT_OK) {
            showFile()
        } else {
            file = null
        }
    }

    private fun showFile() {
        imageMessageLayout.visibility = View.VISIBLE
        Glide.with(context!!).load(file?.absolutePath).into(imageMessageView)
    }

    override fun onStop() {
        super.onStop()
        reportInfoDisposable?.dispose()
        reportDisposable?.dispose()
    }

    private fun showPermissions(){
        Dexter.withActivity(mainActivity)
                .withPermissions(Manifest.permission.CAMERA)
                .withListener(object : MultiplePermissionsListener {

                    override fun onPermissionRationaleShouldBeShown(permissions: MutableList<PermissionRequest>?, token: PermissionToken?) {
                        token?.continuePermissionRequest()
                    }

                    override fun onPermissionsChecked(report: MultiplePermissionsReport?) {
                        try {
                            isGranted = report!!.areAllPermissionsGranted()
                        } catch (e: IOException) {
                            toast("Could not create file!")
                        }
                    }
                }).check()
    }

    companion object {

        private val GALLERY_REQUEST_CODE = 100
        private val REQUEST_IMAGE = 200


        val ARG_REPORT_ID = "arg_report_id"

        fun newInstance(id: Int): SupportDetailsFragment {

            val args = Bundle()

            args.putInt(ARG_REPORT_ID, id)
            val fragment = SupportDetailsFragment()
            fragment.arguments = args
            return fragment
        }
    }

}
