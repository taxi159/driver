package app.pollycabcar.driver.model

import com.google.gson.annotations.SerializedName

class ActiveOrderModel {

    @SerializedName("id")
    var id: Int? = null

    @SerializedName("addresses")
    var addresses: ArrayList<String>? = null

    @SerializedName("order_date")
    var orderDate: String? = null

    @SerializedName("client_full_name")
    var clientName: String? = null

    @SerializedName("deadline")
    var deadline: String? = null

    @SerializedName("result_trip_cost")
    var tripCost: Int? = null

    @SerializedName("comment")
    var comment: String? = null
}
