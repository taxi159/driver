package app.pollycabcar.driver.model

class SupportThemeModel (var isActive: Boolean?, var date: String?, var topic: String?, var content: String?)