package app.pollycabcar.driver.model

import com.google.gson.annotations.SerializedName

class OrderInfoResponse {

    @SerializedName("status")
    var status: String? = null

    @SerializedName("error")
    var error: String? = null

    @SerializedName("hide_route_points")
    var hideRoutePoints: Boolean? = null

    @SerializedName("show_client_data_for_performer")
    var showClientDataForPerformer: Boolean? = null

    @SerializedName("order_info")
    var orderInfo: OrderInfoModel? = null
}