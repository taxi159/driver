package app.pollycabcar.driver.fragment

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Bundle
import androidx.localbroadcastmanager.content.LocalBroadcastManager
import androidx.recyclerview.widget.DefaultItemAnimator
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.lifecycle.Observer
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.lifecycle.MutableLiveData
import app.pollycabcar.driver.R
import app.pollycabcar.driver.adapter.ReportsAdapter
import app.pollycabcar.driver.model.Notification
import app.pollycabcar.driver.model.ReportsResponse
import app.pollycabcar.driver.repo.NotificationRepository
import com.google.gson.Gson
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.disposables.Disposable
import io.reactivex.schedulers.Schedulers
import kotlinx.android.synthetic.main.support_fragment.*
import org.jetbrains.anko.notificationManager
import org.jetbrains.anko.support.v4.toast


class SupportFragment : BaseFragment() {

    private lateinit var adapter: ReportsAdapter
    private var reportsDisposable: Disposable? = null

    override fun onStart() {
        super.onStart()
        getReportsList()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        retainInstance = true
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?,
                              savedInstanceState: Bundle?): View? {
        val view = inflater.inflate(R.layout.support_fragment, container, false)

        return view
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        subscribeToNotification()

        toolbar.setNavigationIcon(R.drawable.ic_arrow_back)
        toolbar.setNavigationOnClickListener {
            goBack()
        }

        newMessageToSupportButton.setOnClickListener {
            replaceFragment(NewSupportReportFragment(), true)
        }

        adapter = ReportsAdapter{ id ->
            replaceFragment(SupportDetailsFragment.newInstance(id), true)
        }
        rvSupportThemes.layoutManager = LinearLayoutManager(context, LinearLayoutManager.VERTICAL, false)
        rvSupportThemes.itemAnimator = DefaultItemAnimator()
        rvSupportThemes.adapter = adapter
        rvSupportThemes.isNestedScrollingEnabled = false
    }

    private fun subscribeToNotification() {
        val liveData: MutableLiveData<MutableList<Notification>> =
                NotificationRepository.instance!!.notificationLiveData
        liveData.observe(this, Observer { t ->
            if (t.size == 0) {
                return@Observer
            }

            val notification: Notification = t[0]

            when (notification.action) {
                Notification.Action.ReportChecked -> {
                    getReportsList()
                    NotificationRepository.instance?.removeNotification()
                }
            }
        })
    }

    private fun getReportsList(){
        showProgress(true)

        reportsDisposable = taxiService.value.getReports(loginService.value.accessToken)
                .subscribeOn(Schedulers.newThread())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe({ t: ReportsResponse ->

                    if (t.reports!!.isEmpty()){
                        reportsNotFoundText.visibility = View.VISIBLE
                    } else {
                        adapter.setList(t.reports!!)
                    }
                    showProgress(false)
                }, { e ->
                    e.printStackTrace()
                    toast(e.localizedMessage)
                    showProgress(false)
                })
    }

    override fun onStop() {
        super.onStop()
        reportsDisposable?.dispose()
    }

}
