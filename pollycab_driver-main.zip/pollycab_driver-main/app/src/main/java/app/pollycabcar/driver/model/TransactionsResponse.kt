package app.pollycabcar.driver.model

import com.google.gson.annotations.SerializedName

class TransactionsResponse {

    @SerializedName("status")
    var status: String? = null

    @SerializedName("error")
    var error: String? = null

    @SerializedName("payment_service")
    var paymentService: String? = null

    @SerializedName("balance")
    var balance: Int? = null

    @SerializedName("transactions")
    var transactions: List<Transaction>? = null
}