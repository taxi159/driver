package app.pollycabcar.driver.adapter

import app.pollycabcar.driver.model.WeekDay
import android.annotation.SuppressLint
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import app.pollycabcar.driver.adapter.WeekDaysAdapter.WeekDayHolder
import app.pollycabcar.driver.R
import app.pollycabcar.driver.fragment.WeekEarnFragment
import app.pollycabcar.driver.model.DriverModel
import app.pollycabcar.driver.util.DateFormatter
import java.util.*

class WeekDaysAdapter(private val list: List<WeekDay>, private val callback: ((day: WeekDay) -> Unit)? = null) : RecyclerView.Adapter<WeekDayHolder>() {
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): WeekDayHolder {
        val v = LayoutInflater.from(parent.context)
                .inflate(R.layout.income_of_day_item, parent, false)
        return WeekDayHolder(v)
    }

    override fun onBindViewHolder(holder: WeekDayHolder, position: Int) {
        val day: WeekDay = list[position]
        holder.subtitle.text = "${day.orderCount} поездок"
        holder.value.text = "${day.total} \u20BD"
        val date: Date? = DateFormatter.getDateFromStringUTCWithoutTime(day.date!!)
        val formattedDate: String = DateFormatter.getStringDdMmmmEeFromDate(date!!)
        holder.title.text = formattedDate
        holder.itemView.setOnClickListener { callback?.invoke(day) }
    }

    override fun getItemCount(): Int {
        return list.size
    }

    inner class WeekDayHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        var title: TextView
        var subtitle: TextView
        var value: TextView

        init {
            title = itemView.findViewById(R.id.title)
            subtitle = itemView.findViewById(R.id.subtitle)
            value = itemView.findViewById(R.id.value)
            subtitle.visibility = View.VISIBLE
        }
    }
}