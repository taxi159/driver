package app.pollycabcar.driver.fragment

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.Observer
import androidx.localbroadcastmanager.content.LocalBroadcastManager
import androidx.recyclerview.widget.DefaultItemAnimator
import androidx.recyclerview.widget.LinearLayoutManager
import app.pollycabcar.driver.R
import app.pollycabcar.driver.adapter.OrdersAdapter
import app.pollycabcar.driver.adapter.ServicesAdapter
import app.pollycabcar.driver.model.DriverModel
import app.pollycabcar.driver.model.Notification
import app.pollycabcar.driver.model.OrderResponse
import app.pollycabcar.driver.repo.NotificationRepository
import app.pollycabcar.driver.repo.OrdersRepository
import app.pollycabcar.driver.repo.ProfileRepository
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import com.pixplicity.easyprefs.library.Prefs
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.disposables.Disposable
import io.reactivex.schedulers.Schedulers
import kotlinx.android.synthetic.main.fragment_main.*
import kotlinx.android.synthetic.main.orders_fragment.*
import kotlinx.android.synthetic.main.orders_fragment.toolbar
import org.jetbrains.anko.notificationManager
import org.jetbrains.anko.support.v4.toast
import java.text.SimpleDateFormat
import java.util.*


class OrdersFragment : BaseFragment() {

    private var profile: DriverModel? = null
    private lateinit var adapter: ServicesAdapter
    private lateinit var ordersAdapter: OrdersAdapter
    private var orderDisposable: Disposable? = null
    private var orderTypeDisposable: Disposable? = null
    private var ordersListDisposable: Disposable? = null
    private var statusDisposable: Disposable? = null

    var fragment: Fragment? = null
    private var disposable: Disposable? = null

    override fun onStart() {
        super.onStart()
        changeFonts()
        getOrders()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        retainInstance = true
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        return inflater.inflate(R.layout.orders_fragment, container, false)
    }

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        subscribeToProfile()
        subscribeToNotification()

        toolbar.setNavigationIcon(R.drawable.ic_arrow_back)
        toolbar.setNavigationOnClickListener {
            mainActivity.hardReplaceFragment(MainFragment())
        }

        ordersAdapter = OrdersAdapter{
            if(profile?.status == 1)
                replaceFragment(OrderInfoFragment.newInstance(it.toString(), -1))
            else
                toast("Необходимо выйти на линию")
        }
    }

    private fun subscribeToProfile() {
        val liveData: MutableLiveData<DriverModel> =
                ProfileRepository.instance!!.profileLiveData
        liveData.observe(this, Observer { t ->
            profile = t
        })
    }

    private fun subscribeToNotification() {
        val liveData: MutableLiveData<MutableList<Notification>> =
                NotificationRepository.instance!!.notificationLiveData
        liveData.observe(this, Observer { t ->
            if (t.size == 0) {
                return@Observer
            }

            val notification: Notification = t[0]

            when (notification.action) {
                Notification.Action.NewOrder -> {
                    getOrders()
                    NotificationRepository.instance?.removeNotification()
                }
                Notification.Action.OrderCanceled -> {
                    getOrders()
                    NotificationRepository.instance?.removeNotification()
                }
            }
        })
    }

    private fun getOrders(){
        showProgress(true)

        ordersListDisposable = taxiService.value.getOrders(loginService.value.accessToken)

                .subscribeOn(Schedulers.newThread())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe({ t: OrderResponse ->

                    if (t.status == "success") {

                        if (t.ordersOnMap != null) {

                            val list = t.ordersOnMap
                            OrdersRepository.instance?.setOrders(list!!)

                            list?.sortWith(Comparator { o1, o2 ->
                                o1.distanceToOrder!!.compareTo(o2.distanceToOrder!!)
                            })

                            if(t.positionIsActual == false) {
                                positionNotActualText.visibility = View.VISIBLE
                            } else if(list!!.isEmpty()) {
                                ordersNotFoundText.visibility = View.VISIBLE
                            }

                            for (i in 0 until list!!.size) {
                                if (list[i].status == 0){
                                    ordersAdapter.setList(list)
                                    ordersAdapter.hideEndRoutePoint(t.hideRoutePoints!!)

                                    rvOrders.layoutManager = LinearLayoutManager(context, LinearLayoutManager.VERTICAL, false)
                                    rvOrders.itemAnimator = DefaultItemAnimator()
                                    rvOrders.adapter = ordersAdapter
                                    rvOrders.isNestedScrollingEnabled = false
                                }
                            }
                        }

                    } else if (t.status == "error" && t.error == "no_access") {
                        toast("Доступ запрещён")
                        mainActivity.hardReplaceFragment(MainFragment())
                    }

                    showProgress(false)

                }, { e ->
                    e.printStackTrace()
                    toast(e.localizedMessage)
                    showProgress(false)
                })
    }

    private fun changeFonts(){
        changeFontInTextViewBold(ordersNotFoundText)
        changeFontInTextViewBold(searchOrdersText)
        changeFontInTextViewBold(positionNotActualText)
    }

    override fun onStop() {
        super.onStop()
        orderTypeDisposable?.dispose()
        orderDisposable?.dispose()
        ordersListDisposable?.dispose()
        statusDisposable?.dispose()
    }

    override fun onDestroy() {
        super.onDestroy()
        disposable?.dispose()
    }

    companion object {
        var isSetTarif: Boolean = false
    }
}
