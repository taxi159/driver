package app.pollycabcar.driver.model

import com.google.gson.annotations.SerializedName

class ReportsResponse {
    @SerializedName("reports")
    var reports: List<Report>? = null
}