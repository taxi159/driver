package app.pollycabcar.driver.network

import android.content.Context

import java.util.concurrent.TimeUnit

import okhttp3.OkHttpClient
import retrofit2.Retrofit
import retrofit2.adapter.rxjava2.RxJava2CallAdapterFactory
import retrofit2.converter.gson.GsonConverterFactory

object RetrofitFactory {
//    private val interceptorOb = HttpLoggingInterceptor()
//    private val interceptor: HttpLoggingInterceptor
//        get() {
//            interceptorOb.level = HttpLoggingInterceptor.Level.BODY
//            return interceptorOb
//        }


    private val basicOkHttpClientBuilder: OkHttpClient.Builder
        get() = OkHttpClient.Builder()
            .connectTimeout(45, TimeUnit.SECONDS)
            .writeTimeout(30, TimeUnit.SECONDS)
            .readTimeout(30, TimeUnit.SECONDS)
//            .addInterceptor(interceptor)

    fun getForLogin(baseUrl: String): Retrofit {
        return Retrofit.Builder()
            .client(basicOkHttpClientBuilder.build())
            .baseUrl(baseUrl)
            .addConverterFactory(GsonConverterFactory.create())
            .addCallAdapterFactory(RxJava2CallAdapterFactory.create())
            .build()
    }

    fun getAuthorized(baseUrl: String, loginService: LoginService, context: Context): Retrofit {
        val okHttpClientBuilder = basicOkHttpClientBuilder
        okHttpClientBuilder.addNetworkInterceptor(AuthOkHttpInterceptor(loginService.accessToken))

//        okHttpClientBuilder.addNetworkInterceptor(TokenInterceptor(context, loginService))

        return Retrofit.Builder()
            .client(okHttpClientBuilder.build())
            .baseUrl(baseUrl)
            .addConverterFactory(GsonConverterFactory.create())
            .addCallAdapterFactory(RxJava2CallAdapterFactory.create())
            .build()
    }
}
