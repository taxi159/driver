package app.pollycabcar.driver.model

import com.google.gson.annotations.SerializedName

class WeekDay {

    @SerializedName("date")
    var date: String? = null

    @SerializedName("total")
    var total: String? = null

    @SerializedName("total_fee")
    var totalFee: String? = null

    @SerializedName("order_count")
    var orderCount: Int = 0
}