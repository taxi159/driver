package app.pollycabcar.driver.fragment

import android.app.Dialog
import android.graphics.Typeface
import android.os.Bundle
import androidx.recyclerview.widget.DefaultItemAnimator
import androidx.recyclerview.widget.LinearLayoutManager
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.TextView
import app.pollycabcar.driver.R
import app.pollycabcar.driver.adapter.TransactionsAdapter
import app.pollycabcar.driver.model.InitPaymentResponse
import app.pollycabcar.driver.model.InitPayoutResponse
import app.pollycabcar.driver.model.TransactionsResponse
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.disposables.Disposable
import io.reactivex.schedulers.Schedulers
import kotlinx.android.synthetic.main.transactions_fragment.*
import org.jetbrains.anko.find
import org.jetbrains.anko.support.v4.longToast
import org.jetbrains.anko.support.v4.toast
import java.util.regex.Pattern


class TransactionsFragment : BaseFragment() {

    private lateinit var transactionsAdapter: TransactionsAdapter
    private var disposableTransactions: Disposable? = null
    private var infoDisposable: Disposable? = null



    override fun onStart() {
        super.onStart()
        changeFont()

        getLastTransactions()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        retainInstance = true
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?,
                              savedInstanceState: Bundle?): View? {
        val view = inflater.inflate(R.layout.transactions_fragment, container, false)

        return view
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        toolbar.setNavigationIcon(R.drawable.ic_arrow_back)
        toolbar.setNavigationOnClickListener {
            goBack()
        }

        topUpBalanceBtn.setOnClickListener {
            showDialogForIncreaseBalance()
        }

        withdrawCashBtn.setOnClickListener {
            longToast("Активировано событие 'Вывести' ")
            showDialogForPayout()
        }

        transactionsAdapter = TransactionsAdapter()
        rvTransactions.layoutManager = LinearLayoutManager(context, LinearLayoutManager.VERTICAL, false)
        rvTransactions.itemAnimator = DefaultItemAnimator()
        rvTransactions.adapter = transactionsAdapter
        rvTransactions.isNestedScrollingEnabled = false
    }

    private fun showDialogForIncreaseBalance(){

        val dialog = Dialog(context!!, R.style.CustomDialog)
        dialog.setCancelable(false)
        dialog.setContentView(R.layout.dialog_increase_balance)

        val type = Typeface.createFromAsset(context?.assets, "font/roboto_regular.ttf")
        val typeBold = Typeface.createFromAsset(context?.assets, "font/roboto_medium.ttf")
        val title = dialog.find<TextView>(R.id.title)
        val textAmount = dialog.find<EditText>(R.id.textAmount)
        title.typeface = typeBold
        textAmount.typeface = type
        val firstButtonText = dialog.find<TextView>(R.id.firstButtonText)
        firstButtonText.typeface = type

        val secondButtonText = dialog.find<TextView>(R.id.secondButtonText)
        secondButtonText.typeface = typeBold

        firstButtonText.setOnClickListener {
            dialog.dismiss()
        }

        secondButtonText.setOnClickListener {
            dialog.dismiss()

            val value = textAmount.text.toString().trim()

            if (Pattern.matches("\\d+", value)){
                showProgress(true)
                infoDisposable = taxiService.value.createPayment(loginService.value.accessToken, value.toInt())
                        .subscribeOn(Schedulers.newThread())
                        .observeOn(AndroidSchedulers.mainThread())
                        .subscribe({ t: InitPaymentResponse ->

                            if (t.status == "success"){

                                if (t.formUrl != null) {
                                    replaceFragment(WebViewFragment.newInstance(t.formUrl!!))
                                }
                            }
                            showProgress(false)

                        }, { e ->
                            e.printStackTrace()
                            showProgress(false)
                        })
            } else {
                toast("Допустимо только целое значение")
                return@setOnClickListener
            }
        }

        dialog.show()
    }

    private fun showDialogForPayout(){

        val dialog = Dialog(context!!, R.style.CustomDialog)
        dialog.setCancelable(false)
        dialog.setContentView(R.layout.dialog_increase_balance)

        val type = Typeface.createFromAsset(context?.assets, "font/roboto_regular.ttf")
        val typeBold = Typeface.createFromAsset(context?.assets, "font/roboto_medium.ttf")
        val title = dialog.find<TextView>(R.id.title)
        val textAmount = dialog.find<EditText>(R.id.textAmount)
        title.typeface = typeBold
        title.text = "Вывод средств на банковскую карту"
        textAmount.typeface = type
        val firstButtonText = dialog.find<TextView>(R.id.firstButtonText)
        firstButtonText.typeface = type

        val secondButtonText = dialog.find<TextView>(R.id.secondButtonText)
        secondButtonText.typeface = typeBold
        secondButtonText.text = "ВЫВЕСТИ"
        firstButtonText.setOnClickListener {
            dialog.dismiss()
        }

        secondButtonText.setOnClickListener {
            dialog.dismiss()

            val value = textAmount.text.toString().trim()

            if (Pattern.matches("\\d+", value)){
                showProgress(true)
                infoDisposable = taxiService.value.createPayout(loginService.value.accessToken, value.toInt())
                        .subscribeOn(Schedulers.newThread())
                        .observeOn(AndroidSchedulers.mainThread())
                        .subscribe({ t: InitPayoutResponse ->

                            if (t.status == "success"){

                                if (t.descrError != null) {
                                    toast("Success")
                                }
                            }
                            if (t.descrError != null) {
                                toast(t.descrError!!)
                            }
                            showProgress(false)

                        }, { e ->
                            e.printStackTrace()
                            showProgress(false)
                            toast(e.localizedMessage)
                        })
            } else {
                toast("Допустимо только целое значение")
                return@setOnClickListener
            }

        }

        dialog.show()
    }

    private fun getLastTransactions(){

        showProgress(true)

        disposableTransactions = taxiService.value.getTransactions(loginService.value.accessToken)
                .subscribeOn(Schedulers.newThread())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe({ t: TransactionsResponse ->

                    if (t.status == "success"){
                        amountBalanceText.text = t.balance.toString() + " " + getString(R.string.currency)
                        transactionsAdapter.setList(t.transactions!!)
                        if(!t.paymentService.isNullOrBlank()) topUpBalanceBtn.visibility = View.VISIBLE
                    } else if(t.status == "error" && t.error == "no_access") {
                        toast("Доступ запрещён")
                        goBack()
                    }

                    showProgress(false)
                }, { e ->
                    e.printStackTrace()
                    toast(e.localizedMessage)
                    showProgress(false)
                })
    }

    override fun onStop() {
        super.onStop()
        disposableTransactions?.dispose()
        infoDisposable?.dispose()
    }

    private fun changeFont() {
        changeFontInTextView(balanceText)
        changeFontInTextViewBold(amountBalanceText)
        changeFontInTextViewBold(topUpBalanceText)
    }
}
