package app.pollycabcar.driver.model

import com.google.gson.annotations.SerializedName

class InitPayoutResponse {
    @SerializedName("status")
    var status: String? = null

    @SerializedName("error")
    var descrError: String? = null
}