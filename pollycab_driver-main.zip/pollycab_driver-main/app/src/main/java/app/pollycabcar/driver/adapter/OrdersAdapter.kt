package app.pollycabcar.driver.adapter


import android.graphics.Typeface
import androidx.recyclerview.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView
import app.pollycabcar.driver.R
import app.pollycabcar.driver.model.OrderModel
import kotlinx.android.synthetic.main.trip_address.view.*
import org.jetbrains.anko.find
import java.text.SimpleDateFormat
import java.util.*
import kotlin.collections.ArrayList

class OrdersAdapter(private val callback: ((id: Int) -> Unit)? = null) : RecyclerView.Adapter<OrdersAdapter.MyViewHolder>() {

    private var orderList: ArrayList<OrderModel> = arrayListOf()
    private var hideEndRoutePoint: Boolean = false

    fun setList(list: ArrayList<OrderModel>) {
        orderList = list
        notifyDataSetChanged()
    }

    fun hideEndRoutePoint(hide: Boolean) {
        hideEndRoutePoint = hide
    }

    inner class MyViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        var tvOrderId: TextView = view.find(R.id.tv_order_id)
        var tvPrice: TextView = view.find(R.id.tv_price)
        var tvDateTime: TextView = view.find(R.id.tv_date_time)
        val tvAddressStart: TextView  = view.find(R.id.tv_address_start)
        val dividerAddressStart: View = view.find(R.id.divider_address_start)
        val addressesContainer: LinearLayout  = view.find(R.id.addresses_container)
        var tvPaymentType: TextView = view.find(R.id.tv_payment_type)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyViewHolder {
        val itemView = LayoutInflater.from(parent.context)
                .inflate(R.layout.order_item, parent, false)

        return MyViewHolder(itemView)
    }

    override fun onBindViewHolder(holder: MyViewHolder, position: Int) {
        val orderItem = orderList[position]

        val type = Typeface.createFromAsset(holder.itemView.context?.assets, "font/roboto_regular.ttf")
        val typeBold = Typeface.createFromAsset(holder.itemView.context?.assets, "font/roboto_medium.ttf")

        holder.tvOrderId.text = "№" + orderItem.orderId
        holder.tvPrice.text = orderItem.resultTripCost.toString() + " \u20BD"

        var format: SimpleDateFormat = SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
        val date: Date = format.parse(orderItem.deadline)
        format = SimpleDateFormat("E, d MMM HH:mm", Locale("ru"))
        val deadline: String = format.format(date)
        holder.tvDateTime.text = deadline

        when(orderItem.paymentType) {
            0 -> holder.tvPaymentType.text = "наличными"
            1 -> holder.tvPaymentType.text = "безналичный"
            2 -> holder.tvPaymentType.text = "вирт. счёт"
            3 -> holder.tvPaymentType.text = "корпоративный"
        }

        holder.addressesContainer.removeAllViews()

        if (hideEndRoutePoint) {
            holder.dividerAddressStart.visibility = View.GONE
        } else {
            holder.dividerAddressStart.visibility = View.VISIBLE
        }

        orderItem.geoPoints?.forEachIndexed { index, geoPoint ->
            if (index == 0) {
                holder.tvAddressStart.text = orderItem.addresses?.get(0)

                if (orderItem.geoPoints?.size == 1) {
                    val view = LayoutInflater.from(holder.itemView.context)
                            .inflate(R.layout.trip_address, holder.addressesContainer, false)

                    val address = view.tv_address
                    address.text = "По указанию"

                    val divider = view.divider
                    divider.visibility = View.GONE

                    holder.addressesContainer.addView(view)
                }
            } else if (!hideEndRoutePoint) {
                val view = LayoutInflater.from(holder.itemView.context)
                        .inflate(R.layout.trip_address, holder.addressesContainer, false)

                val address = view.tv_address
                address.text = orderItem.addresses?.get(index)

                if (index == orderItem.geoPoints?.size!! - 1) {
                    val divider = view.divider
                    divider.visibility = View.GONE
                }

                holder.addressesContainer.addView(view)
            }
        }

        holder.itemView.setOnClickListener {
            callback?.invoke(orderItem.orderId!!)
        }

        holder.tvOrderId.typeface = type
        holder.tvPrice.typeface = typeBold
        holder.tvDateTime.typeface = type
        holder.tvPaymentType.typeface = type
    }

    override fun getItemCount(): Int {
        return orderList.size
    }
}
