package app.pollycabcar.driver.fragment

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.lifecycle.MutableLiveData
import app.pollycabcar.driver.R
import app.pollycabcar.driver.model.DriverModel
import app.pollycabcar.driver.model.EarnModel
import app.pollycabcar.driver.model.EarnResponse
import app.pollycabcar.driver.util.DateFormatter
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.disposables.Disposable
import io.reactivex.schedulers.Schedulers
import kotlinx.android.synthetic.main.fragment_finance.*
import kotlinx.android.synthetic.main.transactions_fragment.toolbar
import org.jetbrains.anko.support.v4.toast
import java.util.*


class FinanceFragment : BaseFragment(), View.OnClickListener {

    private var infoDisposable: Disposable? = null
    private var earn: EarnModel? = null

    //live data
    var liveData: MutableLiveData<EarnModel> = MutableLiveData<EarnModel>()

    private fun setLiveData(weekEarn: EarnModel) {
        liveData.postValue(weekEarn)
    }

    override fun onStart() {
        super.onStart()
        getDriverInfo()
        getEarn()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        retainInstance = true
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?,
                              savedInstanceState: Bundle?): View? {
        val view = inflater.inflate(R.layout.fragment_finance, container, false)

        return view
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        sv_income_of_week?.setTitle("ДОХОД НА ЭТОЙ НЕДЕЛЕ:")
        sv_rides_count?.setTitle("ПОЕЗДКИ:")
        sv_balance?.setTitle("БАЛАНС:")
        sv_current_rate?.setTitle("СМЕНА ДЕЙСТВУЕТ ДО")

        btn_buy_work.setOnClickListener(this)
        sv_balance?.setOnClickListener(this)
        sv_rides_count?.setOnClickListener(this)
        sv_income_of_week?.setOnClickListener(this)

        sv_current_rate?.setVisibleArrow(false)
        sv_rides_count?.showProgressBar()
        sv_income_of_week?.showProgressBar()
        sv_balance?.showProgressBar()
        sv_current_rate?.showProgressBar()

        toolbar.setNavigationIcon(R.drawable.ic_arrow_back)
        toolbar.setNavigationOnClickListener {
            goBack()
        }
    }

    override fun onStop() {
        super.onStop()
        infoDisposable?.dispose()
    }

    private fun getDriverInfo(){
        infoDisposable = taxiService.value.getDriverInfo(loginService.value.accessToken)
                .subscribeOn(Schedulers.newThread())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe({ t: DriverModel ->
                    sv_balance?.setCount("${t.balance} \u20BD")

                    if (t.workShiftExpiresAt !== 0) {
                        val cal = Calendar.getInstance()
                        cal.timeInMillis = t.workShiftExpiresAt.toLong() * 1000
                        sv_current_rate?.setCount(DateFormatter.getStringDdMmmmHHmmFromDate(cal.time))
                        sv_current_rate?.visibility = View.VISIBLE
                    }
                }, { e ->
                    e.printStackTrace()
                    toast(e.localizedMessage)
                    showProgress(false)
                })

    }

    private fun getEarn(){
        showProgress(true)

        val endDate = Calendar.getInstance().time
        val endDateString = DateFormatter.getStringUTCFromDate(endDate)
        val startDate = DateFormatter.datePlusDays(endDate, -7)
        val startDateString = DateFormatter.getStringUTCFromDate(startDate)

        infoDisposable = taxiService.value.getEarn(loginService.value.accessToken, startDateString, endDateString)
                .subscribeOn(Schedulers.newThread())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe({ t: EarnResponse ->
                    earn = t.data
                    sv_income_of_week?.setCount(t.data?.total + " \u20BD")
                    sv_rides_count?.setCount(t.data?.orderCount!!)
                    showProgress(false)
                }, { e ->
                    e.printStackTrace()
                    toast(e.localizedMessage)
                    showProgress(false)
                })

    }

    override fun onClick(v: View?) {
        when (v?.id) {
            R.id.sv_rides_count -> { replaceFragment(RidesFragment()) }

            R.id.btn_buy_work -> { replaceFragment(WorkShiftsFragment()) }

            R.id.sv_balance -> { replaceFragment(TransactionsFragment()) }

            R.id.sv_income_of_week -> { replaceFragment(WeekEarnFragment(earn!!)) }
        }
    }
}
