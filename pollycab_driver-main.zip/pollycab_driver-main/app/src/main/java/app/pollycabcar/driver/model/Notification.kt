package app.pollycabcar.driver.model

import com.google.gson.annotations.SerializedName

class Notification {

    @SerializedName("action")
    var action: String? = null

    @SerializedName("orderId")
    var orderId: Int? = null

    @SerializedName("title")
    var title: String? = null

    @SerializedName("orderTimeout")
    var orderTimeout: Int? = 0

    @SerializedName("orderDistributionTime")
    var orderDistributionTime: Int? = 0

    @SerializedName("message")
    var message: String? = null

    object Action {
        const val NewOrder = "newOrder" //Новый заказ
        const val OfflineNewOrder = "offlineNewOrder" //Оффлайн новый заказ
        const val OrderCanceled = "orderCanceled" //Заказ отменён
        const val AssignedOnOrder = "assignedOnOrder" //Назначен на заказ
        const val RemovedFromOrder = "removedFromOrder" //Снят с заказа
        const val PerformerStatusChanged = "performerStatusChanged" //Смена статуса водителя
        const val NewAnswerReport = "newAnswerReport" //Ответ от поддержки
        const val ReportChecked = "reportChecked" //Обращение в поддержку закрыто
    }
}