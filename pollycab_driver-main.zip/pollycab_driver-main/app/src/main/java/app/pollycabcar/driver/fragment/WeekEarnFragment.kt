package app.pollycabcar.driver.fragment

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.LinearLayoutManager
import app.pollycabcar.driver.R
import app.pollycabcar.driver.adapter.WeekDaysAdapter
import app.pollycabcar.driver.fragment.dialogs.DialogChoose
import app.pollycabcar.driver.model.EarnModel
import app.pollycabcar.driver.model.WeekDay
import app.pollycabcar.driver.model.WeekEarn
import app.pollycabcar.driver.util.DateFormatter
import app.pollycabcar.driver.view.Chart
import com.github.mikephil.charting.charts.BarChart
import kotlinx.android.synthetic.main.fragment_week_earn.*
import java.util.*

class WeekEarnFragment(private val earn: EarnModel) : BaseFragment(), View.OnClickListener {
    private var weekEarns: MutableList<WeekEarn>? = null
    private var currentWeek: WeekEarn? = null
    private var chart: Chart? = null

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        val view = inflater.inflate(R.layout.fragment_week_earn, container, false)
        return view
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        toolbar.setNavigationIcon(R.drawable.ic_arrow_back)
        toolbar.setNavigationOnClickListener {
            goBack()
        }

        context?.let {
            chart = Chart((view.findViewById<View>(R.id.chart) as BarChart), it, true)
        }

        imv_choose_week.setOnClickListener(this)

        rv_income_of_day.layoutManager = LinearLayoutManager(context, LinearLayoutManager.VERTICAL, false)

        weekEarns = ArrayList<WeekEarn>()
        weekEarns!!.addAll(earn.weeks!!)

        if (weekEarns?.size != 0) {
            currentWeek = weekEarns!![weekEarns!!.size - 1]
        }

        showCurrentWeek()
    }

    private fun showCurrentWeek() {
        if (currentWeek != null) {
            tv_income_of_week.text = "${currentWeek?.total} \u20BD"
            tv_rides_count.text = currentWeek?.orderCount.toString()
            chart?.setData(currentWeek?.weekDays!!)
            val date: Date? = DateFormatter.getDateFromStringUTCWithoutTime(currentWeek?.start!!)
            date?.let { initWeek(it) }
            initDaysAdapter(currentWeek?.weekDays!!)
        } else {
            tv_income_of_week.text = "0 \u20BD"
            tv_rides_count.text = "0"
        }
    }

    private fun initWeek(date: Date) {
        val calendar = getCalendarDayFromDate(date)
        for (i in 0..6) {
            val child1 = ll_days_numbers.getChildAt(i) as TextView
            child1.text = calendar[Calendar.DAY_OF_MONTH].toString()
            val child2 = ll_days_of_week.getChildAt(i) as TextView
            child2.text = getDayOfWeekFromDate(calendar)
            if (getDayOfWeekFromDate(calendar) == "сб" || getDayOfWeekFromDate(calendar) == "вс") {
                child2.setTextColor(resources.getColor(R.color.red))
            }
            calendar.add(Calendar.DATE, 1)
        }
    }

    private fun getCalendarDayFromDate(date: Date): Calendar {
        val calendar = Calendar.getInstance()
        calendar.time = date
        return calendar
    }

    private fun getDayOfWeekFromDate(calendar: Calendar): String {
        val day = calendar[Calendar.DAY_OF_WEEK]
        return when (day) {
            Calendar.MONDAY -> "пн"
            Calendar.TUESDAY -> "вт"
            Calendar.WEDNESDAY -> "ср"
            Calendar.THURSDAY -> "чт"
            Calendar.FRIDAY -> "пт"
            Calendar.SATURDAY -> "сб"
            Calendar.SUNDAY -> "вс"
            else -> "xз"
        }
    }

    private fun initDaysAdapter(weekDays: List<WeekDay>) {
        val adapter = WeekDaysAdapter(weekDays) {}
        rv_income_of_day.adapter = adapter
    }

    override fun onClick(v: View) {
        when (v.id) {
            R.id.imv_choose_week -> {
                val dialog: DialogChoose = DialogChoose("Выберите неделю") { it ->
                    var selected = it.substring(0, it.indexOf('-'))
                    selected = selected.trim { it <= ' ' }
                    for (weekEarn in weekEarns!!) {
                        val weekStart: Date? = DateFormatter.getDateFromStringUTCWithoutTime(weekEarn.start!!)
                        if (weekStart != null) {
                            val weekStartString: String = DateFormatter.getStringDdMmmmEromDate(weekStart)
                            if (weekStartString == selected) {
                                currentWeek = weekEarn
                            }
                        }
                    }
                    chart?.setData(currentWeek?.weekDays!!)
                    showCurrentWeek()
                }
                val weeksString: MutableList<String> = ArrayList()
                for (weekEarn in weekEarns!!) {
                    val startDate: Date? = DateFormatter.getDateFromStringUTCWithoutTime(weekEarn.start!!)
                    val endDate: Date = DateFormatter.datePlusDays(startDate!!, 6)
                    val startDateString: String = DateFormatter.getStringDdMmmmEromDate(startDate)
                    val endDateString: String = DateFormatter.getStringDdMmmmEromDate(endDate)
                    weeksString.add("$startDateString - $endDateString")
                }
                dialog.setDataList(weeksString)
                dialog.show(fragmentManager, "dialog")
            }
        }
    }
}