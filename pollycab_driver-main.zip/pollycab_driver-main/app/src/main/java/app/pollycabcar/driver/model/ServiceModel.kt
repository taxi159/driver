package app.pollycabcar.driver.model

class ServiceModel (var title: String?)