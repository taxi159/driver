package app.pollycabcar.driver.model

import com.google.gson.annotations.SerializedName

class ReportInfoResponse {

    @SerializedName("report")
    var report: Report? = null
}