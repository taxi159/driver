package app.pollycabcar.driver.model

import com.google.gson.annotations.SerializedName

class ModelsResponse<T> {

    @SerializedName("status")
    var isStatus: String? = null

    @SerializedName("data")
    var data: List<T>? = null
}
