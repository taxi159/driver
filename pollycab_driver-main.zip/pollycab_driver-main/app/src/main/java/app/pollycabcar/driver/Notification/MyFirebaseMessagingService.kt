package app.pollycabcar.driver.notification

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Intent
import android.media.AudioAttributes
import android.media.RingtoneManager
import android.net.Uri
import android.os.Build
import android.util.Log
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import androidx.localbroadcastmanager.content.LocalBroadcastManager
import app.pollycabcar.driver.R
import app.pollycabcar.driver.activity.MainActivity
import app.pollycabcar.driver.model.Notification
import app.pollycabcar.driver.repo.NotificationRepository
import com.google.firebase.messaging.FirebaseMessagingService
import com.google.firebase.messaging.RemoteMessage
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import com.pixplicity.easyprefs.library.Prefs
import org.json.JSONObject
import java.util.*
import kotlin.collections.ArrayList


class MyFirebaseMessagingService : FirebaseMessagingService() {

    override fun onMessageReceived(remoteMessage: RemoteMessage) {

        if (remoteMessage.data.isNotEmpty()){

            val gson = Gson()
            val data = gson.toJson(remoteMessage.data)
            val notification: Notification = gson.fromJson(data, Notification::class.java)

            if(notification.action == Notification.Action.NewOrder && notification.orderDistributionTime != 0) {
                val calendar: Calendar = Calendar.getInstance()
                calendar.add(Calendar.SECOND, notification.orderDistributionTime!!)
                notification.orderTimeout = (calendar.timeInMillis / 1000).toInt()
            }

            var mBuilder = NotificationCompat.Builder(this, "PULTTAXI_DRIVER")
            var defaultSoundUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)

            when (notification.action) {
                Notification.Action.NewOrder -> {
                    mBuilder = NotificationCompat.Builder(this, "PULTTAXI_DRIVER_NEW_ORDER")
                    defaultSoundUri = Uri.parse("android.resource://" + packageName + "/" + R.raw.order_new)
                }
                Notification.Action.OfflineNewOrder -> {
                    mBuilder = NotificationCompat.Builder(this, "PULTTAXI_DRIVER_NEW_ORDER")
                    defaultSoundUri = Uri.parse("android.resource://" + packageName + "/" + R.raw.order_new)
                }
                Notification.Action.OrderCanceled -> {
                    mBuilder = NotificationCompat.Builder(this, "PULTTAXI_DRIVER_ORDER_CANCELED")
                    defaultSoundUri = Uri.parse("android.resource://" + packageName + "/" + R.raw.order_canceled)
                }
                Notification.Action.AssignedOnOrder -> {
                    mBuilder = NotificationCompat.Builder(this, "PULTTAXI_DRIVER_ASSIGNED_ON_ORDER")
                    defaultSoundUri = Uri.parse("android.resource://" + packageName + "/" + R.raw.assigned_on_order)
                }
            }

            val ii = Intent(applicationContext, MainActivity::class.java)
            val pendingIntent = PendingIntent.getActivity(applicationContext, 0, ii, 0)

            mBuilder.setContentIntent(pendingIntent)

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                mBuilder.setSmallIcon(R.drawable.logo_notif)
                mBuilder.color = ContextCompat.getColor(applicationContext, R.color.colorPrimary)
            } else {
                mBuilder.setSmallIcon(R.mipmap.ic_launcher)
            }

            mBuilder.setContentTitle(notification.title)
            mBuilder.setContentText(notification.message)
            mBuilder.setSound(defaultSoundUri)
            mBuilder.priority = NotificationCompat.PRIORITY_HIGH
            mBuilder.setAutoCancel(true)

            Log.e(TAG, notification.action)
            Log.e(TAG, notification.orderId.toString())

            val mNotificationManager = NotificationManagerCompat.from(this)

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                val notificationManager = getSystemService(NotificationManager::class.java)
                val importance = NotificationManager.IMPORTANCE_HIGH
                val attributes = AudioAttributes.Builder()
                        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                        .setUsage(AudioAttributes.USAGE_NOTIFICATION)
                        .build()

                // Канал для обычных уведомлений
                var channel = NotificationChannel("PULTTAXI_DRIVER", "Обычные уведомления", importance)
                channel.description = "Обычные уведомления"
                channel.enableVibration(true)
                channel.setSound(RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION), attributes)
                notificationManager.createNotificationChannel(channel)

                // Канал для уведомлений о новом заказе
                channel = NotificationChannel("PULTTAXI_DRIVER_NEW_ORDER", "Уведомления о новых заказах", importance)
                channel.description = "Уведомления о новых заказах"
                channel.enableVibration(true)
                channel.setSound(Uri.parse("android.resource://" + packageName + "/" + R.raw.order_new), attributes)
                notificationManager.createNotificationChannel(channel)

                // Канал для уведомлений об отмене заказа
                channel = NotificationChannel("PULTTAXI_DRIVER_ORDER_CANCELED", "Уведомления об отмене заказа", importance)
                channel.description = "Уведомления об отмене заказа"
                channel.enableVibration(true)
                channel.setSound(Uri.parse("android.resource://" + packageName + "/" + R.raw.order_canceled), attributes)
                notificationManager.createNotificationChannel(channel)

                // Канал для уведомлений о назначение на заказ
                channel = NotificationChannel("PULTTAXI_DRIVER_ASSIGNED_ON_ORDER", "Уведомления о назначение на заказ", importance)
                channel.description = "Уведомления о назначение на заказ"
                channel.enableVibration(true)
                channel.setSound(Uri.parse("android.resource://" + packageName + "/" + R.raw.assigned_on_order), attributes)
                notificationManager.createNotificationChannel(channel)
            }

            if (notification.title != null && notification.message != null && notification.orderId != null) {
                mNotificationManager.notify(0, mBuilder.build())
            }

            NotificationRepository.instance?.addNotification(notification)
        }
    }

    companion object {
        private val TAG = "MyFirebaseMsgService"
    }
}
