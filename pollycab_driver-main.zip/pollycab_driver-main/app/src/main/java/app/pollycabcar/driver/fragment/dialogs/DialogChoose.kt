package app.pollycabcar.driver.fragment.dialogs

import android.app.Dialog
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.fragment.app.DialogFragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import app.pollycabcar.driver.R
import app.pollycabcar.driver.adapter.DialogChooseAdapter
import kotlinx.android.synthetic.main.dialog_choose.*

class DialogChoose(private val title: String, private val callback: ((data: String) -> Unit)? = null) : DialogFragment(), View.OnClickListener {
    private var dataList: List<String?> = listOf()
    private var adapter: DialogChooseAdapter? = null

    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog {
        val view: View = LayoutInflater.from(context).inflate(R.layout.dialog_choose, null)

        val title = view.findViewById<TextView>(R.id.tv_title)
        val recyclerView = view.findViewById<RecyclerView>(R.id.rv)
        val accept = view.findViewById<TextView>(R.id.btn_accept)
        val cancel = view.findViewById<TextView>(R.id.btn_cancel)

        title.text = this.title

        adapter = DialogChooseAdapter()
        adapter?.setList(dataList)
        recyclerView.layoutManager = LinearLayoutManager(context)
        recyclerView.adapter = adapter

        accept.setOnClickListener(this)
        cancel.setOnClickListener(this)

        val builder = AlertDialog.Builder(context!!)
        builder.setView(view)

        return builder.create()
    }

    override fun onClick(v: View) {
        when (v.id) {
            R.id.btn_accept -> {
                if (adapter?.pickedItem != null) {
                    callback?.invoke(adapter?.pickedItem!!)
                }
                dismiss()
            }
            R.id.btn_cancel -> dismiss()
        }
    }

    fun setDataList(dataList: List<String?>) {
        this.dataList = dataList
    }
}