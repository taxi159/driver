package app.pollycabcar.driver.view

import android.content.Context
import android.util.AttributeSet
import android.util.TypedValue
import android.view.LayoutInflater
import android.view.View
import android.widget.ImageView
import android.widget.ProgressBar
import android.widget.TextView

import androidx.constraintlayout.widget.ConstraintLayout
import app.pollycabcar.driver.R

class StatisticView(context: Context, attrs: AttributeSet) : ConstraintLayout(context, attrs) {

    private val title: TextView
    private val count: TextView
    private val text: TextView
    private val arrow: ImageView
    private val progressBar: ProgressBar
    var listener: View.OnClickListener? = null

    init {
        val service = Context.LAYOUT_INFLATER_SERVICE
        val li = getContext().getSystemService(service) as LayoutInflater
        val layout = li.inflate(R.layout.view_statistic, this, true) as ConstraintLayout

        this.progressBar = layout.findViewById(R.id.progress_bar)
        this.title = layout.findViewById(R.id.tv_title)
        this.count = layout.findViewById(R.id.tv_count)
        this.text = layout.findViewById(R.id.text)
        this.arrow = layout.findViewById(R.id.imv_arrow)
    }


    fun setTitle(title: String) {
        this.title.text = title
    }

    fun setCount(count: String) {
        progressBar.visibility = View.GONE
        this.count.text = count
    }

    fun setText(text: String) {
        progressBar.visibility = View.GONE
        this.text.visibility = View.VISIBLE
        this.text.text = text
    }

    fun getCount(): String {
        return count.text.toString()
    }

    fun getTitle(): String {
        return title.text.toString()
    }


    fun setVisibleArrow(visible: Boolean) {
        if (visible) {
            arrow.visibility = View.VISIBLE
        } else {
            arrow.visibility = View.GONE
        }
    }

    fun showProgressBar() {
        progressBar.visibility = View.VISIBLE
    }

    fun setTitleSize(sp: Float) {
        title.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp)
    }

    fun setCountSize(sp: Float) {
        count.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp)
    }


}
