/*
 * Copyright (C) 2017 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package app.pollycabcar.driver.service

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.util.Log
import app.pollycabcar.driver.model.DataResponse
import app.pollycabcar.driver.network.LoginService
import app.pollycabcar.driver.network.TaxiService
import com.github.salomonbrys.kodein.LazyKodein
import com.github.salomonbrys.kodein.android.appKodein
import com.github.salomonbrys.kodein.instance

import com.google.android.gms.location.LocationResult
import com.pixplicity.easyprefs.library.Prefs
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.disposables.Disposable
import io.reactivex.schedulers.Schedulers
import org.jetbrains.anko.toast

/**
 * Receiver for handling location updates.
 *
 * For apps targeting API level O
 * [android.app.PendingIntent.getBroadcast] should be used when
 * requesting location updates. Due to limits on background services,
 * [android.app.PendingIntent.getService] should not be used.
 *
 * Note: Apps running on "O" devices (regardless of targetSdkVersion) may receive updates
 * less frequently than the interval specified in the
 * [com.google.android.gms.location.LocationRequest] when the app is no longer in the
 * foreground.
 */
class LocationUpdatesBroadcastReceiver : BroadcastReceiver() {

    private var disposable: Disposable? = null

    override fun onReceive(context: Context, intent: Intent?) {
        if (intent != null) {
            val action = intent.action
            if (ACTION_PROCESS_UPDATES == action) {
                val result = LocationResult.extractResult(intent)
                if (result != null) {
                    val location = result.locations.get(0)
                    val kodein = LazyKodein(context.appKodein)
                    val taxiService = kodein.instance<TaxiService>()
                    val loginService = kodein.instance<LoginService>()

                    Log.d(TAG, "lat ${location.latitude}, lon ${location.longitude}, bearing ${location.bearing}, speed ${location.speed}")

                    if (loginService.value.isLoggedIn()){
                        disposable?.dispose()
                        disposable = taxiService.value.updateLocation(
                                loginService.value.accessToken,
                                location.latitude.toString(),
                                location.longitude.toString(),
                                location.speed.toString(),
                                location.accuracy.toString(),
                                location.bearing.toString()
                        )
                                .subscribeOn(Schedulers.newThread())
                                .observeOn(AndroidSchedulers.mainThread())
                                .subscribe({ t: DataResponse ->

                                    Prefs.putDouble("my_latitude", location.latitude)
                                    Prefs.putDouble("my_longitude", location.longitude)

                                    if (t.status == "success"){
                                        Log.e(TAG, "location send")
                                    }

                                }, { e ->
                                    e.printStackTrace()
                                    context.toast(e.localizedMessage)
                                })
                    }
                }
            }
        }
    }

    companion object {
        private val TAG = "LUBroadcastReceiver"

        internal val ACTION_PROCESS_UPDATES = "com.google.android.gms.location.driver.backgroundlocationupdates.action" + ".PROCESS_UPDATES"
    }
}