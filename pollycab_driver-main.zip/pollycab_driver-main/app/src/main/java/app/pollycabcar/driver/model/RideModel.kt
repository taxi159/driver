package app.pollycabcar.driver.model

import com.google.gson.annotations.SerializedName

class RideModel {

    @SerializedName("id")
    var id: Int? = null

    @SerializedName("addresses")
    var addresses: ArrayList<String>? = null

    @SerializedName("geo_points")
    var geoPoints: List<Geo>? = null

    @SerializedName("deadline")
    var deadline: String? = null

    @SerializedName("client_full_name")
    var clientFullName: String? = null

    @SerializedName("payment_type")
    var paymentType: Int? = null

    @SerializedName("result_trip_cost")
    var resultTripCost: Int? = null
}