package app.pollycabcar.driver.model

import com.google.gson.annotations.SerializedName

class Transaction {

    @SerializedName("direction")
    var direction: String? = null

    @SerializedName("description")
    var description: String? = null

    @SerializedName("amount")
    var amount: Int? = null

    @SerializedName("date")
    var date: String? = null
}