package app.pollycabcar.driver.model

import com.google.gson.annotations.SerializedName

class DataResponse {

    @SerializedName("status")
    var status: String? = null

    @SerializedName("error")
    var error: String? = null

    @SerializedName("message")
    var message: String? = null
}