package app.pollycabcar.driver.notification

import android.util.Log
import app.pollycabcar.driver.model.DataResponse
import app.pollycabcar.driver.network.LoginService
import app.pollycabcar.driver.network.TaxiService
import com.github.salomonbrys.kodein.LazyKodein
import com.github.salomonbrys.kodein.android.appKodein
import com.github.salomonbrys.kodein.instance
import com.google.firebase.messaging.FirebaseMessagingService
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.schedulers.Schedulers
import org.jetbrains.anko.toast


class MyFirebaseInstanceIDService : FirebaseMessagingService() {

    override fun onNewToken(p0: String) {
        super.onNewToken(p0)

        val refreshedToken = p0
        Log.d(TAG, "Refreshed token: " + refreshedToken)

        sendRegistrationToServer(refreshedToken)
    }

    fun sendRegistrationToServer(token: String?) {

        val kodein = LazyKodein(appKodein)
        val taxiService = kodein.instance<TaxiService>()
        val loginService = kodein.instance<LoginService>()

        val myToken = loginService.value.accessToken

        taxiService.value.sendFirebaseToken(myToken, token!!)
                .subscribeOn(Schedulers.newThread())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe({ t: DataResponse ->

                    if (t.status == "success"){
                        Log.e("sss", "fire token send")
                    }

                }, { e ->
                    e.printStackTrace()
                    toast(e.localizedMessage)
                })

    }

    companion object {

        private val TAG = "MyFirebaseIIDService"
    }
}
