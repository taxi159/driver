package app.pollycabcar.driver.network


import android.content.Context
import app.pollycabcar.driver.R
import com.pixplicity.easyprefs.library.Prefs

class LoginService(private val context: Context, private val yammyPublicService: TaxiPublicService) {

    private val yammyService: TaxiService

    val accessToken: String
        get() = Prefs.getString(ACCESS_TOKEN_KEY, "")

    init {
        val resources = context.resources
        val baseUrl = Prefs.getString(API_URL, context.getString(R.string.api_base_url))

        //Prefs.putString(ACCESS_TOKEN_KEY, "eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiJodHRwczovL3NpbXBsZXRheGkucHVsdHRheGkucnUvYXBpL2F1dGhQZXJmb3JtZXJCeURyaXZlckxpY2Vuc2UiLCJpYXQiOjE1NTQ0OTkyNDIsImV4cCI6MTU2MjUzNDQ0MiwibmJmIjoxNTU0NDk5MjQyLCJqdGkiOiJ6alpwekpCY0taSkJ5SkdPIiwic3ViIjozMiwicHJ2IjoiNTQ1OTYyODRiN2NmMDc3N2RmNDUzNWRjZmQzNDIxZmE3ZTljZjlkOCJ9.Pp_M6qBPnFYTVIkaB01VTmqBv3PwAyXHGBuOCexuRys")

//
        yammyService = RetrofitFactory.getAuthorized(baseUrl, this
                , context
        ).create(TaxiService::class.java)
    }

//    fun login(username: String, password: String, phone: String, callback: YammyLoginCallback) {
//        val loginCall = yammyPublicService.login(LOGIN_TYPE_NATIVE, username, phone, password, null, null)
//
//        processResponseAsync(loginCall, callback)
//    }

    fun logout() {
        Prefs.putString(API_URL, null)
        Prefs.putString(ACCESS_TOKEN_KEY, null)
        Prefs.putString(SESSION_ID, null)
        Prefs.clear()
    }

    fun isLoggedIn(): Boolean = Prefs.getString(ACCESS_TOKEN_KEY, "") != ""

    fun getSessionId(): String = Prefs.getString(SESSION_ID, "")

    companion object {
        val ACCESS_TOKEN_KEY = "access_token"
        val API_URL = "base_url"
        val SESSION_ID = "session_id"
    }
}
