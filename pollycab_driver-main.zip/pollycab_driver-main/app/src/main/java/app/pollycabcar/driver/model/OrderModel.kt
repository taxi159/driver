package app.pollycabcar.driver.model

import com.google.gson.annotations.SerializedName

class OrderModel {

    @SerializedName("id")
    var orderId: Int? = null

    @SerializedName("addresses")
    var addresses: ArrayList<String>? = null

    @SerializedName("geo_points")
    var geoPoints: List<Geo>? = null

    @SerializedName("deadline")
    var deadline: String? = null

    @SerializedName("transportation_tariff_id")
    var transportationTariffId: Int? = null

    @SerializedName("distance_to_order")
    var distanceToOrder: Double? = null

    @SerializedName("service_ids")
    var serviceIds: String? = null

    @SerializedName("payment_type")
    var paymentType: Int? = null

    @SerializedName("result_trip_cost")
    var resultTripCost: Int? = null

    @SerializedName("status")
    var status: Int? = null
}
