package app.pollycabcar.driver.fragment

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.drawable.Drawable
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.annotation.DrawableRes
import androidx.core.content.ContextCompat
import app.pollycabcar.driver.R
import app.pollycabcar.driver.adapter.ServicesAdapter
import app.pollycabcar.driver.model.*
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import com.pixplicity.easyprefs.library.Prefs
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.disposables.Disposable
import io.reactivex.schedulers.Schedulers
import kotlinx.android.synthetic.main.order_info_fragment.*
import java.text.SimpleDateFormat
import java.util.*
import androidx.recyclerview.widget.LinearLayoutManager
import app.pollycabcar.driver.adapter.OrderAddressesAdapter
import app.pollycabcar.driver.repo.ProfileRepository
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.MapsInitializer
import com.google.android.gms.maps.model.*
import kotlinx.android.synthetic.main.order_info_fragment.commentText
import kotlinx.android.synthetic.main.order_info_fragment.mapView
import kotlinx.android.synthetic.main.order_info_fragment.tv_payment_type
import kotlinx.android.synthetic.main.order_info_fragment.tv_price
import kotlinx.android.synthetic.main.order_info_fragment.rvAddresses
import kotlinx.android.synthetic.main.order_info_fragment.rvServices
import kotlinx.android.synthetic.main.order_info_fragment.tv_date_time
import kotlinx.android.synthetic.main.order_info_fragment.textTariff
import kotlinx.android.synthetic.main.order_info_fragment.toolbar
import org.jetbrains.anko.support.v4.toast

class OrderInfoFragment : BaseFragment() {

    private lateinit var servicesAdapter: ServicesAdapter
    private lateinit var addressesAdapter: OrderAddressesAdapter

    private var orderId: String = ""
    private var orderInfo: OrderInfoModel? = null
    private var notifyIndex: Int = -1

    private var infoDisposable: Disposable? = null
    private var takeOrderDisposable: Disposable? = null
    private var statusDisposable: Disposable? = null

    private var googleMap: GoogleMap? = null

    override fun onStart() {
        super.onStart()
        changeFont()

        orderId = arguments?.getString(ARG_ORDER_ID)!!

        notifyIndex = arguments?.getInt(ARG_ORDER_INDEX, -1)!!

        if(notifyIndex != -1) {
            layoutTakeOrderAuto.visibility = View.VISIBLE
        } else {
            btnTakeOrderManual.visibility = View.VISIBLE

            toolbar.setNavigationIcon(R.drawable.ic_arrow_back)
            toolbar.setNavigationOnClickListener {
                goBack()
            }
        }

        getOrderDetails()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        retainInstance = true
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        return inflater.inflate(R.layout.order_info_fragment, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val layoutManager = LinearLayoutManager(context, LinearLayoutManager.HORIZONTAL, false)
        rvServices.layoutManager = layoutManager
        servicesAdapter = ServicesAdapter()
        rvServices.adapter = servicesAdapter
        rvServices.isNestedScrollingEnabled = false

        rvAddresses.layoutManager = LinearLayoutManager(context, LinearLayoutManager.VERTICAL, false)
        addressesAdapter = OrderAddressesAdapter()
        rvAddresses.adapter = addressesAdapter
        rvAddresses.isNestedScrollingEnabled = false

        mapView?.onCreate(savedInstanceState)

        mapView?.onResume()

        try {
            MapsInitializer.initialize(activity!!.applicationContext)
        } catch (e: Exception) {
            e.printStackTrace()
        }

        mapView?.getMapAsync { mMap ->
            googleMap = mMap

            googleMap?.uiSettings?.isRotateGesturesEnabled = false
            googleMap?.uiSettings?.isCompassEnabled = false
            googleMap?.uiSettings?.isMapToolbarEnabled = false
            googleMap?.uiSettings?.isIndoorLevelPickerEnabled = true
            googleMap?.uiSettings?.isMyLocationButtonEnabled = false
        }

        btnTakeOrderManual.setOnClickListener {
            takeOrder()
        }

        btnTakeOrderAuto.setOnClickListener {
            takeOrder()
        }

        btnDeclineOrder.setOnClickListener {
            showProgress(true)
            infoDisposable = taxiService.value.rejectOrderNotification(loginService.value.accessToken, orderId.toInt())
                    .subscribeOn(Schedulers.newThread())
                    .observeOn(AndroidSchedulers.mainThread())
                    .subscribe({ t: DataResponse ->
                        goBack()
                        showProgress(false)
                    }, { e ->
                        e.printStackTrace()
                        showProgress(false)
                    })
        }
    }

    private fun takeOrder() {

        showProgress(true)

        takeOrderDisposable = taxiService.value.confirmOrder(loginService.value.accessToken, orderId.toInt())
                .subscribeOn(Schedulers.newThread())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe({ t: DataResponse ->
                    if (t.status == "success"){
                        statusDisposable?.dispose()
                        statusDisposable = taxiService.value.getDriverInfo(loginService.value.accessToken)
                                .subscribeOn(Schedulers.newThread())
                                .observeOn(AndroidSchedulers.mainThread())
                                .subscribe({ t: DriverModel ->
                                    showProgress(false)
                                    ProfileRepository.instance?.setProfile(t)
                                }, { e ->
                                    e.printStackTrace()
                                    showProgress(false)
                                })

                        mainActivity.hardReplaceFragment(ActiveOrderFragment.newInstance(orderId.toInt()))
                    } else if(t.status == "error") {
                        showProgress(false)

                        when(t.error) {
                            "wrong_balance" -> toast("Недостаточно средств на балансе для принятие заказа")
                            "wrong_rating" -> toast("Недостаточно высокий рейтинг для принятие заказа")
                            "performer_not_match" -> toast("Заказ более не актуален или уже взят другим водителем")
                            "push_timeout" -> toast("Истекло время для принятие заказа")
                            "no_access" -> toast("Доступ запрещён")
                            else -> toast("Вы не можете взять новый заказ, пока не завершён предыдущий")
                        }

                        goBack()
                    }
                }, { e ->
                    e.printStackTrace()
                    showProgress(false)
                    toast("Заказ более не актуален или уже взят другим водителем")
                    goBack()
                })
    }

    private fun drawRoutePolyline() {
        val LatLongB = LatLngBounds.Builder()
        val options = PolylineOptions()
        options.color(resources.getColor(R.color.lightBlue))
        options.width(7f)

        googleMap!!.addMarker(
                MarkerOptions().position(
                        LatLng(
                                orderInfo?.geoPoints?.get(0)?.lat!!.toDouble(),
                                orderInfo?.geoPoints?.get(0)?.lon!!.toDouble()
                        )
                ).icon(bitmapDescriptorFromVector(context!!, R.drawable.ic_marker_start))
        )

        for (coordinates in orderInfo?.routePolyline!!) {
            options.add(LatLng(coordinates[0], coordinates[1]))
            LatLongB.include(LatLng(coordinates[0], coordinates[1]))
        }
        googleMap!!.addPolyline(options)

        for (geoPoint in orderInfo?.geoPoints!!) {
            googleMap!!.addMarker(
                    MarkerOptions().position(
                            LatLng(
                                    geoPoint.lat!!.toDouble(),
                                    geoPoint.lon!!.toDouble()
                            )
                    ).icon(bitmapDescriptorFromVector(context!!, R.drawable.ic_marker_end))
            )
        }

        googleMap!!.setPadding(0, 0, 0, 180)

        val bounds = LatLongB.build()
        val width = getResources().getDisplayMetrics().widthPixels
        val height = getResources().getDisplayMetrics().heightPixels
        val padding = (width * 0.30).toInt()
        googleMap!!.moveCamera(CameraUpdateFactory.newLatLngBounds(bounds, width, height, padding))
    }

    private fun bitmapDescriptorFromVector(
            context: Context,
            @DrawableRes vectorResId: Int
    ): BitmapDescriptor? {
        val vectorDrawable: Drawable = ContextCompat.getDrawable(context, vectorResId)!!
        vectorDrawable.setBounds(
                0,
                0,
                vectorDrawable.intrinsicWidth,
                vectorDrawable.intrinsicHeight
        )
        val bitmap = Bitmap.createBitmap(
                vectorDrawable.intrinsicWidth,
                vectorDrawable.intrinsicHeight,
                Bitmap.Config.ARGB_8888
        )
        val canvas = Canvas(bitmap)
        vectorDrawable.draw(canvas)
        return BitmapDescriptorFactory.fromBitmap(bitmap)
    }

    private fun changeFont(){
        changeFontInTextView(tv_date_time)
        changeFontInTextView(textTariff)
        changeFontInTextView(tv_payment_type)
        changeFontInTextView(commentText)

        changeFontInTextViewBold(tv_price)
        changeFontInTextViewBold(textTakeOrderManual)
        changeFontInTextViewBold(textTakeOrderAuto)
        changeFontInTextViewBold(textDeclineOrder)
    }

    private fun getOrderDetails(){
        showProgress(true)
        infoDisposable = taxiService.value.getOrderInfo(loginService.value.accessToken, orderId.toInt())
                .subscribeOn(Schedulers.newThread())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe({ t: OrderInfoResponse ->

                    if (t.status == "success"){

                        if (t.orderInfo != null){

                            orderInfo = t.orderInfo!!

                            toolbar.title = getString(R.string.orderWithId) + t.orderInfo!!.id

                            textTariff.text = t.orderInfo!!.transportationTariffName

                            t.orderInfo!!.resultTripCost?.let { tv_price.text = it.toString() + " \u20BD" }

                            addressesAdapter.setList(t.orderInfo?.addresses!!, t.hideRoutePoints!!)

                            if(!t.orderInfo!!.comment.isNullOrEmpty()) {
                                commentText.visibility = View.VISIBLE
                                commentText.text = t.orderInfo!!.comment
                            }

                            var format: SimpleDateFormat = SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
                            val date: Date = format.parse(t.orderInfo!!.deadline)
                            format = SimpleDateFormat("E, d MMM HH:mm", Locale("ru"))
                            val deadline: String = format.format(date)
                            tv_date_time.text = deadline

                            if(t.orderInfo!!.services!!.isNotEmpty())
                                servicesAdapter.setList(t.orderInfo!!.services!!)
                            else
                                rvServices.visibility = View.GONE

                            when(t.orderInfo!!.paymentType){
                                0 -> tv_payment_type.text = getString(R.string.payment_type_nal)
                                1 -> tv_payment_type.text = getString(R.string.payment_type_bez_nal)
                                2 -> tv_payment_type.text = getString(R.string.payment_type_virtual)
                                3 -> tv_payment_type.text = getString(R.string.payment_type_organization)
                            }

                            drawRoutePolyline()
                        }

                    } else if(t.status == "error" && t.error == "no_access") {
                        toast("Доступ запрещён")
                        goBack()
                    }

                    showProgress(false)
                }, { e ->
                    e.printStackTrace()
                    showProgress(false)
                })

    }

    override fun onResume() {
        super.onResume()
        mapView?.onResume()
    }

    override fun onPause() {
        super.onPause()
        mapView?.onPause()
    }

    override fun onStop() {
        super.onStop()
        mapView?.onStop()
        infoDisposable?.dispose()
        takeOrderDisposable?.dispose()
    }

    override fun onDestroy() {
        super.onDestroy()
        mapView?.onDestroy()
    }

    override fun onLowMemory() {
        super.onLowMemory()
        mapView?.onLowMemory()
    }

    companion object {
        private val ARG_ORDER_ID = "arg_order_id"
        private val ARG_ORDER_INDEX = "arg_notify_index"

        fun newInstance(orderId: String, notifyIndex: Int?): OrderInfoFragment {

            val args = Bundle()

            args.putString(ARG_ORDER_ID, orderId)
            args.putInt(ARG_ORDER_INDEX, notifyIndex!!)
            val fragment = OrderInfoFragment()
            fragment.arguments = args
            return fragment
        }
    }
}
