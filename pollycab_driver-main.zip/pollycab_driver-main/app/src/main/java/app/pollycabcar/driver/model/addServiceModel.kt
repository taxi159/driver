package app.pollycabcar.driver.model

import com.google.gson.annotations.SerializedName

class addServiceModel {

    @SerializedName("name")
    var name: String? = null
}