package app.pollycabcar.driver.model

import com.google.gson.annotations.SerializedName

class LoginResponse {

    @SerializedName("status")
    var status: String? = null

    @SerializedName("error")
    var error: String? = null

    @SerializedName("token")
    var token: String? = null

    @SerializedName("session_id")
    var session_id: String? = null
}