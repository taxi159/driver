package app.pollycabcar.driver.adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.RadioButton
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import app.pollycabcar.driver.R
import app.pollycabcar.driver.adapter.DialogChooseAdapter.Holder

class DialogChooseAdapter : RecyclerView.Adapter<Holder>() {
    private var list: List<String?> = listOf()
    private var checkPosition: Int? = null
    var pickedItem: String? = null
        private set

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): Holder {
        val view: View = LayoutInflater.from(parent.context).inflate(R.layout.item_choose, null)
        return Holder(view)
    }

    override fun onBindViewHolder(holder: Holder, position: Int) {
        val item = list[position]
        holder.setIsRecyclable(false)
        if (checkPosition != null && checkPosition == position) {
            holder.radioButton.isChecked = true
            checkPosition = null
        }
        holder.text.text = item
        holder.radioButton.setOnClickListener {
            checkPosition = position
            pickedItem = item
            notifyDataSetChanged()
        }
    }

    override fun getItemCount(): Int {
        return list.size
    }

    inner class Holder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val radioButton: RadioButton
        val text: TextView

        init {
            radioButton = itemView.findViewById(R.id.radio_btn)
            text = itemView.findViewById(R.id.tv_text)
        }
    }

    fun setList(list: List<String?>) {
        this.list = list
    }
}