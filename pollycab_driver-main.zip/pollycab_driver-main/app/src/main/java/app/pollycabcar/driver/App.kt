package app.pollycabcar.driver

import android.annotation.SuppressLint
import android.app.Application
import android.content.ContextWrapper
import app.pollycabcar.driver.network.LoginService
import app.pollycabcar.driver.network.RetrofitFactory
import app.pollycabcar.driver.network.TaxiPublicService
import app.pollycabcar.driver.network.TaxiService
import com.github.salomonbrys.kodein.*
import com.pixplicity.easyprefs.library.Prefs
import org.jetbrains.anko.ctx


class App : Application(), KodeinAware {

    override val kodein by Kodein.lazy {
        bind<TaxiPublicService>() with provider { RetrofitFactory.getForLogin(Prefs.getString(LoginService.API_URL, ctx.getString(R.string.api_base_url))).create(TaxiPublicService::class.java) }
        bind<LoginService>() with provider { LoginService(ctx, kodein.instance()) }
        bind<TaxiService>() with provider { RetrofitFactory.getAuthorized(Prefs.getString(LoginService.API_URL, ctx.getString(R.string.api_base_url)), kodein.instance(), applicationContext).create(TaxiService::class.java) }
    }

    @SuppressLint("BatteryLife")
    override fun onCreate() {
        super.onCreate()

        Prefs.Builder()
                .setContext(this)
                .setMode(ContextWrapper.MODE_PRIVATE)
                .setPrefsName(packageName)
                .setUseDefaultSharedPreference(true)
                .build()
    }
}