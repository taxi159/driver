package app.pollycabcar.driver.model

import com.google.gson.annotations.SerializedName

class WorkShift {
    @SerializedName("id")
    var id: Int? = 0

    @SerializedName("cost_working_shift")
    var price: Int? = 0

    @SerializedName("period_working_shift")
    var period: Int? = 0
}