package app.pollycabcar.driver.adapter


import android.graphics.Typeface
import androidx.recyclerview.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import app.pollycabcar.driver.R
import app.pollycabcar.driver.model.addServiceModel
import org.jetbrains.anko.find

class ServicesAdapter : RecyclerView.Adapter<ServicesAdapter.MyViewHolder>() {

    private var servicesList: List<addServiceModel> = listOf()

    fun setList(list: List<addServiceModel>) {
        servicesList = list
        notifyDataSetChanged()
    }

    inner class MyViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        var service: TextView = view.find(R.id.serviceText)
        var divider: ImageView = view.find(R.id.divider)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyViewHolder {
        val itemView = LayoutInflater.from(parent.context)
                .inflate(R.layout.service_item, parent, false)

        return MyViewHolder(itemView)
    }

    override fun onBindViewHolder(holder: MyViewHolder, position: Int) {
        val item = servicesList[position]

        val type = Typeface.createFromAsset(holder.itemView.context?.assets, "font/roboto_regular.ttf")

        holder.service.text = item.name
        holder.service.typeface = type

        val nextPosition = position + 1;
        if(itemCount == nextPosition)
            holder.divider.visibility = View.GONE
    }

    override fun getItemCount(): Int {
        return servicesList.size
    }
}
