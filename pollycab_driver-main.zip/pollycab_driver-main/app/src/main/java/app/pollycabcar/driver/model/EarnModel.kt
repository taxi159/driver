package app.pollycabcar.driver.model

import com.google.gson.annotations.SerializedName

class EarnModel {

    @SerializedName("total")
    var total: String? = null

    @SerializedName("order_count")
    var orderCount: String? = null

    @SerializedName("weeks")
    var weeks: List<WeekEarn>? = null
}