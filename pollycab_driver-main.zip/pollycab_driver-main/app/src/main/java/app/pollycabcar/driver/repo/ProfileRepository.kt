package app.pollycabcar.driver.repo

import androidx.lifecycle.MutableLiveData
import app.pollycabcar.driver.model.DriverModel

class ProfileRepository {
    val profileLiveData = MutableLiveData<DriverModel>()
    fun setProfile(profileLiveData: DriverModel) {
        this.profileLiveData.postValue(profileLiveData)
    }

    val profile: DriverModel?
        get() = profileLiveData.value

    fun setStatus(status: Int) {
        val profile = profileLiveData.value
        if (profile != null) {
            profile.status = status
            profileLiveData.postValue(profile)
        }
    }

    companion object {
        var instance: ProfileRepository? = null
            get() {
                if (field == null) {
                    field = ProfileRepository()
                }
                return field
            }
            private set
    }
}