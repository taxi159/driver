package app.pollycabcar.driver.fragment

import android.app.Dialog
import android.content.ActivityNotFoundException
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Typeface
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.core.content.ContextCompat
import androidx.fragment.app.DialogFragment
import androidx.recyclerview.widget.LinearLayoutManager
import app.pollycabcar.driver.R
import app.pollycabcar.driver.adapter.WorkShiftsAdapter
import app.pollycabcar.driver.model.DataResponse
import app.pollycabcar.driver.model.DriverModel
import app.pollycabcar.driver.model.WorkShiftsResponse
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.disposables.Disposable
import io.reactivex.schedulers.Schedulers
import kotlinx.android.synthetic.main.dialog_with_action.*
import kotlinx.android.synthetic.main.fragment_work_shifts.*
import kotlinx.android.synthetic.main.transactions_fragment.toolbar
import org.jetbrains.anko.find
import org.jetbrains.anko.support.v4.toast


class WorkShiftsFragment : BaseFragment() {
    private var profile: DriverModel? = null
    private lateinit var workShiftsAdapter: WorkShiftsAdapter
    private var infoDisposable: Disposable? = null

    override fun onStart() {
        super.onStart()
        getDriverInfo()
        getAvailableWorkShifts()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        retainInstance = true
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?,
                              savedInstanceState: Bundle?): View? {
        val view = inflater.inflate(R.layout.fragment_work_shifts, container, false)

        return view
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        rv_work_shifts.layoutManager = LinearLayoutManager(context, LinearLayoutManager.VERTICAL, false)
        workShiftsAdapter = WorkShiftsAdapter() {
            if (profile?.workShiftExpiresAt == 0) {
                showDialogToBuy(it.id!!)
            } else {
                showDialogReBuy(it.id!!)
            }
        }
        rv_work_shifts.adapter = workShiftsAdapter
        rv_work_shifts.isNestedScrollingEnabled = false

        toolbar.setNavigationIcon(R.drawable.ic_arrow_back)
        toolbar.setNavigationOnClickListener {
            goBack()
        }
    }

    override fun onStop() {
        super.onStop()
        infoDisposable?.dispose()
    }

    private fun getDriverInfo(){
        showProgress(true)

        infoDisposable = taxiService.value.getDriverInfo(loginService.value.accessToken)
                .subscribeOn(Schedulers.newThread())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe({ t: DriverModel ->
                    profile = t
                    showProgress(false)
                }, { e ->
                    e.printStackTrace()
                    toast(e.localizedMessage)
                    showProgress(false)
                })

    }

    private fun getAvailableWorkShifts(){
        showProgress(true)

        infoDisposable = taxiService.value.getAvailableWorkShifts(loginService.value.accessToken)
                .subscribeOn(Schedulers.newThread())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe({ t: WorkShiftsResponse ->
                    if (t.data?.size != 0) {
                        workShiftsAdapter.list = t.data
                        rv_work_shifts.visibility = View.VISIBLE
                        workShiftsNotFoundText.visibility = View.GONE
                    } else {
                        rv_work_shifts.visibility = View.GONE
                        workShiftsNotFoundText.visibility = View.VISIBLE
                    }

                    showProgress(false)
                }, { e ->
                    e.printStackTrace()
                    toast(e.localizedMessage)
                    showProgress(false)
                })

    }

    private fun buyWorkShift(workShiftId: Int){
        showProgress(true)

        infoDisposable = taxiService.value.buyWorkShift(loginService.value.accessToken, workShiftId)
                .subscribeOn(Schedulers.newThread())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe({ t: DataResponse ->
                    when (t.status) {
                        "success" -> toast("Смена успешно куплена")
                        "error" -> toast(t.error!!)
                    }

                    showProgress(false)
                }, { e ->
                    e.printStackTrace()
                    showProgress(false)
                })

    }

    private fun showDialogReBuy(workShiftId: Int) {
        context?.let {
            val mDialog = Dialog(it, R.style.CustomDialog)
            mDialog.setCancelable(true)
            mDialog.setContentView(R.layout.dialog_with_action)

            mDialog.title.text = getString(R.string.dialog_title_rebuy_work_shift)
            mDialog.title.textSize = 21F
            mDialog.title.setTextColor(resources.getColor(R.color.blue))
            mDialog.firstButtonText.text = getString(R.string.dialog_change_work_shift)
            mDialog.secondButtonText.text = getString(R.string.dialog_cancel_buy_work_shift)

            mDialog.firstButtonText.setOnClickListener {
                mDialog.dismiss()
                buyWorkShift(workShiftId)
            }

            mDialog.secondButtonText.setOnClickListener {
                mDialog.dismiss()
            }

            mDialog.show()
        }
    }

    private fun showDialogToBuy(workShiftId: Int) {
        context?.let {
            val mDialog = Dialog(it, R.style.CustomDialog)
            mDialog.setCancelable(true)
            mDialog.setContentView(R.layout.dialog_with_action)

            mDialog.title.text = getString(R.string.dialog_title_buy_work_shift)
            mDialog.title.textSize = 21F
            mDialog.title.setTextColor(resources.getColor(R.color.blue))
            mDialog.firstButtonText.text = getString(R.string.dialog_buy_work_shift)
            mDialog.secondButtonText.text = getString(R.string.dialog_cancel_buy_work_shift)

            mDialog.firstButtonText.setOnClickListener {
                mDialog.dismiss()
                buyWorkShift(workShiftId)
            }

            mDialog.secondButtonText.setOnClickListener {
                mDialog.dismiss()
            }

            mDialog.show()
        }
    }
}
