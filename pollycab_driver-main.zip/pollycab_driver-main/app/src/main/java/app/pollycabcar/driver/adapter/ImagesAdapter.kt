package app.pollycabcar.driver.adapter


import android.graphics.drawable.Drawable
import androidx.recyclerview.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.ProgressBar
import app.pollycabcar.driver.R
import app.pollycabcar.driver.network.LoginService
import com.bumptech.glide.Glide
import com.bumptech.glide.load.engine.DiskCacheStrategy
import com.bumptech.glide.load.engine.GlideException
import com.bumptech.glide.load.resource.drawable.DrawableTransitionOptions
import com.bumptech.glide.request.RequestListener
import com.bumptech.glide.request.RequestOptions
import com.github.salomonbrys.kodein.LazyKodein
import com.github.salomonbrys.kodein.android.appKodein
import com.github.salomonbrys.kodein.instance
import org.jetbrains.anko.find

class ImagesAdapter : RecyclerView.Adapter<ImagesAdapter.MyViewHolder>() {


    private var imageList: List<String> = listOf()

    fun setList(list: List<String>) {
        imageList = list
        notifyDataSetChanged()
    }

    inner class MyViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        var imageView: ImageView = view.find(R.id.image)
        internal var progressView : ProgressBar = view.find(R.id.progress)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyViewHolder {
        val itemView = LayoutInflater.from(parent.context)
                .inflate(R.layout.images_item, parent, false)

        return MyViewHolder(itemView)
    }

    override fun onBindViewHolder(holder: MyViewHolder, position: Int) {
        val imgItem = imageList[position]

        val loginService: LoginService = LazyKodein(holder.itemView.context!!.applicationContext.appKodein).instance<LoginService>().value

        val requestOptions = RequestOptions()
                .diskCacheStrategy(DiskCacheStrategy.ALL)

        if (imgItem != null){

            val url = imgItem + "/performer?token=" + loginService.accessToken

            holder.progressView.visibility = View.VISIBLE

            Glide.with(holder.itemView.context)
                    .load(url)
                    .apply(requestOptions)
                    .listener(object : RequestListener<Drawable> {
                        override fun onResourceReady(resource: Drawable?, model: Any?, target: com.bumptech.glide.request.target.Target<Drawable>?, dataSource: com.bumptech.glide.load.DataSource?, isFirstResource: Boolean): Boolean {
                            holder.progressView.visibility = View.GONE
                            return false
                        }

                        override fun onLoadFailed(e: GlideException?, model: Any?, target: com.bumptech.glide.request.target.Target<Drawable>?, isFirstResource: Boolean): Boolean {
                            holder.progressView.visibility = View.GONE
                            return false
                        }

                    })
                    .transition(DrawableTransitionOptions.withCrossFade()).into(holder.imageView)
        } else {
            Glide.with(holder.itemView.context).load(R.drawable.rectangle).into(holder.imageView)
        }
    }

    override fun getItemCount(): Int {
        return imageList.size
    }
}
