package app.pollycabcar.driver.util

import java.text.ParseException
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

object DateFormatter {


    //get date
    fun getDateFromStringUTC(datetime: String): Date? {
        try {
            val simpleDateFormat = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale("ru"))
            return simpleDateFormat.parse(datetime)
        } catch (e: ParseException) {
            e.printStackTrace()
        }

        return null
    }

    fun getDateFromStringUTCWithSeconds(datetime: String): Date? {
        try {
            val simpleDateFormat = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", Locale("ru"))
            return simpleDateFormat.parse(datetime)
        } catch (e: ParseException) {
            e.printStackTrace()
        }

        return null
    }

    fun getDateFromStringUTCTimeZone(datetime: String): Date? {
        try {
            val simpleDateFormat = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss")
            return simpleDateFormat.parse(datetime)
        } catch (e: ParseException) {
            e.printStackTrace()
        }

        return null
    }

    fun getDateFromStringUTCWithoutTime(datetime: String): Date? {
        try {
            val simpleDateFormat = SimpleDateFormat("yyyy-MM-dd", Locale("ru"))
            return simpleDateFormat.parse(datetime)
        } catch (e: ParseException) {
            e.printStackTrace()
        }

        return null
    }


    //getString
    fun getStringDdMmmmEromDate(date: Date): String {
        val outputDateFormat = SimpleDateFormat("dd MMMM", Locale("ru"))
        return outputDateFormat.format(date)
    }

    fun getStringDdMmmmEeFromDate(date: Date): String {
        val outputDateFormat = SimpleDateFormat("dd MMMM, EE", Locale("ru"))
        return outputDateFormat.format(date)
    }

    fun getStringDdMmmmHHmmFromDate(date: Date): String {
        val outputDateFormat = SimpleDateFormat("dd MMMM, HH:mm", Locale("ru"))
        return outputDateFormat.format(date)
    }

    fun getStringSimpleTimeFromDate(date: Date): String {
        val outputDateFormat = SimpleDateFormat("HH:mm", Locale("ru"))
        return outputDateFormat.format(date)
    }

    fun getStringUTCFromDate(date: Date): String {
        //SimpleDateFormat outputDateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", Locale("ru"));
        val outputDateFormat = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale("ru"))
        return outputDateFormat.format(date)
    }


    fun getStringDateTimeFromDate(date: Date): String {
        val outputDateFormat = SimpleDateFormat("HH:mm dd.MM", Locale("ru"))
        return outputDateFormat.format(date)
    }

    fun getSimpleTime(date: Date): String {
        val outputDateFormat = SimpleDateFormat("HH:mm", Locale("ru"))
        return outputDateFormat.format(date)
    }

    fun getSimpleDate(date: Date): String {
        val outputDateFormat = SimpleDateFormat("dd.MM.yyyy", Locale("ru"))
        return outputDateFormat.format(date)
    }

    fun isSameDay(date1: Date, date2: Date): Boolean {
        val outputDateFormat = SimpleDateFormat("yyyy-MM-dd", Locale("ru"))
        return outputDateFormat.format(date1) == outputDateFormat.format(date2)
    }

    fun getDay(date: Date): String {
        val outputDateFormat = SimpleDateFormat("dd", Locale("ru"))
        return outputDateFormat.format(date)
    }

    fun getMonth(date: Date): String {
        val outputDateFormat = SimpleDateFormat("MMM", Locale("ru"))
        return outputDateFormat.format(date)
    }

    fun getStartOfDay(date: Date): String {
        val outputDateFormat = SimpleDateFormat("yyyy-MM-dd 00:00:00", Locale("ru"))
        return outputDateFormat.format(date)
    }

    fun getEndOfDay(date: Date): String {
        val outputDateFormat = SimpleDateFormat("yyyy-MM-dd 23:59:59", Locale("ru"))
        return outputDateFormat.format(date)
    }

    //time
    fun getHoursDifference(startDate: Date, endDate: Date): String {
        val milliseconds = endDate.time - startDate.time

        // 3 600 секунд = 60 минут = 1 час
        val hours = (milliseconds / (60 * 60 * 1000)).toInt()
        /* System.out.println("Разница между датами в часах: " + hours);*/

        return hours.toString() + ""
    }

    fun getMinutesDifference(startDate: Date, endDate: Date): Int {
        val milliseconds = endDate.time - startDate.time

        // 60 000 миллисекунд = 60 секунд = 1 минута

        return (milliseconds / (60 * 1000)).toInt()
    }


    // calendar
    fun datePlusDays(date: Date, days: Int): Date {
        val instance = Calendar.getInstance()
        instance.time = date
        instance.add(Calendar.DAY_OF_MONTH, days)
        return instance.time
    }

    fun getDayOfWeek(date: Date): Int {
        val calendar = Calendar.getInstance()
        calendar.time = date

        val day = calendar.get(Calendar.DAY_OF_WEEK)
        when (day) {
            Calendar.MONDAY -> return 0
            Calendar.TUESDAY -> return 1
            Calendar.WEDNESDAY -> return 2
            Calendar.THURSDAY -> return 3
            Calendar.FRIDAY -> return 4
            Calendar.SATURDAY -> return 5
            Calendar.SUNDAY -> return 6
        }

        return 7
    }

}
