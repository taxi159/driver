package app.pollycabcar.driver.adapter


import android.graphics.Typeface
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import app.pollycabcar.driver.R
import app.pollycabcar.driver.model.Transaction
import org.jetbrains.anko.find
import org.jetbrains.anko.textColor
import java.text.SimpleDateFormat
import java.util.*

class TransactionsAdapter : RecyclerView.Adapter<TransactionsAdapter.MyViewHolder>() {

    private var transactionsList: List<Transaction> = listOf()

    fun setList(list: List<Transaction>) {
        transactionsList = list
        notifyDataSetChanged()
    }

    inner class MyViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        var textValue: TextView = view.find(R.id.textValue)
        var textDate: TextView = view.find(R.id.textDate)
        var textCommentary: TextView = view.find(R.id.textCommentary)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyViewHolder {
        val itemView = LayoutInflater.from(parent.context)
                .inflate(R.layout.transaction_item, parent, false)

        return MyViewHolder(itemView)
    }

    override fun onBindViewHolder(holder: MyViewHolder, position: Int) {
        val transactionItem = transactionsList[position]

        val type = Typeface.createFromAsset(holder.itemView.context?.assets, "font/roboto_regular.ttf")
        val typeBold = Typeface.createFromAsset(holder.itemView.context?.assets, "font/roboto_medium.ttf")

        when(transactionItem.direction){
            "DEBIT" -> {
                holder.textValue.textColor = ContextCompat.getColor(holder.itemView.context, R.color.darkGrey)
            }

            else-> {
                holder.textValue.textColor = ContextCompat.getColor(holder.itemView.context, R.color.lightBlue)
            }
        }

        holder.textValue.text = transactionItem.amount.toString() + " \u20BD"

        holder.textCommentary.text = transactionItem.description

        var format: SimpleDateFormat = SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
        val timezoneUTC: TimeZone = TimeZone.getTimeZone("Europe/Moscow")
        format.timeZone = timezoneUTC
        val date: Date = format.parse(transactionItem.date)

        val timezoneDefault: TimeZone = TimeZone.getDefault()
        format = SimpleDateFormat("dd.MM.yyyy HH:mm", Locale("ru"))
        format.timeZone = timezoneDefault
        val createdAt: String = format.format(date)
        holder.textDate.text = createdAt

        holder.textValue.typeface = typeBold
        holder.textCommentary.typeface = typeBold
        holder.textDate.typeface = type
    }

    override fun getItemCount(): Int {
        return transactionsList.size
    }
}
