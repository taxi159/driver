package app.pollycabcar.driver.model

import com.google.gson.annotations.SerializedName

class StatusResponse {

    @SerializedName("status")
    var status: Int? = null

}