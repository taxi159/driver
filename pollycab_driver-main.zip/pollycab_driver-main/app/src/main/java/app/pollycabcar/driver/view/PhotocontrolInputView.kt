package app.pollycabcar.driver.view

import android.content.Context
import android.graphics.drawable.Drawable
import android.util.AttributeSet
import android.view.LayoutInflater
import android.view.View
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.TextView
import androidx.constraintlayout.widget.ConstraintLayout
import app.pollycabcar.driver.R
import com.bumptech.glide.Glide
import kotlinx.android.synthetic.main.chat_with_support_fragment.*
import java.io.File

class PhotocontrolInputView(context: Context, attrs: AttributeSet) : ConstraintLayout(context, attrs) {

    private val title: TextView
    private val containerPhoto: ConstraintLayout
    private val containerChoosePhoto: ConstraintLayout
    private val photoImageView: ImageView
    private val buttonDeletePhoto: ImageButton
    private var listener: OnClickListener? = null

    init {
        val service = Context.LAYOUT_INFLATER_SERVICE
        val li = getContext().getSystemService(service) as LayoutInflater
        val layout = li.inflate(R.layout.view_photocontrol_input, this, true) as ConstraintLayout

        this.title = layout.findViewById(R.id.title)
        this.containerPhoto = layout.findViewById(R.id.container_photo)
        this.containerChoosePhoto = layout.findViewById(R.id.container_choose_photo)
        this.photoImageView = layout.findViewById(R.id.iv_photo)
        this.buttonDeletePhoto = layout.findViewById(R.id.b_delete_photo)

        this.buttonDeletePhoto.setOnClickListener {
            listener?.onPhotoDeleteClick(tag.toString())
            hideImage()
        }

        this.containerChoosePhoto.setOnClickListener {
            listener?.onPhotoChooseClick(this, tag.toString())
        }
    }

    fun setTitle(title: String) {
        this.title.text = title
    }

    fun showImage(filePath: String?) {
        this.containerChoosePhoto.visibility = View.GONE
        this.containerPhoto.visibility = View.VISIBLE
        Glide.with(context!!).load(filePath).into(this.photoImageView)
    }

    private fun hideImage() {
        this.containerPhoto.visibility = View.GONE
        this.containerChoosePhoto.visibility = View.VISIBLE
    }

    fun getListener(): OnClickListener? {
        return listener
    }

    fun setListener(listener: OnClickListener?) {
        this.listener = listener
    }

    interface OnClickListener {
        fun onPhotoChooseClick(input: PhotocontrolInputView, tag: String)
        fun onPhotoDeleteClick(tag: String)
    }

}
