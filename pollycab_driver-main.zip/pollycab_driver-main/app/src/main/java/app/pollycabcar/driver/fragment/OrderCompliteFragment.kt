package app.pollycabcar.driver.fragment

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import app.pollycabcar.driver.R
import app.pollycabcar.driver.adapter.ServicesAdapter
import app.pollycabcar.driver.model.DataResponse
import app.pollycabcar.driver.model.DriverModel
import app.pollycabcar.driver.model.OrderInfoResponse
import app.pollycabcar.driver.repo.ProfileRepository
import com.google.gson.Gson
import com.pixplicity.easyprefs.library.Prefs
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.disposables.Disposable
import io.reactivex.schedulers.Schedulers
import kotlinx.android.synthetic.main.order_completed_fragment.*
import org.jetbrains.anko.support.v4.toast


class OrderCompliteFragment : BaseFragment() {

    private lateinit var adapter: ServicesAdapter
    private var isForBack: Boolean = false
    private var infoDisposable: Disposable? = null
    private var statusDisposable: Disposable? = null

    private var orderId: Int = 0
    private var latitude: String = "-"
    private var longitude: String = "-"

    override fun onStart() {
        super.onStart()
        changeFont()

        orderId = arguments?.getInt(ARG_ORDER_ID)!!
        latitude = Prefs.getDouble("my_latitude", 0.0).toString()
        longitude = Prefs.getDouble("my_longitude", 0.0).toString()

        getOrderInfo(orderId)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        retainInstance = true
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?,
                              savedInstanceState: Bundle?): View? {
        val view = inflater.inflate(R.layout.order_completed_fragment, container, false)

        return view
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        toolbar.setNavigationIcon(R.drawable.ic_menu)
        toolbar.setNavigationOnClickListener {
            mainActivity.hardReplaceFragment(MainFragment())
        }

        btnFinishOrder.setOnClickListener {
            isForBack = true

            finishOrder()
        }
    }

    private fun changeFont(){
        changeFontInTextView(tripCostText)
        changeFontInTextView(tv_payment_type)

        changeFontInTextViewBold(ratingClientText)
        changeFontInTextViewBold(tripCostValueText)
        changeFontInTextViewBold(tv_to_pay_value)
        changeFontInTextViewBold(finishOrderText)
    }

    private fun getOrderInfo(id: Int){
        showProgress(true)
        infoDisposable = taxiService.value.getOrderInfo(loginService.value.accessToken, id)
                .subscribeOn(Schedulers.newThread())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe({ t: OrderInfoResponse ->
                    if (t.status == "success"){
                        if (t.orderInfo != null) {
                            toolbar.title = getString(R.string.orderWithId) + t.orderInfo!!.id

                            t.orderInfo!!.resultTripCost?.let { tripCostValueText.text = it.toString() + " \u20BD"}

                            when(t.orderInfo!!.paymentType){
                                0 -> tv_payment_type.text = getString(R.string.payment_type_full_nal)
                                1 -> tv_payment_type.text = getString(R.string.payment_type_full_bez_nal)
                                2 -> tv_payment_type.text = getString(R.string.payment_type_full_virtual)
                                3 -> {
                                    tv_payment_type.text = getString(R.string.payment_type_full_organization)
                                    to_pay_container.visibility = View.VISIBLE
                                    t.orderInfo!!.clientAmount?.let { tv_to_pay_value.text = it.toString() + " \u20BD"}
                                }
                            }
                        }
                    } else if(t.status == "error" && t.error == "no_access") {
                        toast("Доступ запрещён")
                        mainActivity.hardReplaceFragment(MainFragment())
                    }

                    showProgress(false)
                }, { e ->
                    e.printStackTrace()
                    showProgress(false)
                    toast(e.localizedMessage)
                })

    }

    override fun onStop() {
        super.onStop()
        infoDisposable?.dispose()
        statusDisposable?.dispose()
    }

    private fun finishOrder(){
        val rating = ratingBar.rating.toInt()

        showProgress(true)
        statusDisposable = taxiService.value.finishOrder(loginService.value.accessToken, orderId, rating)
                .subscribeOn(Schedulers.newThread())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe({ t: DataResponse ->
                    if (t.status == "success") {
                        statusDisposable?.dispose()
                        statusDisposable = taxiService.value.getDriverInfo(loginService.value.accessToken)
                                .subscribeOn(Schedulers.newThread())
                                .observeOn(AndroidSchedulers.mainThread())
                                .subscribe({ t: DriverModel ->
                                    showProgress(false)
                                    ProfileRepository.instance?.setProfile(t)

                                    if (t.photocontrolStatus != DriverModel.PhotocontrolStatus.Accept && t.activeOrder == null) {
                                        mainActivity.hardReplaceFragment(PhotocontrolFragment())
                                    } else {
                                        mainActivity.getOrders()
                                        mainActivity.hardReplaceFragment(MainFragment())
                                    }
                                }, { e ->
                                    e.printStackTrace()
                                    showProgress(false)
                                })
                    }
                }, { e ->
                    e.printStackTrace()
                    toast(e.localizedMessage)
                })
    }

    companion object {
        val ARG_ORDER_ID = "arg_order_id"

        fun newInstance(id: Int): OrderCompliteFragment {

            val args = Bundle()

            args.putInt(ARG_ORDER_ID, id)

            val fragment = OrderCompliteFragment()
            fragment.arguments = args
            return fragment
        }
    }
}
