package app.pollycabcar.driver.adapter


import android.graphics.Typeface
import androidx.recyclerview.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView
import app.pollycabcar.driver.R
import app.pollycabcar.driver.model.RideModel
import kotlinx.android.synthetic.main.trip_address.view.*
import org.jetbrains.anko.find
import java.text.SimpleDateFormat
import java.util.*
import kotlin.collections.ArrayList

class RidesAdapter : RecyclerView.Adapter<RidesAdapter.MyViewHolder>() {

    private var rideList: ArrayList<RideModel> = arrayListOf()

    fun setList(list: ArrayList<RideModel>) {
        rideList = list
        notifyDataSetChanged()
    }

    inner class MyViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        var tvOrderId: TextView = view.find(R.id.tv_order_id)
        var tvPrice: TextView = view.find(R.id.tv_price)
        var tvDateTime: TextView = view.find(R.id.tv_date_time)
        val tvAddressStart: TextView  = view.find(R.id.tv_address_start)
        val dividerAddressStart: View = view.find(R.id.divider_address_start)
        val addressesContainer: LinearLayout  = view.find(R.id.addresses_container)
        var tvPaymentType: TextView = view.find(R.id.tv_payment_type)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyViewHolder {
        val itemView = LayoutInflater.from(parent.context)
                .inflate(R.layout.order_item, parent, false)

        return MyViewHolder(itemView)
    }

    override fun onBindViewHolder(holder: MyViewHolder, position: Int) {
        val rideItem = rideList[position]

        val type = Typeface.createFromAsset(holder.itemView.context?.assets, "font/roboto_regular.ttf")
        val typeBold = Typeface.createFromAsset(holder.itemView.context?.assets, "font/roboto_medium.ttf")

        holder.tvOrderId.text = "№" + rideItem.id
        holder.tvPrice.text = rideItem.resultTripCost.toString() + " \u20BD"

        var format: SimpleDateFormat = SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
        val timezoneUTC: TimeZone = TimeZone.getTimeZone("Europe/Moscow")
        format.timeZone = timezoneUTC
        val date: Date = format.parse(rideItem.deadline)

        val timezoneDefault: TimeZone = TimeZone.getDefault()
        format = SimpleDateFormat("E, d MMM HH:mm", Locale("ru"))
        format.timeZone = timezoneDefault
        val finishedAt: String = format.format(date)
        holder.tvDateTime.text = finishedAt

        when(rideItem.paymentType) {
            0 -> holder.tvPaymentType.text = "наличными"
            1 -> holder.tvPaymentType.text = "банк. карта"
            2 -> holder.tvPaymentType.text = "вирт. счёт"
        }

        holder.addressesContainer.removeAllViews()

        rideItem.geoPoints?.forEachIndexed { index, geoPoint ->
            if (index == 0) {
                holder.tvAddressStart.text = rideItem.addresses?.get(0)

                if (rideItem.geoPoints?.size == 1) {
                    val view = LayoutInflater.from(holder.itemView.context)
                            .inflate(R.layout.trip_address, holder.addressesContainer, false)

                    val address = view.tv_address
                    address.text = "По указанию"

                    if (index == rideItem.geoPoints?.size!! - 1) {
                        val divider = view.divider
                        divider.visibility = View.GONE
                    }

                    holder.addressesContainer.addView(view)
                }
            } else {
                val view = LayoutInflater.from(holder.itemView.context)
                        .inflate(R.layout.trip_address, holder.addressesContainer, false)

                val address = view.tv_address
                address.text = rideItem.addresses?.get(index)

                if (index == rideItem.geoPoints?.size!! - 1) {
                    val divider = view.divider
                    divider.visibility = View.GONE
                }

                holder.addressesContainer.addView(view)
            }
        }

        holder.tvOrderId.typeface = type
        holder.tvPrice.typeface = typeBold
        holder.tvDateTime.typeface = type
        holder.tvPaymentType.typeface = type
    }

    override fun getItemCount(): Int {
        return rideList.size
    }
}
