package app.pollycabcar.driver.model

import com.google.gson.annotations.SerializedName

class SessionIdResponse {

    @SerializedName("status")
    var status: String? = null

    @SerializedName("session_id")
    var sessionId: String? = null
}