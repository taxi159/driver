package app.pollycabcar.driver.fragment

import android.os.Bundle
import androidx.recyclerview.widget.DefaultItemAnimator
import androidx.recyclerview.widget.LinearLayoutManager
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import app.pollycabcar.driver.R
import app.pollycabcar.driver.adapter.RidesAdapter
import app.pollycabcar.driver.model.OrdersResponse
import app.pollycabcar.driver.util.DateFormatter
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.disposables.Disposable
import io.reactivex.schedulers.Schedulers
import kotlinx.android.synthetic.main.rides_fragment.*
import org.jetbrains.anko.support.v4.toast
import java.text.SimpleDateFormat
import java.util.*


class RidesFragment : BaseFragment() {

    private lateinit var ridesAdapter: RidesAdapter
    private var ridesDisposable: Disposable? = null

    override fun onStart() {
        super.onStart()
        changeFontInTextViewBold(ridesNotFoundText)

        getLastRides()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        retainInstance = true
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?,
                              savedInstanceState: Bundle?): View? {
        val view = inflater.inflate(R.layout.rides_fragment, container, false)

        return view
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        toolbar.setNavigationIcon(R.drawable.ic_arrow_back)
        toolbar.setNavigationOnClickListener {
            goBack()
        }

        ridesAdapter = RidesAdapter()
        rvRides.layoutManager = LinearLayoutManager(context, LinearLayoutManager.VERTICAL, false)
        rvRides.itemAnimator = DefaultItemAnimator()
        rvRides.adapter = ridesAdapter
        rvRides.isNestedScrollingEnabled = false
    }

    private fun getLastRides() {
        val endDate = Calendar.getInstance().time
        val endDateString = DateFormatter.getStringUTCFromDate(endDate)
        val startDate = DateFormatter.datePlusDays(endDate, -7)
        val startDateString = DateFormatter.getStringUTCFromDate(startDate)

        println(startDateString)
        println(endDateString)

        showProgress(true)
        ridesDisposable = taxiService.value.getLastOrders(loginService.value.accessToken, startDateString, endDateString)
                .subscribeOn(Schedulers.newThread())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe({ t: OrdersResponse ->

                    if (t.status == "success"){
                        if (t.orders?.size!! > 0){
                            t.orders!!.sortWith(Comparator { o1, o2 ->
                                o2.id!!.compareTo(o1.id!!)
                            })
                            ridesAdapter.setList(t.orders!!)
                        } else
                            ridesNotFoundText.visibility = View.VISIBLE
                    } else if(t.status == "error" && t.error == "no_access") {
                        toast("Доступ запрещён")
                        goBack()
                    }

                    showProgress(false)
                }, { e ->
                    e.printStackTrace()
                    showProgress(false)
                })
    }

    override fun onStop() {
        super.onStop()
        ridesDisposable?.dispose()
    }
}
