package app.pollycabcar.driver.fragment

import android.app.Dialog
import android.graphics.Typeface
import android.os.Bundle
import android.os.Handler
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.Observer
import app.pollycabcar.driver.R
import app.pollycabcar.driver.model.DriverModel
import app.pollycabcar.driver.repo.ProfileRepository
import com.bumptech.glide.Glide
import com.google.gson.Gson
import com.pixplicity.easyprefs.library.Prefs
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.disposables.Disposable
import io.reactivex.schedulers.Schedulers
import kotlinx.android.synthetic.main.account_settings_fragment.*
import org.jetbrains.anko.find
import org.jetbrains.anko.support.v4.toast


class AccountSettingsFragment : BaseFragment() {

    private var infoDisposable: Disposable? = null

    override fun onStart() {
        super.onStart()
        changeFont()
        checkNavigation()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        retainInstance = true
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        return inflater.inflate(R.layout.account_settings_fragment, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        subscribeToProfile()

        rightBtn.setOnClickListener {
            showProgress(true)
            val handler = Handler()
            handler.postDelayed({
                showProgress(false)
                mainActivity.hardReplaceFragment(MainFragment())
            }, 2000)
        }

        leftBtn.setOnClickListener {
            mainActivity.hardReplaceFragment(MainFragment())
        }

        exitBtn.setOnClickListener {
            mainActivity.finish()
        }

        layoutNavigation.setOnClickListener {
            showDialogForNavigationAction()
        }
    }

    private fun subscribeToProfile() {
        val liveData: MutableLiveData<DriverModel> =
                ProfileRepository.instance!!.profileLiveData
        liveData.observe(this, Observer { t ->
            userNameTv.text = "${t.name} ${t.middleName} ${t.surname}"

            if (t.photo != null) {

                if (t.photo!!.isNotEmpty()) {
                    Glide.with(context!!).load(t.photo + "/performer?token=${loginService.value.accessToken}").into(userImg)
                } else {
                    Glide.with(context!!).load(R.drawable.avatar_placeholder).into(userImg)
                }
            }

            t.rating?.let { starCount.text = it }

            autoTv.text = t.mark + " " + t.model + " - " + t.stateNumber
        })
    }

    private fun checkNavigation(){

        when (Prefs.getInt("navigation", 0)){
            2 -> {
                icon.setImageResource(R.drawable.togis_img)
                yandexText.text = "2GIS"
                Prefs.putInt("navigation", 2)
            }

            else -> {
                icon.setImageResource(R.drawable.ya_img)
                yandexText.text = "Яндекс"
                Prefs.putInt("navigation", 1)
            }
        }
    }

    private fun showDialogForNavigationAction() {
        context?.let {
            val mDialog = Dialog(it, R.style.CustomDialog)
            mDialog.setCancelable(true)
            mDialog.setContentView(R.layout.dialog_for_navigation)

            val typeBold = Typeface.createFromAsset(context?.assets, "font/opensans_bold.ttf")

            val title = mDialog.find<TextView>(R.id.title)
            val firstButtonText = mDialog.find<TextView>(R.id.firstButtonText)
            val secondButtonText = mDialog.find<TextView>(R.id.secondButtonText)
            title.typeface = typeBold
            firstButtonText.typeface = typeBold
            secondButtonText.typeface = typeBold
            val yaLayout = mDialog.find<LinearLayout>(R.id.yaLayout)
            val toGisLayout = mDialog.find<LinearLayout>(R.id.toGisLayout)

            yaLayout.setOnClickListener {
                Prefs.putInt("navigation", 1)
                checkNavigation()
                mDialog.dismiss()
            }

            toGisLayout.setOnClickListener {
                Prefs.putInt("navigation", 2)
                checkNavigation()
                mDialog.dismiss()
            }

            mDialog.show()
        }
    }


    private fun changeFont(){
        changeFontInTextView(starCount)
        changeFontInTextView(textTitle)
        changeFontInTextView(autoTv)
        changeFontInTextView(navigationText)

        changeFontInTextViewBold(userNameTv)
        changeFontInTextViewBold(yandexText)
        changeFontInTextViewBold(textExit)
    }

    override fun onStop() {
        super.onStop()
        infoDisposable?.dispose()
    }
}
