package app.pollycabcar.driver.fragment

import android.Manifest
import android.app.Activity
import android.app.Dialog
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.ContextWrapper
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.Observer
import app.pollycabcar.driver.R
import app.pollycabcar.driver.model.DataResponse
import app.pollycabcar.driver.model.DriverModel
import app.pollycabcar.driver.repo.ProfileRepository
import app.pollycabcar.driver.view.PhotocontrolInputView
import com.bumptech.glide.Glide
import com.google.gson.Gson
import com.karumi.dexter.Dexter
import com.karumi.dexter.MultiplePermissionsReport
import com.karumi.dexter.PermissionToken
import com.karumi.dexter.listener.PermissionRequest
import com.karumi.dexter.listener.multi.MultiplePermissionsListener
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.disposables.Disposable
import io.reactivex.schedulers.Schedulers
import kotlinx.android.synthetic.main.chat_with_support_fragment.*
import kotlinx.android.synthetic.main.fragment_photocontrol.*
import kotlinx.android.synthetic.main.fragment_photocontrol_car_photo.*
import kotlinx.android.synthetic.main.fragment_photocontrol_decline.*
import kotlinx.android.synthetic.main.fragment_photocontrol_documents_photo.*
import kotlinx.android.synthetic.main.fragment_photocontrol_requested.*
import kotlinx.android.synthetic.main.fragment_photocontrol_sent.*
import okhttp3.MediaType
import okhttp3.MultipartBody
import okhttp3.RequestBody
import org.jetbrains.anko.find
import org.jetbrains.anko.support.v4.toast
import retrofit2.HttpException
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.io.OutputStream
import java.text.SimpleDateFormat
import java.util.*
import kotlin.collections.HashMap


class PhotocontrolFragment : BaseFragment(), PhotocontrolInputView.OnClickListener {

    private val REQUEST_IMAGE = 200

    private var infoDisposable: Disposable? = null
    private var isGranted: Boolean? = false
    private var file: File? = null
    private var files: HashMap<String, File> = HashMap()
    private var activePhotocontrolInput: PhotocontrolInputView? = null
    private var profile: DriverModel? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        retainInstance = true
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        return inflater.inflate(R.layout.fragment_photocontrol, container, false)
    }

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)
        subscribeToProfile()
        showPermissions()
    }

    private fun subscribeToProfile() {
        val liveData: MutableLiveData<DriverModel> =
                ProfileRepository.instance!!.profileLiveData
        liveData.observe(this, Observer { t ->
            profile = t

            when (t.photocontrolStatus) {
                DriverModel.PhotocontrolStatus.Requested -> {
                    setView(R.layout.fragment_photocontrol_requested)
                    changeFontInTextView(tv_requested_photocontrol)

                    b_start_photocontrol.setOnClickListener {
                        if (t.photocontrolType == DriverModel.PhotocontrolType.All || t.photocontrolType == DriverModel.PhotocontrolType.Car) {
                            startCarPhotocontrol()
                        } else {
                            startDocumentsPhotocontrol()
                        }
                    }
                }
                DriverModel.PhotocontrolStatus.Decline -> {
                    setView(R.layout.fragment_photocontrol_decline)
                    changeFontInTextView(tv_decline_photocontrol)

                    tv_decline_photocontrol.text = "Фотоконтроль не пройден. Комментарий: ${t.photocontrolComment}. Необходимо повторно пройти фотоконтроль."

                    b_repeat_photocontrol.setOnClickListener {
                        if (t.photocontrolType == DriverModel.PhotocontrolType.All || t.photocontrolType == DriverModel.PhotocontrolType.Car) {
                            startCarPhotocontrol()
                        } else {
                            startDocumentsPhotocontrol()
                        }
                    }
                }
                DriverModel.PhotocontrolStatus.Sent -> {
                    setView(R.layout.fragment_photocontrol_sent)
                    changeFontInTextView(tv_sent_photocontrol)
                }
                else -> {
                    mainActivity.getOrders()
                    mainActivity.hardReplaceFragment(MainFragment())
                }
            }
        })
    }

    private fun setView(layout: Int) {
        val view = LayoutInflater.from(context)
                .inflate(layout, placeholder, false)
        placeholder.removeAllViews()
        placeholder.addView(view)
    }

    private fun startCarPhotocontrol() {
        setView(R.layout.fragment_photocontrol_car_photo)

        front_car_photo_input.setTitle(getString(R.string.front_car_photo))
        front_car_photo_input.setListener(this)

        back_car_photo_input.setTitle(getString(R.string.back_car_photo))
        back_car_photo_input.setListener(this)

        right_side_car_photo_input.setTitle(getString(R.string.right_side_car_photo))
        right_side_car_photo_input.setListener(this)

        left_side_car_photo_input.setTitle(getString(R.string.left_side_car_photo))
        left_side_car_photo_input.setListener(this)

        front_seats_of_car_photo_input.setTitle(getString(R.string.front_seats_of_car_photo))
        front_seats_of_car_photo_input.setListener(this)

        back_seats_of_car_photo_input.setTitle(getString(R.string.back_seats_of_car_photo))
        back_seats_of_car_photo_input.setListener(this)

        boot_of_car_photo_input.setTitle(getString(R.string.boot_of_car_photo))
        boot_of_car_photo_input.setListener(this)

        b_continue_photocontrol.setOnClickListener {
            if (files.count() != 7) {
                toast("Необходимо сделать все фотографии автомобиля")
                return@setOnClickListener
            }

            if (profile?.photocontrolType == DriverModel.PhotocontrolType.All) {
                startDocumentsPhotocontrol()
            } else {
                updatePhotocontrol()
            }
        }
    }

    private fun startDocumentsPhotocontrol() {
        setView(R.layout.fragment_photocontrol_documents_photo)

        driver_license_photo_input.setTitle(getString(R.string.driver_license_photo))
        driver_license_photo_input.setListener(this)

        passport_photo_input.setTitle(getString(R.string.passport_photo))
        passport_photo_input.setListener(this)

        selfie_driver_license_photo_input.setTitle(getString(R.string.selfie_driver_license_photo))
        selfie_driver_license_photo_input.setListener(this)

        selfie_passport_photo_input.setTitle(getString(R.string.selfie_passport_photo))
        selfie_passport_photo_input.setListener(this)

        vehicle_registration_certificate_photo_input.setTitle(getString(R.string.vehicle_registration_certificate_photo))
        vehicle_registration_certificate_photo_input.setListener(this)

        b_finish_photocontrol.setOnClickListener {
            if ((profile?.photocontrolType == DriverModel.PhotocontrolType.All && files.count() != 12)
                    || (profile?.photocontrolType == DriverModel.PhotocontrolType.Documents && files.count() != 5)) {
                toast("Необходимо сделать все фотографии документов")
                return@setOnClickListener
            }

            updatePhotocontrol()
        }
    }

    private fun updatePhotocontrol() {
        val token = MultipartBody.Part.createFormData("token", loginService.value.accessToken)
        val body: ArrayList<MultipartBody.Part> = ArrayList<MultipartBody.Part>()

        files.forEach {
            body.add(prepareFilePart(it.key, it.value))
        }

        showProgress(true)
        infoDisposable = taxiService.value.updatePhotocontrol(token, body)
                .subscribeOn(Schedulers.newThread())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe({ t: DataResponse ->
                    showProgress(false)

                    if (t.status == "success"){
                        setView(R.layout.fragment_photocontrol_sent)
                        changeFontInTextView(tv_sent_photocontrol)

                        if (files.isNotEmpty()){
                            files.forEach {
                                it.value.deleteOnExit()
                            }
                        }
                    }
                }, { e ->
                    val gson = Gson()
                    val error: HttpException = e as HttpException
                    val errorBody: String = error.response().errorBody()!!.string()
                    val response = gson.fromJson(errorBody, DataResponse::class.java)

                    if (response.status == "error" && response.message != null) {
                        toast(response.message!!)
                    } else {
                        e.printStackTrace()
                        println(errorBody)
                        toast(e.localizedMessage)
                    }

                    showProgress(false)
                })
    }

    private fun prepareFilePart(name: String?, file: File?): MultipartBody.Part {
        val requestFile = RequestBody.create(MediaType.parse("image/png"), file!!)
        return MultipartBody.Part.createFormData(name, file.name, requestFile)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

        if (requestCode == REQUEST_IMAGE && resultCode == Activity.RESULT_OK) {
            activePhotocontrolInput?.showImage(file?.absolutePath)
            files[activePhotocontrolInput?.tag.toString()] = file!!

            file = null
            activePhotocontrolInput = null
        } else {
            file = null
        }
    }

    override fun onPhotoChooseClick(input: PhotocontrolInputView, tag: String) {
        activePhotocontrolInput = input

        if (!isGranted!!){
            showPermissions()
        } else {
            // Create an image file name
            val timeStamp: String = SimpleDateFormat("yyyyMMdd_HHmmss").format(Date())
            val storageDir: File? = mainActivity.getExternalFilesDir(Environment.DIRECTORY_PICTURES)
            file = File.createTempFile(
                    "JPEG_${timeStamp}_", /* prefix */
                    ".jpg", /* suffix */
                    storageDir /* directory */
            )

            val imageUri = if(Build.VERSION.SDK_INT >= 24){
                FileProvider.getUriForFile(context!!, "${context?.packageName}.fileprovider", file!!)
            } else {
                Uri.fromFile(file!!)
            }

            val intent = Intent(MediaStore.ACTION_IMAGE_CAPTURE)
            intent.putExtra(MediaStore.EXTRA_OUTPUT, imageUri)
            startActivityForResult(intent, REQUEST_IMAGE)
        }
    }

    override fun onPhotoDeleteClick(tag: String) {
        if (files.containsKey(tag)) {
            val file = files[tag]
            file?.deleteOnExit()
            files.remove(tag)
        }
    }

    override fun onStop() {
        super.onStop()
        infoDisposable?.dispose()
    }

    private fun showPermissions(){
        Dexter.withActivity(mainActivity)
                .withPermissions(Manifest.permission.CAMERA)
                .withListener(object : MultiplePermissionsListener {

                    override fun onPermissionRationaleShouldBeShown(permissions: MutableList<PermissionRequest>?, token: PermissionToken?) {
                        token?.continuePermissionRequest()
                    }

                    override fun onPermissionsChecked(report: MultiplePermissionsReport?) {
                        try {
                            isGranted = report!!.areAllPermissionsGranted()
                        } catch (e: IOException) {
                            toast("Could not create file!")
                        }
                    }
                }).check()
    }

    companion object {
        private val REQUEST_IMAGE = 200
    }
}
