package app.pollycabcar.driver.adapter

import android.graphics.Typeface
import androidx.recyclerview.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.TextView
import app.pollycabcar.driver.R
import app.pollycabcar.driver.network.LoginService
import app.pollycabcar.driver.model.AnswerModel
import com.bumptech.glide.Glide
import com.github.salomonbrys.kodein.LazyKodein
import com.github.salomonbrys.kodein.android.appKodein
import com.github.salomonbrys.kodein.instance
import org.jetbrains.anko.find
import java.text.SimpleDateFormat
import java.util.*

class AnswersAdapter(private val callback: ((image: String) -> Unit)? = null) : RecyclerView.Adapter<AnswersAdapter.TextMessageHolder>() {

    private var answersList: List<AnswerModel> = listOf()

    fun setList(list: List<AnswerModel>) {
        answersList = list
        notifyDataSetChanged()
    }

    class TextMessageHolder constructor(view: View) : RecyclerView.ViewHolder(view) {
        internal var textMessage: TextView = view.find(R.id.textMessage)
        internal var imageLayout: FrameLayout = view.find(R.id.imageLayout)
        internal var imageView: ImageView = view.find(R.id.imageView)
        internal var textDate: TextView = view.find(R.id.textDate)
    }

    override fun getItemViewType(position: Int): Int {
        val item = answersList[position]

        if (item.accountType == 2) {
            return MY_TEXT
        } else {
            return TEXT
        }

    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): TextMessageHolder {
        var itemView: View? = null

        when (viewType) {
            TEXT -> {
                itemView = LayoutInflater.from(parent.context)
                        .inflate(R.layout.support_user_item, parent, false)
            }
            MY_TEXT -> {
                itemView = LayoutInflater.from(parent.context)
                        .inflate(R.layout.support_my_item, parent, false)
            }
        }

        return TextMessageHolder(itemView!!)
    }

    override fun getItemCount(): Int = answersList.size

    override fun onBindViewHolder(holder: TextMessageHolder, position: Int) {
        val report = answersList[position]

        val type = Typeface.createFromAsset(holder.itemView.context!!.assets, "font/roboto_regular.ttf")
        val typeBold = Typeface.createFromAsset(holder.itemView.context!!.assets, "font/roboto_medium.ttf")

        val loginService: LoginService = LazyKodein(holder.itemView.context!!.applicationContext.appKodein).instance<LoginService>().value

        holder.textMessage.text = report.answer

        holder.textMessage.typeface = type

        if (report.pathFile != null && report.pathFile!!.isNotEmpty()){
            holder.imageLayout.visibility = View.VISIBLE
            Glide.with(holder.itemView.context).load(report.pathFile + "/performer?token=${loginService.accessToken}").into(holder.imageView)
        } else {
            holder.imageLayout.visibility = View.GONE
        }

        var format: SimpleDateFormat = SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
        val timezoneUTC: TimeZone = TimeZone.getTimeZone("Europe/Moscow")
        format.timeZone = timezoneUTC
        val date: Date = format.parse(report.createdAt)

        val timezoneDefault: TimeZone = TimeZone.getDefault()
        format = SimpleDateFormat("E, d MMM HH:mm", Locale("ru"))
        format.timeZone = timezoneDefault
        val createdAt: String = format.format(date)
        holder.textDate.text = createdAt

        holder.imageLayout.setOnClickListener {
            callback?.invoke(report.pathFile!!)
        }
    }

    companion object {

        private val TEXT = 1
        private val MY_TEXT = 2
    }
}