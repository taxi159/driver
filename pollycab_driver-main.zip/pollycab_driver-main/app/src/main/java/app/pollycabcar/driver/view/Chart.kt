package app.pollycabcar.driver.view

import app.pollycabcar.driver.model.WeekDay
import android.content.Context
import android.graphics.Color
import com.github.mikephil.charting.charts.BarChart
import com.github.mikephil.charting.components.AxisBase
import com.github.mikephil.charting.components.Legend
import com.github.mikephil.charting.components.XAxis
import com.github.mikephil.charting.components.YAxis
import com.github.mikephil.charting.data.BarData
import com.github.mikephil.charting.data.BarDataSet
import com.github.mikephil.charting.data.BarEntry
import com.github.mikephil.charting.data.Entry
import com.github.mikephil.charting.formatter.IAxisValueFormatter
import com.github.mikephil.charting.formatter.IValueFormatter
import com.github.mikephil.charting.utils.ViewPortHandler
import app.pollycabcar.driver.R
import app.pollycabcar.driver.model.DriverModel
import app.pollycabcar.driver.util.DateFormatter
import java.util.*

class Chart(chart: BarChart, context: Context, animation: Boolean) {
    private val chart: BarChart
    private val context: Context
    private val animation: Boolean
    private fun initChart() {

        //Axis
        val yAxis: YAxis = chart.axisLeft
        yAxis.isEnabled = false
        yAxis.textSize = 13F
        yAxis.textColor = Color.WHITE
        yAxis.axisMinimum = 0f
        yAxis.valueFormatter = object : IAxisValueFormatter {
            override fun getFormattedValue(value: Float, axis: AxisBase?): String {
                return ""
            }
        }
        val xAxis: XAxis = chart.xAxis
        xAxis.setDrawGridLines(false)
        xAxis.setTextSize(15F)
        xAxis.textColor = Color.WHITE
        xAxis.setAxisMinimum(0F)
        xAxis.axisMaximum = 7f
        xAxis.setGranularity(1F)
        xAxis.setCenterAxisLabels(true)
        xAxis.position = XAxis.XAxisPosition.BOTTOM

        //legend
        val l: Legend = chart.legend
        l.formSize = 20f
        l.setTextSize(15F)
        l.textColor = Color.WHITE
        l.formToTextSpace = 5f
        l.xEntrySpace = 10f


        //property
        chart.setTouchEnabled(false)
        chart.axisRight.isEnabled = false
        chart.description.isEnabled = false
        chart.setClipValuesToContent(false)
        chart.setNoDataTextColor(context.resources.getColor(R.color.blue))
    }

    fun setData(weekDays: List<WeekDay>) {
        val totalByDayOfWeek: MutableList<Float> = ArrayList()
        totalByDayOfWeek.add(0f)
        totalByDayOfWeek.add(0f)
        totalByDayOfWeek.add(0f)
        totalByDayOfWeek.add(0f)
        totalByDayOfWeek.add(0f)
        totalByDayOfWeek.add(0f)
        totalByDayOfWeek.add(0f)
        for (weekDay in weekDays) {
            val date: Date? = DateFormatter.getDateFromStringUTCWithoutTime(weekDay.date!!)
            if (date != null) {
                val day: Int = DateFormatter.getDayOfWeek(date)
                val numberOnly: String = weekDay.total!!.replace("[^0-9]", "")
                val total = numberOnly.toFloat()
                totalByDayOfWeek[day] = total
            }
        }
        val entries: MutableList<BarEntry> = ArrayList<BarEntry>()
        entries.add(BarEntry(0.5f, totalByDayOfWeek[0]))
        entries.add(BarEntry(1.5f, totalByDayOfWeek[1]))
        entries.add(BarEntry(2.5f, totalByDayOfWeek[2]))
        entries.add(BarEntry(3.5f, totalByDayOfWeek[3]))
        entries.add(BarEntry(4.5f, totalByDayOfWeek[4]))
        entries.add(BarEntry(5.5f, totalByDayOfWeek[5]))
        entries.add(BarEntry(6.5f, totalByDayOfWeek[6]))
        val set = BarDataSet(entries, "BarDataSet")
        set.color = context.resources.getColor(R.color.blue)
        set.valueFormatter = object : IValueFormatter {
            override fun getFormattedValue(value: Float, entry: Entry?, dataSetIndex: Int, viewPortHandler: ViewPortHandler?): String {
                return "$value \u20BD"
            }
        }
        val data = BarData(set)
        data.barWidth = 0.5f // set custom bar width
        data.setValueTextColor(context.resources.getColor(R.color.blue))
        data.setValueTextSize(10f)
        chart.data = data
        chart.setFitBars(true) // make the x axis fit exactly all bars
        if (animation) chart.animateY(1000)
        chart.legend.isEnabled = false
        chart.setBackgroundColor(context.resources.getColor(R.color.white))
        chart.invalidate() // refresh
    }

    init {
        this.chart = chart
        this.context = context
        this.animation = animation
        initChart()
    }
}