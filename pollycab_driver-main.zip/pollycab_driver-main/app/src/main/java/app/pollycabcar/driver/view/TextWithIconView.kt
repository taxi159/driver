package app.pollycabcar.driver.view

import android.content.Context
import android.util.AttributeSet
import android.view.LayoutInflater
import android.view.View
import android.widget.ImageView
import android.widget.TextView
import androidx.constraintlayout.widget.ConstraintLayout
import app.pollycabcar.driver.App
import app.pollycabcar.driver.R

class TextWithIconView(context: Context?, attrs: AttributeSet?) : ConstraintLayout(context, attrs) {
    var layout: ConstraintLayout
    var icon: ImageView
    var title: TextView
    var iconCount: TextView
    var arrow: ImageView
    fun setIcon(drawable: Int) {
        icon.visibility = View.VISIBLE
        icon.setImageDrawable(context.getDrawable(drawable))
    }

    fun setTitle(title: String?) {
        this.title.text = title
    }

    fun setIconCount(text: String?) {
        iconCount.visibility = View.VISIBLE
        iconCount.text = text
    }

    fun setArrow() {
        arrow.visibility = View.VISIBLE
    }

    val textSise: Float
        get() = title.textSize

    init {
        val service = Context.LAYOUT_INFLATER_SERVICE
        val li = getContext().getSystemService(service) as LayoutInflater

        layout = li.inflate(R.layout.view_text_with_icon, this, true) as ConstraintLayout
        icon = layout.findViewById(R.id.icon)
        title = layout.findViewById(R.id.title)
        iconCount = layout.findViewById(R.id.icon_count)
        arrow = layout.findViewById(R.id.arrow)
    }
}