package app.pollycabcar.driver.model

class NewsModel (var fromWho: String?, var time: String?, var date: String?, var title: String?, var text: String?)