package app.pollycabcar.driver.repo

import androidx.lifecycle.MutableLiveData
import app.pollycabcar.driver.model.DriverModel
import app.pollycabcar.driver.model.OrderModel

class OrdersRepository {
    val ordersLiveData = MutableLiveData<ArrayList<OrderModel>>()
    fun setOrders(ordersLiveData: ArrayList<OrderModel>) {
        this.ordersLiveData.postValue(ordersLiveData)
    }

    val orders: ArrayList<OrderModel>?
        get() = ordersLiveData.value

    companion object {
        var instance: OrdersRepository? = null
            get() {
                if (field == null) {
                    field = OrdersRepository()
                }
                return field
            }
            private set
    }
}