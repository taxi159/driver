package app.pollycabcar.driver.model

import com.google.gson.annotations.SerializedName

class OrderResponse {

    @SerializedName("status")
    var status: String? = null

    @SerializedName("error")
    var error: String? = null

    @SerializedName("position_is_actual")
    var positionIsActual: Boolean? = null

    @SerializedName("hide_route_points")
    var hideRoutePoints: Boolean? = null

    @SerializedName("orders")
    var ordersOnMap: ArrayList<OrderModel>? = null
}