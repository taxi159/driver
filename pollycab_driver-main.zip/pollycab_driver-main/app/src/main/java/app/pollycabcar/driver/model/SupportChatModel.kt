package app.pollycabcar.driver.model

class SupportChatModel (var isFromMe: Boolean?, var type: String?, var name: String?, var test: String?)