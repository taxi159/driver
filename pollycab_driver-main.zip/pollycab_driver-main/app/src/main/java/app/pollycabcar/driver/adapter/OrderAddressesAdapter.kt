package app.pollycabcar.driver.adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.core.content.ContextCompat
import java.util.ArrayList
import androidx.recyclerview.widget.RecyclerView
import app.pollycabcar.driver.R
import org.jetbrains.anko.image

class OrderAddressesAdapter() : RecyclerView.Adapter<RecyclerView.ViewHolder>() {
    private var addresses: ArrayList<String> = ArrayList()
    private var hideRoutePoints: Boolean = false

    fun setList(list: ArrayList<String>, hidePoints: Boolean = false) {
        addresses = list
        hideRoutePoints = hidePoints
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        val itemView = LayoutInflater.from(parent.context)
                .inflate(R.layout.trip_address, parent,false)

        return AddressHolder(itemView)
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        if (holder is AddressHolder) {
            if (hideRoutePoints && position != 0)
                return;

            val address = addresses.get(position)

            holder.tvAddress.text = address

            if (position == 0) {
                holder.ring.setImageDrawable(ContextCompat.getDrawable(holder.itemView.context, R.drawable.ic_start_route_point))
            }

            if (position == itemCount - 1) {
                holder.divider.visibility = View.GONE
            }
        }
    }

    override fun getItemCount(): Int {
        return addresses.size
    }

    internal inner class AddressHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        var tvAddress: TextView
        var divider: View
        var ring: ImageView

        init {
            tvAddress = itemView.findViewById(R.id.tv_address)
            divider = itemView.findViewById(R.id.divider)
            ring = itemView.findViewById(R.id.iv_ring)
        }
    }
}