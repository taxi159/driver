package app.pollycabcar.driver.repo

import androidx.lifecycle.MutableLiveData
import app.pollycabcar.driver.model.Notification
import java.util.*

class NotificationRepository {
    val notificationLiveData: MutableLiveData<MutableList<Notification>> =
        MutableLiveData<MutableList<Notification>>()

    fun addNotification(notification: Notification) {
        var list: MutableList<Notification>? =
            notificationLiveData.value
        if (list == null) {
            list = ArrayList<Notification>()
        }
        list.add(notification)
        notificationLiveData.postValue(list)
    }

    fun removeNotification() {
        val list: MutableList<Notification>? =
            notificationLiveData.value
        if (list?.size != 0) {
            list?.removeAt(0)
            notificationLiveData.postValue(list)
        }
    }

    val notification: Notification?
        get() {
            val list: MutableList<Notification> =
                notificationLiveData.value
                    ?: return null
            return list[0]
        }

    var notifications: List<Notification>?
        get() = notificationLiveData.value
        set(notifications) {
            var list: MutableList<Notification>? =
                notificationLiveData.value
            if (list == null) {
                list = ArrayList<Notification>()
            }
            list.addAll(notifications!!)
            notificationLiveData.postValue(list)
        }

    companion object {
        var instance: NotificationRepository? = null
            get() {
                if (field == null) {
                    field = NotificationRepository()
                }
                return field
            }
            private set
    }
}