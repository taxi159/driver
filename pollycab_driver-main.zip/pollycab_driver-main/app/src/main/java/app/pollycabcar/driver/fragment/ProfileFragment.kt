package app.pollycabcar.driver.fragment

import android.os.Bundle
import androidx.recyclerview.widget.LinearLayoutManager
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import app.pollycabcar.driver.R
import app.pollycabcar.driver.adapter.ActionHistoryAdapter
import app.pollycabcar.driver.model.ActionHistoryResponse
import app.pollycabcar.driver.model.DriverModel
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.disposables.Disposable
import io.reactivex.schedulers.Schedulers
import kotlinx.android.synthetic.main.fragment_profile.*
import kotlinx.android.synthetic.main.transactions_fragment.toolbar
import org.jetbrains.anko.support.v4.toast


class ProfileFragment : BaseFragment() {

    private lateinit var actionHistoryAdapter: ActionHistoryAdapter

    private var infoDisposable: Disposable? = null

    override fun onStart() {
        super.onStart()
        changeFont()
        getDriverInfo()
        getActionHistory()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        retainInstance = true
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?,
                              savedInstanceState: Bundle?): View? {
        val view = inflater.inflate(R.layout.fragment_profile, container, false)

        return view
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        rvActionHistory.layoutManager = LinearLayoutManager(context, LinearLayoutManager.VERTICAL, false)
        actionHistoryAdapter = ActionHistoryAdapter()
        rvActionHistory.adapter = actionHistoryAdapter
        rvActionHistory.isNestedScrollingEnabled = false

        toolbar.setNavigationIcon(R.drawable.ic_arrow_back)
        toolbar.setNavigationOnClickListener {
            goBack()
        }
    }

    override fun onStop() {
        super.onStop()
        infoDisposable?.dispose()
    }

    private fun getDriverInfo(){
        showProgress(true)

        infoDisposable = taxiService.value.getDriverInfo(loginService.value.accessToken)
                .subscribeOn(Schedulers.newThread())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe({ t: DriverModel ->

                    nameText.text = "${t.surname} ${t.name} ${t.middleName}"
                    carText.text = "${t.mark} ${t.model} ${t.stateNumber}"
                    phoneText.text = t.phoneNumber
                    ratingValueText.text = t.rating
                    activityValueText.text = t.activity

                    showProgress(false)
                }, { e ->
                    e.printStackTrace()
                    toast(e.localizedMessage)
                    showProgress(false)
                })

    }

    private fun getActionHistory(){
        progress_bar.visibility = View.VISIBLE

        infoDisposable = taxiService.value.getActionHistory(loginService.value.accessToken)
                .subscribeOn(Schedulers.newThread())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe({ t: ActionHistoryResponse ->
                    actionHistoryAdapter.setList(t.data!!)

                    progress_bar.visibility = View.GONE
                }, { e ->
                    e.printStackTrace()
                    toast(e.localizedMessage)
                    progress_bar.visibility = View.GONE
                })

    }

    private fun changeFont() {
        changeFontInTextView(nameText)
        changeFontInTextView(carText)
        changeFontInTextView(phoneText)
        changeFontInTextView(activityText)
        changeFontInTextView(ratingText)

        changeFontInTextViewBold(activityValueText)
        changeFontInTextViewBold(ratingValueText)
    }
}
