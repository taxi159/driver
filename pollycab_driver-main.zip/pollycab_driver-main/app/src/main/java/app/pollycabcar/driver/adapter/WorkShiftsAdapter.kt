package app.pollycabcar.driver.adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView

import androidx.recyclerview.widget.RecyclerView
import app.pollycabcar.driver.R
import app.pollycabcar.driver.model.WeekDay
import app.pollycabcar.driver.model.WorkShift
import app.pollycabcar.driver.util.DateFormatter
import java.util.*

class WorkShiftsAdapter(private val callback: ((workShift: WorkShift) -> Unit)? = null) : RecyclerView.Adapter<WorkShiftsAdapter.WorkShiftHolder>() {
    var list: List<WorkShift>? = null
        set(list) {
            field = list
            notifyDataSetChanged()
        }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): WorkShiftHolder {
        val v = LayoutInflater.from(parent.context)
                .inflate(R.layout.work_shift_item, parent, false)
        return WorkShiftHolder(v)
    }

    override fun onBindViewHolder(holder: WorkShiftHolder, position: Int) {
        holder.setIsRecyclable(false)
        val item = list?.get(position)

        holder.period.text = "${item?.period} часовая"
        holder.value.text = "${item?.price} \u20BD"
        holder.itemView.setOnClickListener {
            callback?.invoke(item!!)
        }
    }

    override fun getItemCount(): Int {
        return if (list != null)
            list!!.size
        else
            0
    }

    inner class WorkShiftHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val period: TextView
        val value: TextView

        init {
            period = itemView.findViewById(R.id.period)
            value = itemView.findViewById(R.id.value)
        }
    }
}
