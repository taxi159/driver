package app.pollycabcar.driver.model

import com.google.gson.annotations.SerializedName

class WeekEarn {

    @SerializedName("total")
    var total: String? = null

    @SerializedName("order_count")
    var orderCount: Int = 0

    @SerializedName("start")
    var start: String? = null

    @SerializedName("days")
    var weekDays: List<WeekDay>? = null
}