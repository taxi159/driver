package app.pollycabcar.driver.fragment

import android.content.Context
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.InputMethodManager
import app.pollycabcar.driver.R
import app.pollycabcar.driver.model.LoginResponse
import app.pollycabcar.driver.network.LoginService
import com.pixplicity.easyprefs.library.Prefs
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.schedulers.Schedulers
import kotlinx.android.synthetic.main.fragment_login.*
import org.jetbrains.anko.support.v4.toast


class LoginFragment : BaseFragment() {

    internal var phoneNumber: String? = null
    internal var phoneNumberFilled: Boolean = false

    private var imm: InputMethodManager? = null

    override fun onStart() {
        super.onStart()
        changeFont()
        showProgress(false)

        imm = context!!.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        retainInstance = true
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?,
                              savedInstanceState: Bundle?): View? {
        val view = inflater.inflate(R.layout.fragment_login, container, false)

        return view
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        btnContinue.setOnClickListener {
            if (phoneNumberLogin.text.length  < 15 || phoneNumberLogin.text.isNullOrBlank()){
                toast("Необходимо указать номер телефона")
            } else if (passwordLogin.text.isNullOrBlank()) {
                toast("Необходимо ввести пароль")
            } else {
                imm?.hideSoftInputFromWindow(view.windowToken, 0);
                showProgress(true)
                phoneNumber = phoneNumberLogin.text.toString()
                        .replace("(","")
                        .replace(")","")
                        .replace("-","")
                taxiPublicService.value.signInObservable(phoneNumber!!, passwordLogin.text.toString())
                        .subscribeOn(Schedulers.newThread())
                        .observeOn(AndroidSchedulers.mainThread())
                        .subscribe({ t: LoginResponse ->

                            if(t.status == "success") {
                                if (t.token != null) {
                                    Prefs.putString(LoginService.ACCESS_TOKEN_KEY, t.token)
                                    Prefs.putString(LoginService.SESSION_ID, t.session_id)
                                    mainActivity.createLocationRequest()
                                    mainActivity.getLocationPermissions()
                                    mainActivity.getDriverInfo()
                                }
                            }

                            if (t.status == "error") {
                                showProgress(false)

                                when(t.error) {
                                    "already_authenticated" -> toast("Водитель уже авторизирован на другом устройстве")
                                    "invalid_credentials" -> toast("Неверные данные для авторизации")
                                    "no_access" -> toast("Учётная запись заблокирована")
                                }
                            }

                        }, { e ->
                            e.printStackTrace()
                            toast("Таксопарк с таким логином не найден")
                            showProgress(false)
                        })
            }
        }

        phoneNumberLogin.setOnKeyListener(object : View.OnKeyListener {
            override fun onKey(v: View?, keyCode: Int, event: KeyEvent?): Boolean { //You can identify which key pressed buy checking keyCode value with KeyEvent.KEYCODE_
                if (keyCode == KeyEvent.KEYCODE_DEL) { //this is for backspace
                    println("sss")
                    phoneNumberLogin.getText().clear()
                }
                return false
            }
        })

        phoneNumberLogin.addTextChangedListener(object : TextWatcher {
            var beforeLength = 0

            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {
                beforeLength = phoneNumberLogin.length()
            }

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                val digits: Int = phoneNumberLogin.getText().toString().length
                if((digits==1)&&(phoneNumberLogin.getText().toString().equals("+"))) {
                    phoneNumberLogin.setText("7")
                    phoneNumberLogin.setSelection(phoneNumberLogin.length())
                    phoneNumberLogin.append("(")
                }
                if (beforeLength < digits && (digits == 1)) {
                    phoneNumberLogin.append("(")
                }
                if (beforeLength < digits && ( digits == 5)) {
                    phoneNumberLogin.append(")")
                }
                if (beforeLength < digits && (digits == 9|| digits == 12)) {
                    phoneNumberLogin.append("-")
                }
            }

            override fun afterTextChanged(s: Editable?) {}
        })
        phoneNumberLogin.hint = "7(000)000-00-00"
    }

    private fun changeFont() {
        changeFontInTextView(phoneNumberText)
        changeFontInTextView(passwordText)
        changeFontInTextViewBold(continueText)
        changeFontInEditTextView(phoneNumberLogin)
        changeFontInEditTextView(passwordLogin)
    }
}
