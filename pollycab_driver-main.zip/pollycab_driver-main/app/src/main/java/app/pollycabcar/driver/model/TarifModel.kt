package app.pollycabcar.driver.model

class TarifModel (var image: Int?, var title: String?, var number: String?, var isEnable: Boolean?)