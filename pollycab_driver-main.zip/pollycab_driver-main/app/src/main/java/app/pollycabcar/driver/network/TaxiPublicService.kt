package app.pollycabcar.driver.network

import app.pollycabcar.driver.model.LoginResponse
import io.reactivex.Observable
import retrofit2.http.*
import retrofit2.http.POST


interface TaxiPublicService {

    @FormUrlEncoded
    @POST("/api/authenticatePerformers")
    fun signInObservable(@Field("phone_number") phoneNumber: String, @Field("password") password: String) :Observable<LoginResponse>
}

