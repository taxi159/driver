package app.pollycabcar.driver.model

import com.google.gson.annotations.SerializedName

class OrdersResponse {

    @SerializedName("status")
    var status: String? = null

    @SerializedName("error")
    var error: String? = null

    @SerializedName("orders")
    var orders: ArrayList<RideModel>? = null
}