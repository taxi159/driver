package app.pollycabcar.driver.model

import com.google.gson.annotations.SerializedName

class Geo {
    @SerializedName("lat")
    var lat: String? = null

    @SerializedName("lon")
    var lon: String? = null
}