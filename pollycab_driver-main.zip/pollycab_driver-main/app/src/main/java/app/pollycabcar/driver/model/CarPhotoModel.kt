package app.pollycabcar.driver.model

import com.google.gson.annotations.SerializedName

class CarPhotoModel {

    @SerializedName("photo_left")
    var left: String? = null

    @SerializedName("photo_right")
    var right: String? = null

    @SerializedName("photo_forward")
    var forward: String? = null

    @SerializedName("photo_back")
    var back: String? = null
}