package app.pollycabcar.driver.fragment

import android.app.Activity
import android.content.Context
import android.graphics.Typeface
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.View
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.TextView
import app.pollycabcar.driver.R
import app.pollycabcar.driver.activity.MainActivity
import app.pollycabcar.driver.network.LoginService
import app.pollycabcar.driver.network.TaxiPublicService
import app.pollycabcar.driver.network.TaxiService
import com.github.salomonbrys.kodein.LazyKodein
import com.github.salomonbrys.kodein.android.appKodein
import com.github.salomonbrys.kodein.instance


abstract class BaseFragment : Fragment() {

    protected val kodein = LazyKodein(appKodein)

    protected var taxiService = kodein.instance<TaxiService>()
    protected var loginService = kodein.instance<LoginService>()
    protected var taxiPublicService = kodein.instance<TaxiPublicService>()

    protected lateinit var mainActivity: MainActivity

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)
        mainActivity = activity as MainActivity
    }

    fun refleshKodeinServices() {
        taxiService = kodein.instance<TaxiService>()
        loginService = kodein.instance<LoginService>()
        taxiPublicService = kodein.instance<TaxiPublicService>()
    }

    fun showProgress(show: Boolean) {
        mainActivity.progressView!!.visibility = if (show) View.VISIBLE else View.GONE
    }

    fun replaceFragment(fragment: Fragment, addToBackStack: Boolean = true, tag: String? = null) {
        val ft = mainActivity.supportFragmentManager.beginTransaction()
        ft.setCustomAnimations(R.anim.enter_from_right, R.anim.exit_to_left, R.anim.enter_from_left, R.anim.exit_to_right)
        if(tag == null)
            ft.replace(R.id.placeholder, fragment)
        else
            ft.replace(R.id.placeholder, fragment, tag)
        if (addToBackStack) {
            ft.addToBackStack(null)
        }

        ft.commit()
    }

    fun addFragment(fragment: Fragment, addToBackStack: Boolean = true, tag: String? = null) {
        val ft = mainActivity.supportFragmentManager.beginTransaction()
        ft.setCustomAnimations(R.anim.enter_from_right, R.anim.exit_to_left, R.anim.enter_from_left, R.anim.exit_to_right)
        if(tag == null)
            ft.add(R.id.placeholder, fragment)
        else
            ft.add(R.id.placeholder, fragment, tag)
        if (addToBackStack) {
            ft.addToBackStack(null)
        }

        ft.commit()
    }

    fun hideKeyboard() {
        val imm = mainActivity.applicationContext.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        if (imm.isActive) {
            view?.let {
                imm.hideSoftInputFromWindow(it.windowToken, 0)
            }
        }
    }

    fun goBack(){

        if (mainActivity.supportFragmentManager.backStackEntryCount > 0) {
            mainActivity.supportFragmentManager.popBackStackImmediate()
        }

    }

    fun changeFontInTextView(view: TextView){
        val type = Typeface.createFromAsset(context?.assets, "font/roboto_regular.ttf")
        view.typeface = type
    }

    fun changeFontInTextViewBold(view: TextView){
        val type = Typeface.createFromAsset(context?.assets, "font/roboto_medium.ttf")
        view.typeface = type
    }

    fun changeFontInEditTextView(view: EditText){
        val type = Typeface.createFromAsset(context?.assets, "font/roboto_regular.ttf")
        view.typeface = type
    }

    fun changeFontInEditTextViewBold(view: EditText){
        val type = Typeface.createFromAsset(context?.assets, "font/roboto_medium.ttf")
        view.typeface = type
    }

    fun hideKeyboardFrom(context: Context, view: View) {
        val imm = context.getSystemService(Activity.INPUT_METHOD_SERVICE) as InputMethodManager
        imm.hideSoftInputFromWindow(view.windowToken, 0)
    }
}
