package app.pollycabcar.driver.adapter


import android.graphics.Typeface
import androidx.recyclerview.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import app.pollycabcar.driver.R
import app.pollycabcar.driver.model.Report
import org.jetbrains.anko.find
import java.text.SimpleDateFormat
import java.util.*

class ReportsAdapter(private val callback: ((id: Int) -> Unit)? = null) : RecyclerView.Adapter<ReportsAdapter.MyViewHolder>() {

    private var newsList: List<Report> = listOf()

    fun setList(list: List<Report>) {
        newsList = list
        notifyDataSetChanged()
    }

    inner class MyViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        var textStatus: TextView = view.find(R.id.textStatus)
        var textTime: TextView = view.find(R.id.textTime)
        var title: TextView = view.find(R.id.title)
        var iconStatus: ImageView = view.find(R.id.iconStatus)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyViewHolder {
        val itemView = LayoutInflater.from(parent.context)
                .inflate(R.layout.support_themes_item, parent, false)

        return MyViewHolder(itemView)
    }

    override fun onBindViewHolder(holder: MyViewHolder, position: Int) {
        val item = newsList[position]

        val type = Typeface.createFromAsset(holder.itemView.context?.assets, "font/roboto_regular.ttf")
        val typeBold = Typeface.createFromAsset(holder.itemView.context?.assets, "font/roboto_medium.ttf")

        holder.title.text = item.topic

        if (item.checked == 0){
            holder.textStatus.text = "Открыто"
            holder.iconStatus.setImageResource(R.drawable.ic_access_time)
        } else {
            holder.textStatus.text = "Закрыто"
            holder.iconStatus.setImageResource(R.drawable.ic_check)
        }

        var format: SimpleDateFormat = SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
        val timezoneUTC: TimeZone = TimeZone.getTimeZone("Europe/Moscow")
        format.timeZone = timezoneUTC
        val date: Date = format.parse(item.createdAt)

        val timezoneDefault: TimeZone = TimeZone.getDefault()
        format = SimpleDateFormat("E, d MMM HH:mm", Locale("ru"))
        format.timeZone = timezoneDefault
        val createdAt: String = format.format(date)
        holder.textTime.text = createdAt

        holder.textStatus.typeface = type
        holder.title.typeface = typeBold
        holder.textTime.typeface = type

        holder.itemView.setOnClickListener {
            callback?.invoke(item.id!!)
        }
    }

    override fun getItemCount(): Int {
        return newsList.size
    }
}
