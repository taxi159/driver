package app.pollycabcar.driver.fragment

import android.Manifest
import android.app.Dialog
import android.content.Context
import android.content.Intent
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import android.widget.Toast
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat.checkSelfPermission
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.Observer
import app.pollycabcar.driver.R
import app.pollycabcar.driver.model.DataResponse
import app.pollycabcar.driver.model.DriverModel
import app.pollycabcar.driver.model.OrderModel
import app.pollycabcar.driver.repo.OrdersRepository
import app.pollycabcar.driver.repo.ProfileRepository
import com.karumi.dexter.Dexter
import com.karumi.dexter.MultiplePermissionsReport
import com.karumi.dexter.PermissionToken
import com.karumi.dexter.listener.multi.MultiplePermissionsListener
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.disposables.Disposable
import io.reactivex.schedulers.Schedulers
import kotlinx.android.synthetic.main.fragment_main.*
import org.jetbrains.anko.find
import org.jetbrains.anko.support.v4.toast
import java.text.SimpleDateFormat
import java.util.*


class MainFragment : BaseFragment() {

    private var profile: DriverModel? = null

    private var infoDisposable: Disposable? = null
    private var statusDisposable: Disposable? = null
    private var firebaseDisposable: Disposable? = null
    private var orderDisposable: Disposable? = null
    private var ordersListDisposable: Disposable? = null

    private var isGranted: Boolean = false

    override fun onStart() {
        super.onStart()
        changeFont()

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            val intent = Intent()
            val packageName = context?.packageName
            val pm = context?.getSystemService(Context.POWER_SERVICE) as PowerManager
            if (!pm.isIgnoringBatteryOptimizations(packageName)) {
                intent.action = Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS
                intent.data = Uri.parse("package:$packageName")
                startActivity(intent)
            }
        }

        if (!isGranted) {
            getLocationPermissions()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        retainInstance = true
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_main, container, false)

        return view
    }

    fun getDrawable(resourceId: Int): Drawable? {
        return if (Build.VERSION.SDK_INT >= 21) {
            context?.getDrawable(resourceId)
        } else { /*from   w w  w  . ja  v  a 2s .c  o m*/
            context?.resources?.getDrawable(resourceId)
        }
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        subscribeToProfile()
        subscribeToOrders()

        onlineOfflineSwitch.setOnClickListener {
            if (onlineOfflineSwitch.isChecked) {
                statusDisposable?.dispose()
                statusDisposable = taxiService.value.setStatusOnline(loginService.value.accessToken)
                    .subscribeOn(Schedulers.newThread())
                    .observeOn(AndroidSchedulers.mainThread())
                    .subscribe({ t: DataResponse ->
                        if (t.status == "success") {
                            toast("Вы вышли на линию")
                            ProfileRepository.instance?.setStatus(1)
                        } else if (t.status == "error" && t.error == "no_access") {
                            toast("Доступ запрещён")
                            onlineOfflineSwitch.isChecked = false
                        }
                    }, { e ->
                        e.printStackTrace()
                        toast(e.localizedMessage)
                    })
            } else {
                statusDisposable?.dispose()
                statusDisposable =
                    taxiService.value.setStatusOffline(loginService.value.accessToken)
                        .subscribeOn(Schedulers.newThread())
                        .observeOn(AndroidSchedulers.mainThread())
                        .subscribe({ t: DataResponse ->
                            if (t.status == "success") {
                                toast("Вы ушли с линии")
                                ProfileRepository.instance?.setStatus(0)
                            } else if (t.status == "error" && t.error == "no_access") {
                                toast("Доступ запрещён")
                                onlineOfflineSwitch.isChecked = true
                            }
                        }, { e ->
                            e.printStackTrace()
                            toast(e.localizedMessage)
                        })
            }
        }

        activeOrderEnterBtn.setOnClickListener {

            replaceFragment(ActiveOrderFragment.newInstance(profile?.activeOrder?.id!!))
        }

        btnOrders.setOnClickListener {
            if (isGranted) {
                mainActivity.hardReplaceFragment(OrdersFragment())
            } else {
                getLocationPermissions()
                return@setOnClickListener
            }
        }

        btnMoney.setOnClickListener {
            replaceFragment(FinanceFragment(), true)
        }

        btnFinishedOrders.setOnClickListener {
            replaceFragment(RidesFragment(), true)
        }

        btnSupport.setOnClickListener {
            replaceFragment(SupportFragment(), true)
        }

        btnProfile.setOnClickListener {
            replaceFragment(ProfileFragment(), true)
        }

        logoutButton.setOnClickListener() {
            logout()
        }
    }

    private fun subscribeToProfile() {
        val liveData: MutableLiveData<DriverModel> =
            ProfileRepository.instance!!.profileLiveData
        liveData.observe(this, Observer { t ->
            profile = t

            userName.text = "${t.name} ${t.surname}"

            onlineOfflineSwitch.isChecked = t.status == 1

            if (t.activeOrder != null) {
                activeOrder.visibility = View.VISIBLE
                counterNewOrders.visibility = View.GONE

                var format: SimpleDateFormat = SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
                val date: Date = format.parse(t.activeOrder?.deadline)
                format = SimpleDateFormat("E, d MMM HH:mm", Locale("ru"))
                val deadline: String = format.format(date)
                activeOrderDeadlineText.text = deadline

                activeOrderAddressText.text = t.activeOrder?.addresses?.get(0)
                activeOrderCostText.text =
                    t.activeOrder?.tripCost.toString() + " " + getString(R.string.currency)
            } else {
                activeOrder.visibility = View.GONE
            }
        })
    }

    private fun subscribeToOrders() {
        val liveData: MutableLiveData<ArrayList<OrderModel>> =
            OrdersRepository.instance!!.ordersLiveData
        liveData.observe(this, Observer { t ->
            if (profile?.activeOrder != null || t.size == 0) {
                counterNewOrders.visibility = View.GONE
                return@Observer
            }

            if (t.size == 1) {
                counterNewOrders.visibility = View.VISIBLE
                countNewOrdersText.text = "${t.size} заказ"
            } else if (t.size!! in 2..4) {
                counterNewOrders.visibility = View.VISIBLE
                countNewOrdersText.text = "${t.size} заказа"
            } else if (t.size > 4) {
                counterNewOrders.visibility = View.VISIBLE
                countNewOrdersText.text = "${t.size} заказов"
            }
        })
    }

    private fun logout() {
        showProgress(true)

        infoDisposable?.dispose()
        infoDisposable = taxiService.value.logout(loginService.value.accessToken)
            .subscribeOn(Schedulers.newThread())
            .observeOn(AndroidSchedulers.mainThread())
            .subscribe({ t: DataResponse ->

                if (t.status == "success") {
                    loginService.value.logout()
                    toast("Вы вышли из учётной записи")
                    mainActivity.removeLocationUpdates()
                    mainActivity.hardReplaceFragment(LoginFragment())
                } else {
                    toast("Что-то пошло не так, попробуйте еще раз")
                }

                showProgress(false)
            }, { e ->
                e.printStackTrace()
                toast(e.localizedMessage)
                showProgress(false)
            })
    }

    private fun getLocationPermissions() {
        Dexter.withContext(mainActivity)
            .withPermissions(
                Manifest.permission.ACCESS_COARSE_LOCATION,
                Manifest.permission.ACCESS_FINE_LOCATION
            )
            .withListener(object : MultiplePermissionsListener {

                override fun onPermissionRationaleShouldBeShown(
                    permissions: MutableList<com.karumi.dexter.listener.PermissionRequest>?,
                    token: PermissionToken?
                ) {
                    val mDialog = Dialog(mainActivity, R.style.CustomDialog)
                    mDialog.setCancelable(true)
                    mDialog.setContentView(R.layout.dialog_with_action)

                    val type = Typeface.createFromAsset(context?.assets, "font/roboto_regular.ttf")

                    val title = mDialog?.find<TextView>(R.id.title)
                    val firstButtonText = mDialog?.find<TextView>(R.id.firstButtonText)
                    val secondButtonText = mDialog?.find<TextView>(R.id.secondButtonText)
                    secondButtonText.visibility = View.GONE

                    title.typeface = type
                    title.text = getString(R.string.geo_request_desc)
                    firstButtonText.typeface = type
                    firstButtonText.text = "Ок"

                    firstButtonText.setOnClickListener {
                        token?.continuePermissionRequest()
                        mDialog.dismiss()
                    }
                    mDialog.show()
                }

                override fun onPermissionsChecked(report: MultiplePermissionsReport?) {

                    if (report?.areAllPermissionsGranted()!!) {
                        isGranted = true
                        mainActivity.requestLocationUpdates()

                    }
                }
            }).check()
    }


    private fun changeFont() {
        changeFontInTextView(newOrdersText)
        changeFontInTextView(finishedOrdersText)
        changeFontInTextView(moneyText)
        changeFontInTextView(supportText)
        changeFontInTextView(profileText)
        changeFontInTextView(activeOrderPointText)
        changeFontInTextView(activeOrderDeadlineText)

        changeFontInTextViewBold(userName)
        changeFontInTextViewBold(activeOrderText)
        changeFontInTextViewBold(activeOrderEnterText)
        changeFontInTextViewBold(activeOrderAddressText)
        changeFontInTextViewBold(activeOrderCostText)
    }

    override fun onStop() {
        super.onStop()
        infoDisposable?.dispose()
        statusDisposable?.dispose()
        firebaseDisposable?.dispose()
        orderDisposable?.dispose()
    }
}
