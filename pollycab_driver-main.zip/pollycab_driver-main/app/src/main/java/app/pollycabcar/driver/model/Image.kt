package app.pollycabcar.driver.model

class Image (var image: Int)